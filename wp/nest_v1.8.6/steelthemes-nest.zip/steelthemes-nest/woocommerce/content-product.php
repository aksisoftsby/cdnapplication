<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Check if the product is a valid WooCommerce product and ensure its visibility before proceeding.
if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
	return;
}
defined( 'ABSPATH' ) || exit;
global $product;
global $nest_theme_mod;
$listview = '';
 if(nest_get_view_via_url() == 'list-view'): 
	$listview = 'display-list';
 endif;
 $brand_terms = get_the_terms($product->get_id(), 'brand'); // Replace 'product_brand' with your actual brand taxonomy slug
$brand_classes = '';

if ($brand_terms && !is_wp_error($brand_terms)) {
    foreach ($brand_terms as $brand_term) {
        $brand_classes .= ' product_brand-' . $brand_term->slug;
    }
}
$product_archive_style = isset( $nest_theme_mod['product_archive_style'] ) ? $nest_theme_mod['product_archive_style'] : '';
 if(nest_get_view_via_url() == 'list-view'): ?>
	<li <?php wc_product_class( $listview . $brand_classes , $product ); ?>>
		<?php do_action('get_nest_product_card_list'); ?>
	</li>
<?php else: ?>
<?php if($product_archive_style == 'style_two' || nest_get_product_card_option_via_url() == 'style_two'): ?>
    <li <?php wc_product_class( 'product_grid_style_two' . $brand_classes, $product ); ?>>
        <?php  do_action('get_nest_product_single_card_one'); ?>
    </li>
<?php elseif($product_archive_style == 'style_three' || nest_get_product_card_option_via_url() == 'style_three'): ?>
    <li <?php wc_product_class( $brand_classes, $product ); ?>>
        <?php  do_action('get_nest_product_card_three'); ?>
    </li>
<?php elseif($product_archive_style == 'style_four' || nest_get_product_card_option_via_url() == 'style_four'): ?>
    <li <?php wc_product_class( $brand_classes, $product ); ?>>
        <?php  do_action('get_nest_product_card_two'); ?>
    </li>
<?php elseif($product_archive_style == 'style_five' || nest_get_product_card_option_via_url() == 'style_five'): ?>
    <li <?php wc_product_class( $brand_classes, $product ); ?>>
        <?php  do_action('get_nest_product_card_six'); ?>
    </li>
<?php else: ?>
    <li <?php wc_product_class( $brand_classes, $product ); ?>>
        <?php  do_action('get_nest_product_card_one'); ?>
    </li>
<?php endif; ?>
<?php endif; ?>
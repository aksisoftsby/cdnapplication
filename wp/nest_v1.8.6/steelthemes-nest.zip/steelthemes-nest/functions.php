<?php
/*
**   ==============================   
**    Nest Ecommerce Function File
**   ==============================
*/ 
//Mobile Detect
require_once get_template_directory() . '/includes/lib/Nest_Mobile_Detect.php';
/*
==========================================
Metabox admin styles
==========================================
*/
function isMobile() {
    if ( ! class_exists( 'Nest_Mobile_Detect' ) ) {
        return false;
    }
    $detect = new Nest_Mobile_Detect;
    $mobile = false;
    if( $detect->isMobile() || $detect->isTablet() ){
        $mobile = true;
    }
    return $mobile;
}
require get_template_directory() . '/includes/functions/theme.php';
 // ============================== theme update ============================
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;
if(class_exists('Nest_update')):
$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://themepanthers.com/updatedplugin/nest/theme.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'nest-theme-update'
);
endif;
// ============================== theme update ============================

/*
==========================================
Disable Elementor Boarding
==========================================
*/
add_action('init', 'nest_disable_elementor_onboarding_redirect');
function nest_disable_elementor_onboarding_redirect() {
    delete_transient( 'elementor_activation_redirect' );
}
// Disable redirection after activating The Woocommerce
add_filter( 'woocommerce_prevent_automatic_wizard_redirect', '__return_true' );   
// Disable WooCommerce Page Installation
add_filter( 'woocommerce_create_pages', '__return_false' ); 

 
/**
 * Add admin notice for plugin updates.
 */
add_action('admin_notices', 'custom_plugin_update_notice');
function custom_plugin_update_notice() {
    // Only run for admin users with manage_options capability
    if (!current_user_can('manage_options')) {
        return;
    }

    // Only run on plugins page to reduce overhead
    $screen = get_current_screen();
    if ($screen->base !== 'plugins') {
        return;
    }

    // URL to the hosted version.json file
    $json_url = 'https://themepanthers.com/updatedplugin/plugins.json';

    // Check transient for cached data
    $transient_key = 'custom_plugin_update_data';
    $data = get_transient($transient_key);

    if (false === $data) {
        // Set strict arguments for the request
        $args = array(
            'timeout'     => 5,
            'redirection' => 5,
            'sslverify'   => true,
            'headers'     => array(
                'Accept' => 'application/json'
            )
        );

        // Fetch the JSON file
        $response = wp_remote_get(esc_url_raw($json_url), $args);

        // Check for errors
        if (is_wp_error($response)) {
            error_log('Plugin update check failed: ' . $response->get_error_message());
            return;
        }

        // Verify response code
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('Plugin update check failed with response code: ' . $response_code);
            return;
        }

        // Parse the JSON response
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        // Cache the data for 12 hours
        set_transient($transient_key, $data, 12 * HOUR_IN_SECONDS);
    }

    // Validate JSON structure
    if (!is_array($data) || !isset($data['plugins']) || !is_array($data['plugins'])) {
        error_log('Invalid plugin update JSON structure');
        return;
    }

    // Trusted domains for source URLs
    $trusted_domains = ['themepanthers.com', 'themeforest.net'];

    foreach ($data['plugins'] as $plugin) {
        // Validate required plugin data
        if (!isset($plugin['slug'], $plugin['name'], $plugin['latest_version'], $plugin['source']) ||
            !is_string($plugin['slug']) ||
            !is_string($plugin['name']) ||
            !is_string($plugin['latest_version']) ||
            !is_string($plugin['source'])) {
            error_log('Invalid plugin data for slug: ' . (isset($plugin['slug']) ? $plugin['slug'] : 'unknown'));
            continue;
        }

        // Validate source URL domain
        $source_host = parse_url($plugin['source'], PHP_URL_HOST);
        if (!in_array($source_host, $trusted_domains)) {
            error_log('Untrusted source URL for plugin: ' . $plugin['slug']);
            continue;
        }

        // Sanitize plugin data
        $slug = sanitize_file_name($plugin['slug']);
        $plugin_path = wp_normalize_path(WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php');

        // Verify the path is within the plugins directory
        if (strpos($plugin_path, wp_normalize_path(WP_PLUGIN_DIR)) !== 0 || !file_exists($plugin_path)) {
            error_log('Invalid plugin path for slug: ' . $slug);
            continue;
        }

        // Get installed plugin data
        $plugin_data = get_plugin_data($plugin_path);
        $installed_version = isset($plugin_data['Version']) ? $plugin_data['Version'] : '';

        if (!empty($installed_version) && version_compare($installed_version, $plugin['latest_version'], '<')) {
            // Use wp_kses to allow only specific HTML tags
            $message = sprintf(
                __('A new version of %s is available. Installed version: %s, Latest version: %s. You can download the update from %s.', 'risehand'),
                '<strong>' . esc_html($plugin['name']) . '</strong>',
                esc_html($installed_version),
                esc_html($plugin['latest_version']),
                '<a href="' . esc_url($plugin['source']) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('here', 'risehand') . '</a>'
            );

            printf(
                '<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
                wp_kses(
                    $message,
                    array(
                        'strong' => array(),
                        'a' => array(
                            'href' => array(),
                            'target' => array(),
                            'rel' => array()
                        )
                    )
                )
            );
        }
    }
}

 
/**
 * Add admin notice for Ecom Theme promotion.
 */
add_action('admin_notices', 'ecom_theme_launch_notice');
function ecom_theme_launch_notice() {
    // Only run for admin users with manage_options capability
    if (!current_user_can('manage_options')) {
        return;
    }

    // Check if notice was permanently dismissed
    if (get_option('ecom_theme_notice_dismissed') === 'permanent') {
        return;
    }

    // Generate nonce for AJAX
    $nonce = wp_create_nonce('ecom_dismiss_nonce');
    ?>
    <style>
        .ecom-admin-notice {
            border: 4px solid #FD9636;
            background: #F0F3F8;
            padding: 15px 20px;
            margin: 20px 0;
            border-radius: 8px;
            font-family: "DM Sans", sans-serif;
            color: #425A8B;
            display: flex;
            align-items: center;
            gap: 15px;
            justify-content: space-between;
            position: relative;
        }
        .ecom-admin-notice .image {
            width: 40%;
            height: auto;
        }
        .ecom-admin-notice img {
            width: 100%;
            height: auto;
            border-radius: 4px;
        }
        .ecom-admin-notice .content {
            width: 55%;
        }
        .ecom-admin-notice h2 {
            margin: 0 0 5px;
            font-size: 18px;
            color: #425A8B;
        }
        .ecom-admin-notice p {
            margin: 0 0 10px;
            color: #8C9EC5;
            font-size: 14px;
        }
        .ecom-admin-notice ul {
            margin: 20px 0;
            padding-left: 20px;
            color: #8C9EC5;
            font-size: 14px;
            display: flex;
            flex-wrap:wrap;
            gap: 5px 1.5rem;
        }
        .ecom-admin-notice li {
            margin-bottom: 5px;
            list-style: decimal;
        }
        .ecom-notice-dismiss {
            position: absolute;
            top: 10px;
            right: 15px;
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            color: #8C9EC5;
            padding: 0;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .ecom-notice-dismiss:hover {
            color: #425A8B;
        }
    </style>
    <div class="notice notice-info ecom-admin-notice" id="ecom-admin-notice">
        <button class="ecom-notice-dismiss" onclick="dismissEcomNotice()" title="<?php esc_attr_e('Dismiss permanently', 'ecom-theme'); ?>">×</button>
        <div class="image">
            <img src="<?php echo esc_url('https://elango.steelthemes.com/ecom/ecom-promo.jpg'); ?>" alt="<?php esc_attr_e('Ecom Theme', 'ecom-theme'); ?>" />
        </div>
        <div class="content">
            <h2><strong><?php esc_html_e('Ecom Multipurpose WooCommerce Theme', 'ecom-theme'); ?></strong></h2>
            <p>
                <?php
                printf(
                    esc_html__('Check the demos: %s | %s | %s', 'ecom-theme'),
                    '<a href="' . esc_url('https://elango.steelthemes.com/ecom/el1/') . '" target="_blank">' . esc_html__('Elementor Page Builder Version', 'ecom-theme') . '</a>',
                    '<a href="' . esc_url('https://elango.steelthemes.com/ecom/wp1') . '" target="_blank">' . esc_html__('WPBakery Page Builder Version', 'ecom-theme') . '</a>',
                    '<a href="' . esc_url('https://elango.steelthemes.com/ecom/el2/') . '" target="_blank">' . esc_html__('Grocery Demo', 'ecom-theme') . '</a>'
                );
                ?><br>
                <?php esc_html_e('Ecom comes with powerful built-in features for smart online stores, no extra plugins needed.', 'ecom-theme'); ?>
            </p>
            <ul>
                <li><?php esc_html_e('Live AJAX Product Filtering', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Quickview Popups', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('AJAX Add to Cart with Plus/Minus Quantity Controls', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Built-in Variation Swatches', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Wishlist & Compare Functionality', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Countdown Timer & Mobile Sticky Menu', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Request a Quote Mode', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Live AJAX Search', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Frequently Bought Together', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Quick Buy Now', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Product Request Quote', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Location Taxonomy Filter', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('4 Types of Product Single', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Video In Gallery', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Product Review With Image Upload Option', 'ecom-theme'); ?></li>
                <li><?php esc_html_e('Dokan Multivendor Support', 'ecom-theme'); ?></li>
            </ul>
            <p>
                <strong><?php esc_html_e('No extra plugins needed, all these options come built-in with Ecom', 'ecom-theme'); ?></strong><br>
                <?php
                printf(
                    esc_html__('🎉 Launched at just %s first release offer. The price will increase to $59 soon.', 'ecom-theme'),
                    '<strong style="color: #FD9636;">$18</strong>'
                );
                ?>
            </p>
            <a href="<?php echo esc_url('https://themeforest.net/item/ecom-multipurpose-woocommerce-wp-theme/58774920'); ?>" class="button" target="_blank"><?php esc_html_e('Purchase and Save $40 Now', 'ecom-theme'); ?></a>
        </div>
    </div>
    <script>
        function dismissEcomNotice() {
            const notice = document.getElementById('ecom-admin-notice');
            notice.style.display = 'none';

            // Send AJAX request to save dismiss time
            jQuery.ajax({
                url: '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
                type: 'POST',
                data: {
                    action: 'dismiss_ecom_notice',
                    nonce: '<?php echo esc_js($nonce); ?>'
                },
                error: function() {
                    alert('<?php echo esc_js(__('Failed to dismiss the notice. Please try again.', 'ecom-theme')); ?>');
                    notice.style.display = 'block';
                }
            });
        }
    </script>
    <?php
}

/**
 * Handle AJAX request to dismiss the Ecom theme notice.
 */
add_action('wp_ajax_dismiss_ecom_notice', 'handle_dismiss_ecom_notice');
function handle_dismiss_ecom_notice() {
    // Verify nonce for security
    check_ajax_referer('ecom_dismiss_nonce', 'nonce');

    // Save permanent dismissal
    update_option('ecom_theme_notice_dismissed', 'permanent');

    wp_send_json_success();
}

/**
 * Reset the Ecom notice dismissal (for testing purposes).
 */
function reset_ecom_notice() {
    delete_option('ecom_theme_notice_dismissed');
} 
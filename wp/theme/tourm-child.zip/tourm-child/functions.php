<?php
/**
 *
 * @Packge      Tourm 
 * @Author      Themeholy
 * @Author URL  https://themeforest.net/user/themeholy 
 * @version     2.1.0
 *
 */

/**
 * Enqueue style of child theme
 */
function tourm_child_enqueue_styles() {

    wp_enqueue_style( 'tourm-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'tourm-child-style', get_stylesheet_directory_uri() . '/style.css',array( 'tourm-style' ),wp_get_theme()->get('Version'));
}
add_action( 'wp_enqueue_scripts', 'tourm_child_enqueue_styles', 100000 );
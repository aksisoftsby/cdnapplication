<?php

// SECTION
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_section', 'show_video_on_mobile' );
	bt_bb_remove_params( 'bt_bb_section', 'background_overlay' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_section', array(		
		array( 'param_name' => 'background_overlay', 'type' => 'dropdown', 'heading' => esc_html__( 'Background overlay', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ), 
			'value' => array(
				esc_html__( 'No overlay', 'avantage' )    => '',
				esc_html__( 'Light stripes', 'avantage' ) => 'light_stripes',
				esc_html__( 'Dark stripes', 'avantage' )  => 'dark_stripes',
				esc_html__( 'Light solid', 'avantage' )	  => 'light_solid',
				esc_html__( 'Dark solid', 'avantage' )	  => 'dark_solid',
				esc_html__( 'Accent solid', 'avantage' )	  => 'accent_solid',
				esc_html__( 'Alternate solid', 'avantage' )	  => 'alternate_solid',
				esc_html__( 'Light gradient', 'avantage' )	  => 'light_gradient',
				esc_html__( 'Dark gradient', 'avantage' )	  => 'dark_gradient'
			)
		),
		array( 'param_name' => 'background_position', 'type' => 'textfield', 'heading' => esc_html__( 'Background position in keywords (e.g. left, right, top, bottom, center) or in pixels / percentage - ineffective if parallax is used', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),
		array( 'param_name' => 'background_size', 'type' => 'textfield', 'heading' => esc_html__( 'Background size (e.g. auto, cover, contain, initial, inherit or size in pixels - ineffective if parallax is used', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),			
		array( 'param_name' => 'show_boxed_content', 'type' => 'dropdown', 'default' => 'no', 'heading' => esc_html__( 'Box column content', 'avantage' ), 'description' => esc_html__( 'Used to stretch or box column content, only applicable for one and two column layouts', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__( 'No', 'avantage' ) => 'no',
				esc_html__( 'Box both columns', 'avantage' ) => 'yes',
				esc_html__( 'Box left column', 'avantage' ) => 'left',
				esc_html__( 'Box right column', 'avantage' ) => 'right'
			)
		),
		array( 'param_name' => 'allow_content_outside', 'type' => 'dropdown', 'heading' => esc_html__( 'Top & Bottom Coverage Images position', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__( 'No (content to be underneath top and bottom covering image)', 'avantage' ) => 'no',
				esc_html__( 'Yes (content will cover both covering images)', 'avantage' ) => 'yes'
			)
		),		
	));
}

function avantage_bt_bb_section_class( $class, $atts ) {
	if ( isset( $atts['allow_content_outside'] ) && $atts['allow_content_outside'] == 'yes' ) {
		$class[] = 'bt_bb_section_allow_content_outside';
	}

	if ( isset( $atts['show_boxed_content'] ) ) {
			if ( $atts['show_boxed_content'] == 'yes' ) {
				$class[] = 'bt_bb_section' . '_show_boxed_content';
			}
			if ( $atts['show_boxed_content'] == 'left' ) {
				$class[] = 'bt_bb_section' . '_show_left_boxed_content';
			}
			if ( $atts['show_boxed_content'] == 'right' ) {
				$class[] = 'bt_bb_section' . '_show_right_boxed_content';
			}
	}

	return $class;
}

function avantage_bt_bb_section_style( $style, $atts ) {
	if ( isset( $atts['background_position'] ) && $atts['background_position'] != '' ) {	
		$background_position_style  = 'background-position:' . $atts['background_position'] . ';';
		if ( $background_position_style ) $style .= $background_position_style;
	}
	if ( isset( $atts['background_size'] ) && $atts['background_size'] != '' ) {	
		$background_size_style  = 'background-size:' . $atts['background_size'] . ';';
		if ( $background_size_style ) $style .= $background_size_style;
	}
	return $style;
}

add_filter( 'bt_bb_section_class', 'avantage_bt_bb_section_class', 10, 2 );
add_filter( 'bt_bb_section_style', 'avantage_bt_bb_section_style', 10, 2 );



// ROW and INNER ROW: New row & column fix
// Move el_style to inner element (compatibility with old row and inner_row)

/* Row fix */
function avantage_bt_bb_row_fix_inner_style( $el_inner_style, $atts ) {
	$el_style = isset( $atts['el_style'] ) && $atts['el_style'] != '' ? $atts['el_style'] : 0;
	return $el_inner_style . '; ' . $el_style;
}
function avantage_bt_bb_row_style( $el_style, $atts ) {
	return '';
}
add_filter( 'bt_bb_row_fix_inner_style', 'avantage_bt_bb_row_fix_inner_style', 10, 2 );
add_filter( 'bt_bb_row_style', 'avantage_bt_bb_row_style', 10, 2 );

/* Inner row fix */
function avantage_bt_bb_row_inner_fix_inner_style( $el_inner_style, $atts ) {
	$el_style = isset( $atts['el_style'] ) && $atts['el_style'] != '' ? $atts['el_style'] : 0;
	return $el_inner_style . '; ' . $el_style;
}
function avantage_bt_bb_row_inner_style( $el_style, $atts ) {
	return '';
}
add_filter( 'bt_bb_row_inner_fix_inner_style', 'avantage_bt_bb_row_inner_fix_inner_style', 10, 2 );
add_filter( 'bt_bb_row_inner_style', 'avantage_bt_bb_row_inner_style', 10, 2 );



// COLUMN - BACKGROUND POSITION & SIZE, INNER BACKGROUND POSITION & SIZE, HIGHLIGHT, ALIGN TO EDGE
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_column', array(
		array( 'param_name' => 'background_position', 'type' => 'textfield', 'heading' => esc_html__( 'Background position in keywords (e.g. left, right, top, bottom, center) or in pixels / percentage', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),
		array( 'param_name' => 'background_size', 'type' => 'textfield', 'heading' => esc_html__( 'Background size (e.g. auto, cover, contain, initial, inherit or size in pixels', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),
		array( 'param_name' => 'inner_background_position', 'type' => 'textfield', 'heading' => esc_html__( 'Inner Background position in keywords (e.g. left, right, top, bottom, center) or in pixels / percentage', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),
		array( 'param_name' => 'inner_background_size', 'type' => 'textfield', 'heading' => esc_html__( 'Inner Background size (e.g. auto, cover, contain, initial, inherit or size in pixels', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),                                
		array( 'param_name' => 'highlight', 'type' => 'dropdown', 'default' => 'no', 'heading' => esc_html__( 'Show shadow on column', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
					esc_html__( 'No', 'avantage' ) => 'no',
					esc_html__( 'Yes', 'avantage' ) => 'yes'
			)
		),
		array( 'param_name' => 'align_to_edge_column', 'type' => 'dropdown', 'default' => 'no', 'heading' => esc_html__( 'Align column to screen edges on mobile screens - below 992px', 'avantage' ), 'group' => esc_html__( 'Responsive', 'avantage' ),
			'value' => array(
				esc_html__( 'No', 'avantage' ) => 'no',
				esc_html__( 'Align to left screen edge', 'avantage' ) => 'left',
				esc_html__( 'Align to right screen edge', 'avantage' ) => 'right',
				esc_html__( 'Align to both screen edges', 'avantage' ) => 'both'
			)
		),
	));
}

function avantage_bt_bb_column_class( $class, $atts ) {
	if ( isset( $atts['align_to_edge_column'] ) && $atts['align_to_edge_column'] == 'left' ) {
		$class[] = 'bt_bb_mobile_align_to_left_edge';
	}
	if ( isset( $atts['align_to_edge_column'] ) && $atts['align_to_edge_column'] == 'right' ) {
		$class[] = 'bt_bb_mobile_align_to_right_edge';
	}
	if ( isset( $atts['align_to_edge_column'] ) && $atts['align_to_edge_column'] == 'both' ) {
		$class[] = 'bt_bb_mobile_align_to_both_edge';
	}
	if ( isset( $atts['highlight'] ) && $atts['highlight'] == 'yes' ) {
		$class[] = 'bt_bb_highlight';
	}
	
	return $class;
}

function avantage_bt_bb_column_style( $style_attr, $atts ) {
	if ( isset( $atts['background_position'] ) && $atts['background_position'] != '' ) {
		$style_attr = $style_attr . '--background-position:' . $atts['background_position'] . ';';
	}
	if ( isset( $atts['background_size'] ) && $atts['background_size'] != '' ) {
		$style_attr = $style_attr . '--background-size:' . $atts['background_size'] . ';';
	}
	if ( isset( $atts['inner_background_position'] ) && $atts['inner_background_position'] != '' ) {
		$style_attr = $style_attr . '--inner-background-position:' . $atts['inner_background_position'] . ';';
	}
	if ( isset( $atts['inner_background_size'] ) && $atts['inner_background_size'] != '' ) {
		$style_attr = $style_attr . '--inner-background-size:' . $atts['inner_background_size'] . ';';
	}

	return $style_attr;
}

add_filter( 'bt_bb_column_class', 'avantage_bt_bb_column_class', 10, 2 );
add_filter( 'bt_bb_column_style', 'avantage_bt_bb_column_style', 10, 2 );



// INNER COLUMN - BACKGROUND POSITION & SIZE, INNER BACKGROUND POSITION & SIZE, HIGHLIGHT
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_column_inner', array(
		array( 'param_name' => 'background_position', 'type' => 'textfield', 'heading' => esc_html__( 'Background position in keywords (e.g. left, right, top, bottom, center) or in pixels / percentage', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),
		array( 'param_name' => 'background_size', 'type' => 'textfield', 'heading' => esc_html__( 'Background size (e.g. auto, cover, contain, initial, inherit or size in pixels', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),
		array( 'param_name' => 'inner_background_position', 'type' => 'textfield', 'heading' => esc_html__( 'Inner Background position in keywords (e.g. left, right, top, bottom, center) or in pixels / percentage', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),
		array( 'param_name' => 'inner_background_size', 'type' => 'textfield', 'heading' => esc_html__( 'Inner Background size (e.g. auto, cover, contain, initial, inherit or size in pixels', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ) ),                                
		array( 'param_name' => 'highlight', 'type' => 'dropdown', 'default' => 'no', 'heading' => esc_html__( 'Outer column with shadow', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__( 'No', 'avantage' ) => 'no',
				esc_html__( 'Yes', 'avantage' ) => 'yes'
			)
		),
	));
}

function avantage_bt_bb_column_inner_class( $class, $atts ) {
	if ( isset( $atts['highlight'] ) && $atts['highlight'] == 'yes' ) {
		$class[] = 'bt_bb_highlight';
	}
	
	return $class;
}

function avantage_bt_bb_column_inner_style( $style_attr, $atts ) {
	if ( isset( $atts['background_position'] ) && $atts['background_position'] != '' ) {
		$style_attr = $style_attr . '--background-inner-position:' . $atts['background_position'] . ';';
	}
	if ( isset( $atts['background_size'] ) && $atts['background_size'] != '' ) {
		$style_attr = $style_attr . '--background-inner-size:' . $atts['background_size'] . ';';
	}
	if ( isset( $atts['inner_background_position'] ) && $atts['inner_background_position'] != '' ) {
		$style_attr = $style_attr . '--inner-background-inner-position:' . $atts['inner_background_position'] . ';';
	}
	if ( isset( $atts['inner_background_size'] ) && $atts['inner_background_size'] != '' ) {
		$style_attr = $style_attr . '--inner-background-inner-size:' . $atts['inner_background_size'] . ';';
	}

	return $style_attr;
}

add_filter( 'bt_bb_column_inner_class', 'avantage_bt_bb_column_inner_class', 10, 2 );
add_filter( 'bt_bb_column_inner_style', 'avantage_bt_bb_column_inner_style', 10, 2 );


// BUTTONS - shape
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_button', 'style' );
	bt_bb_remove_params( 'bt_bb_button', 'shape' );
}
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_button', array(		
		array( 'param_name' => 'style', 'type' => 'dropdown', 'heading' => esc_html__( 'Style', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__( 'Outline', 'avantage' ) => 'outline',
				esc_html__( 'Filled', 'avantage' ) => 'filled',
				esc_html__( 'Clean', 'avantage' ) => 'clean',
				esc_html__( 'Lined', 'avantage' ) => 'lined'
			)
		),
		array( 'param_name' => 'shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Shape', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('Inherit', 'avantage' ) => 'inherit',
				esc_html__('Square', 'avantage' ) => 'square',
				esc_html__('Rounded', 'avantage' ) => 'rounded',
				esc_html__('Round', 'avantage' ) => 'round',
				esc_html__('Slanted Right', 'avantage' ) => 'slanted_right',
				esc_html__('Slanted Left', 'avantage' ) => 'slanted_left',
				esc_html__( 'Lined', 'avantage' ) => 'lined'
			)
		),
	));
}


// CONTENT SLIDER - new: dots_style, arrows_style, arrows_position
// edited: show_dots, gap
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_content_slider', 'arrows_size' );
	bt_bb_remove_params( 'bt_bb_content_slider', 'show_dots' );
	bt_bb_remove_params( 'bt_bb_content_slider', 'gap' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_content_slider', array(
		array( 'param_name' => 'arrows_size', 'type' => 'dropdown', 'preview' => true, 'default' => 'normal', 'heading' => esc_html__( 'Navigation arrows size', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('No arrows', 'avantage' ) => 'no_arrows',
				esc_html__('Small', 'avantage' ) => 'small',
				esc_html__('Normal', 'avantage' ) => 'normal',
				esc_html__('Large', 'avantage' ) => 'large'
			)
		),
		array( 'param_name' => 'arrows_style', 'type' => 'dropdown', 'preview' => true, 'default' => 'normal', 'heading' => esc_html__( 'Navigation arrows style', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('Default', 'avantage' ) => '',
				esc_html__('Transparent background, light arrow', 'avantage' ) => 'transparent_light',
				esc_html__('Transparent background, dark arrow', 'avantage' ) => 'transparent_dark',
				esc_html__('Accent background, light arrow', 'avantage' ) => 'accent_light',
				esc_html__('Accent background, dark arrow', 'avantage' ) => 'accent_dark',
				esc_html__('Alternate background, light arrow', 'avantage' ) => 'alternate_light',
				esc_html__('Alternate background, dark arrow', 'avantage' ) => 'alternate_dark'
			)
		),
		array( 'param_name' => 'arrows_position', 'type' => 'dropdown', 'preview' => true, 'default' => 'normal', 'heading' => esc_html__( 'Navigation arrows position', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('At sides', 'avantage' ) => '',
				esc_html__('From outside, at sides', 'avantage' ) => 'outside',
				esc_html__('Bottom left', 'avantage' ) => 'bottom_left',
				esc_html__('Bottom right', 'avantage' ) => 'bottom_right',
				esc_html__('Below', 'avantage' ) => 'below',
				esc_html__('Below left', 'avantage' ) => 'below_left',
				esc_html__('Below right', 'avantage' ) => 'below_right'
			)
		),
		array( 'param_name' => 'show_dots', 'type' => 'dropdown', 'heading' => esc_html__( 'Dots navigation', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('Bottom', 'avantage' ) => 'bottom',
				esc_html__('Below slider', 'avantage' ) => 'below',
				esc_html__('Left', 'avantage' ) => 'left',
				esc_html__('Right', 'avantage' ) => 'right',
				esc_html__('Hide', 'avantage' ) => 'hide'
			)
		),
		array( 'param_name' => 'dots_style', 'type' => 'dropdown', 'heading' => esc_html__( 'Dots style', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('Inherit', 'avantage' ) => '',
				esc_html__('Accent active dot', 'avantage' ) => 'accent_dot',
				esc_html__('Alternate active dot', 'avantage' ) => 'alternate_dot',
				esc_html__('Light active dot', 'avantage' ) => 'light_dot',
				esc_html__('Dark active dot', 'avantage' ) => 'dark_dot'
			)
		),
		array( 'param_name' => 'gap', 'type' => 'dropdown', 'heading' => esc_html__( 'Gap', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('No gap', 'avantage' ) => 'no_gap',
				esc_html__('Small', 'avantage' ) => 'small',
				esc_html__('Normal', 'avantage' ) => 'normal',
				esc_html__('Large', 'avantage' ) => 'large',
				esc_html__('Extra Large', 'avantage' ) => 'extra_large',
				esc_html__('Huge', 'avantage' ) => 'huge'
			)
		),
	));
}

function avantage_bt_bb_content_slider_class( $class, $atts ) {
	if ( isset( $atts['dots_style'] ) && $atts['dots_style'] != '' ) {
		$class[] = 'bt_bb_dots_style_' . $atts['dots_style'];
	}
	if ( isset( $atts['arrows_style'] ) && $atts['arrows_style'] != '' ) {
		$class[] = 'bt_bb_arrows_style' . '_' . $atts['arrows_style'];
	}
	if ( isset( $atts['arrows_position'] ) && $atts['arrows_position'] != '' ) {
		$class[] = 'bt_bb_arrows_position' . '_' . $atts['arrows_position'];
	}
	return $class;
}
add_filter( 'bt_bb_content_slider_class', 'avantage_bt_bb_content_slider_class', 10, 2 );


// HEADLINE - font_weight, semitransparent_text
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_headline', 'font_weight' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_headline', array(
		array( 'param_name' => 'font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Font weight', 'avantage' ), 'group' => esc_html__( 'Font', 'avantage' ),
			'value' => array(
				esc_html__( 'Default', 'avantage' ) => '',
				esc_html__( 'Normal', 'avantage' ) => 'normal',
				esc_html__( 'Bold', 'avantage' ) => 'bold',
				esc_html__( 'Bolder', 'avantage' ) => 'bolder',
				esc_html__( 'Lighter', 'avantage' ) => 'lighter',
				esc_html__( 'Light', 'avantage' ) => 'light',
				esc_html__( 'Thin', 'avantage' ) => 'thin',
				esc_html__( 'Font weight 100', 'avantage' ) => '100',
				esc_html__( 'Font weight 200', 'avantage' ) => '200',
				esc_html__( 'Font weight 300', 'avantage' ) => '300',
				esc_html__( 'Font weight 400', 'avantage' ) => '400',
				esc_html__( 'Font weight 500', 'avantage' ) => '500',
				esc_html__( 'Font weight 600', 'avantage' ) => '600',
				esc_html__( 'Font weight 700', 'avantage' ) => '700',
				esc_html__( 'Font weight 800', 'avantage' ) => '800',
				esc_html__( 'Font weight 900', 'avantage' ) => '900',
			)
		),
		array( 'param_name' => 'semitransparent_text', 'type' => 'checkbox', 'value' => array( esc_html__( 'Yes', 'avantage' ) => 'true' ), 'heading' => esc_html__( 'Semitransparent text', 'avantage' ), 'preview' => true, 'group' => esc_html__( 'Design', 'avantage' ),
		),
	));
}

function avantage_bt_bb_headline_class( $class, $atts ) {
	if ( isset( $atts['semitransparent_text'] ) && $atts['semitransparent_text'] != '' ) {
		$class[] = ' bt_bb_semitransparent_subheadline';
	}
	
	return $class;
}
add_filter( 'bt_bb_headline_class', 'avantage_bt_bb_headline_class', 10, 2 );


// IMAGE - new: fill_background_color
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_image', array(		
		array( 'param_name' => 'fill_background_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Fill background color', 'avantage' ),'group' => esc_html__( 'Content', 'avantage' ) ,
			'value' => array(
				esc_html__( 'Full', 'avantage' ) => 'full',
				esc_html__( 'Match content height', 'avantage' ) => 'match_content_height'
			)
		),

		array( 'param_name' => 'top_negative_margin', 'type' => 'dropdown', 'group' => esc_html__( 'Margin', 'avantage' ), 'heading' => esc_html__( 'Top negative margin', 'avantage' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'avantage' ) 		=> 'none',
				esc_html__( '10px', 'avantage' ) 			=> '10',
				esc_html__( '20px', 'avantage' ) 			=> '20',
				esc_html__( '30px', 'avantage' ) 			=> '30',
				esc_html__( '40px', 'avantage' ) 			=> '40',
				esc_html__( '50px', 'avantage' ) 			=> '50',
				esc_html__( '60px', 'avantage' ) 			=> '50',
				esc_html__( '70px', 'avantage' ) 			=> '50',
				esc_html__( '80px', 'avantage' ) 			=> '50',
				esc_html__( '90px', 'avantage' ) 			=> '90',
				esc_html__( '100px', 'avantage' ) 			=> '100',
				esc_html__( '200px', 'avantage' ) 			=> '200'
			)
		),
		array( 'param_name' => 'bottom_negative_margin', 'type' => 'dropdown', 'group' => esc_html__( 'Margin', 'avantage' ), 'heading' => esc_html__( 'Bottom negative margin', 'avantage' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'avantage' ) 		=> 'none',
				esc_html__( '10px', 'avantage' ) 			=> '10',
				esc_html__( '20px', 'avantage' ) 			=> '20',
				esc_html__( '30px', 'avantage' ) 			=> '30',
				esc_html__( '40px', 'avantage' ) 			=> '40',
				esc_html__( '50px', 'avantage' ) 			=> '50',
				esc_html__( '60px', 'avantage' ) 			=> '50',
				esc_html__( '70px', 'avantage' ) 			=> '50',
				esc_html__( '80px', 'avantage' ) 			=> '50',
				esc_html__( '90px', 'avantage' ) 			=> '90',
				esc_html__( '100px', 'avantage' ) 			=> '100',
				esc_html__( '200px', 'avantage' ) 			=> '200'
			)
		),
		array( 'param_name' => 'right_negative_margin', 'type' => 'dropdown', 'group' => esc_html__( 'Margin', 'avantage' ), 'heading' => esc_html__( 'Right negative margin', 'avantage' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'avantage' ) 		=> 'none',
				esc_html__( '10px', 'avantage' ) 			=> '10',
				esc_html__( '20px', 'avantage' ) 			=> '20',
				esc_html__( '30px', 'avantage' ) 			=> '30',
				esc_html__( '40px', 'avantage' ) 			=> '40',
				esc_html__( '50px', 'avantage' ) 			=> '50',
				esc_html__( '60px', 'avantage' ) 			=> '50',
				esc_html__( '70px', 'avantage' ) 			=> '50',
				esc_html__( '80px', 'avantage' ) 			=> '50',
				esc_html__( '90px', 'avantage' ) 			=> '90',
				esc_html__( '100px', 'avantage' ) 			=> '100',
				esc_html__( '200px', 'avantage' ) 			=> '200'
			)
		),
		array( 'param_name' => 'left_negative_margin', 'type' => 'dropdown', 'group' => esc_html__( 'Margin', 'avantage' ), 'heading' => esc_html__( 'Left negative margin', 'avantage' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'avantage' ) 		=> 'none',
				esc_html__( '10px', 'avantage' ) 			=> '10',
				esc_html__( '20px', 'avantage' ) 			=> '20',
				esc_html__( '30px', 'avantage' ) 			=> '30',
				esc_html__( '40px', 'avantage' ) 			=> '40',
				esc_html__( '50px', 'avantage' ) 			=> '50',
				esc_html__( '60px', 'avantage' ) 			=> '50',
				esc_html__( '70px', 'avantage' ) 			=> '50',
				esc_html__( '80px', 'avantage' ) 			=> '50',
				esc_html__( '90px', 'avantage' ) 			=> '90',
				esc_html__( '100px', 'avantage' ) 			=> '100',
				esc_html__( '200px', 'avantage' ) 			=> '200'
			)
		),
	));
}

add_filter( 'bt_bb_image_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'top_negative_margin';
	return $params;
});

add_filter( 'bt_bb_image_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'bottom_negative_margin';
	return $params;
});

add_filter( 'bt_bb_image_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'right_negative_margin';
	return $params;
});

add_filter( 'bt_bb_image_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'left_negative_margin';
	return $params;
});

function avantage_bt_bb_image_class( $class, $atts ) {
	if ( isset( $atts['fill_background_color'] ) && $atts['fill_background_color'] != '' ) {
		$class[] = 'bt_bb_fill_background_color' . '_' . $atts['fill_background_color'];
	}
	
	return $class;
}
add_filter( 'bt_bb_image_class', 'avantage_bt_bb_image_class', 10, 2 );



// IMAGE SLIDER - new: dots_style, arrows_size, arrows_style, arrows_position; 
// deleted: size, pause_on_hover, use_lightbox; changed: show_dots
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_slider', 'size' );
	bt_bb_remove_params( 'bt_bb_slider', 'pause_on_hover' );
	bt_bb_remove_params( 'bt_bb_slider', 'use_lightbox' );
	bt_bb_remove_params( 'bt_bb_slider', 'show_dots' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_slider', array(
		array( 'param_name' => 'show_dots', 'type' => 'dropdown', 'heading' => esc_html__( 'Dots navigation', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('Bottom', 'avantage' ) => 'bottom',
				esc_html__('Below', 'avantage' ) => 'below',
				esc_html__('Left', 'avantage' ) => 'left',
				esc_html__('Right', 'avantage' ) => 'right',
				esc_html__('Hide', 'avantage' ) => 'hide'
			)
		),
		array( 'param_name' => 'dots_style', 'type' => 'dropdown', 'heading' => esc_html__( 'Dots style', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('Inherit', 'avantage' ) => '',
				esc_html__('Accent active dot', 'avantage' ) => 'accent_dot',
				esc_html__('Alternate active dot', 'avantage' ) => 'alternate_dot',
				esc_html__('Light active dot', 'avantage' ) => 'light_dot',
				esc_html__('Dark active dot', 'avantage' ) => 'dark_dot'
			)
		),		
		array( 'param_name' => 'arrows_size', 'type' => 'dropdown', 'preview' => true, 'default' => 'normal', 'heading' => esc_html__( 'Navigation arrows size', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('Small', 'avantage' ) => 'small',
				esc_html__('Normal', 'avantage' ) => 'normal',
				esc_html__('Large', 'avantage' ) => 'large'
			)
		),
		array( 'param_name' => 'arrows_style', 'type' => 'dropdown', 'preview' => true, 'default' => 'normal', 'heading' => esc_html__( 'Navigation arrows style', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('Default', 'avantage' ) => '',
				esc_html__('Transparent background, light arrow', 'avantage' ) => 'transparent_light',
				esc_html__('Transparent background, dark arrow', 'avantage' ) => 'transparent_dark',
				esc_html__('Accent background, light arrow', 'avantage' ) => 'accent_light',
				esc_html__('Accent background, dark arrow', 'avantage' ) => 'accent_dark',
				esc_html__('Alternate background, light arrow', 'avantage' ) => 'alternate_light',
				esc_html__('Alternate background, dark arrow', 'avantage' ) => 'alternate_dark'
			)
		),
		array( 'param_name' => 'arrows_position', 'type' => 'dropdown', 'preview' => true, 'default' => 'normal', 'heading' => esc_html__( 'Navigation arrows position', 'avantage' ), 'group' => esc_html__( 'Design', 'avantage' ),
			'value' => array(
				esc_html__('At sides', 'avantage' ) => '',
				esc_html__('From outside, at sides', 'avantage' ) => 'outside',
				esc_html__('Bottom left', 'avantage' ) => 'bottom_left',
				esc_html__('Bottom right', 'avantage' ) => 'bottom_right',
				esc_html__('Below', 'avantage' ) => 'below',
				esc_html__('Below left', 'avantage' ) => 'below_left',
				esc_html__('Below right', 'avantage' ) => 'below_right'
			)
		),				
	));
}

function avantage_bt_bb_slider_class( $class, $atts ) {
	if ( isset( $atts['dots_style'] ) && $atts['dots_style'] != '' ) {
		$class[] = 'bt_bb_dots_style_' . $atts['dots_style'];
	}
	if ( isset( $atts['arrows_size'] ) && $atts['arrows_size'] != '' ) {
		$class[] = 'bt_bb_arrows_size' . '_' . $atts['arrows_size'];
	}

	if ( isset( $atts['arrows_style'] ) && $atts['arrows_style'] != '' ) {
		$class[] = 'bt_bb_arrows_style' . '_' . $atts['arrows_style'];
	}

	if ( isset( $atts['arrows_position'] ) && $atts['arrows_position'] != '' ) {
		$class[] = 'bt_bb_arrows_position' . '_' . $atts['arrows_position'];
	}

	return $class;
}
add_filter( 'bt_bb_slider_class', 'avantage_bt_bb_slider_class', 10, 2 );


// CONTENT SLIDER ITEM - new: show_boxed_content
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_content_slider_item', array(	
		array( 'param_name' => 'show_boxed_content', 'type' => 'dropdown', 'default' => 'no', 'heading' => esc_html__( 'Box column content - used to stretch or box column content, only applicable for one and two column layouts, for sliders in wide sections.', 'avantage' ),
			'value' => array(
				esc_html__( 'No', 'avantage' ) => 'no',
				esc_html__( 'Box both columns', 'avantage' ) => 'yes',
				esc_html__( 'Box left column', 'avantage' ) => 'left',
				esc_html__( 'Box right column', 'avantage' ) => 'right'
			)
		)
	));
}

function avantage_bt_bb_content_slider_item_class( $class, $atts ) {
	if ( isset( $atts['show_boxed_content'] ) && $atts['show_boxed_content'] != '' ) {
		if ( $atts['show_boxed_content'] == 'yes' ) {
				$class[] = 'bt_bb_show_boxed_content';
		}
		if ( $atts['show_boxed_content'] == 'left' ) {
				$class[] = 'bt_bb_show_left_boxed_content';
		}
		if ( $atts['show_boxed_content'] == 'right' ) {
				$class[] = 'bt_bb_show_right_boxed_content';
		}

	}
	return $class;
}
add_filter( 'bt_bb_content_slider_item_class', 'avantage_bt_bb_content_slider_item_class', 10, 2 );



/* FRONT END 
---------------------------------------------------------- */

/* OLD ELEMENTS */
function bt_bb_fe_new_params( $elements_array) {

	$elements_array[ 'bt_bb_icon' ][ 'params' ][ 'vertical_position' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_icon' ][ 'params' ][ 'colored_icon_color_scheme' ] = array( 'ajax_filter' => array( 'class', 'style' ) );

	$elements_array[ 'bt_bb_latest_posts' ][ 'params' ][ 'look' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_latest_posts' ][ 'params' ][ 'show_dash' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_latest_posts' ][ 'params' ][ 'date_design' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'icon' ] = array( 'js_handler' => array( 'target_selector' => '.bt_bb_price_list_price .bt_bb_price_list_details', 'type' => 'inner_html' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'align' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'size' ] = array();
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'style' ] = array();
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'shape' ] = array();
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'colored_icon' ] = array();
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'colored_icon_color_scheme' ] = array( 'ajax_filter' => array( 'class', 'style' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'vertical_position' ] = array();

	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'colored_icon' ] = array();
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'colored_icon_color_scheme' ] = array( 'ajax_filter' => array( 'class', 'style' ) );
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'semitransparent_text' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'highlight' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'vertical_align' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'font_weight' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_headline' ][ 'params' ][ 'semitransparent_text' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_image' ][ 'params' ][ 'fill_background_color' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_section' ][ 'params' ][ 'show_boxed_content' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_section' ][ 'params' ][ 'allow_content_outside' ] = array( 'ajax_filter' => array( 'class' ) );


    return $elements_array;
}
add_filter( 'bt_bb_fe_elements', 'bt_bb_fe_new_params' );


/* ADD NEW ELEMENTS */
function avantage_bt_bb_fe_templates( $templates ) {

	$templates[ 'splitted_headline' ] = array(
		'base' 			=> esc_html__( 'bt_bb_splitted_headline', 'avantage' ),
		'name' 			=> esc_html__( 'Split Headline', 'avantage' ),
		'description' 	=> esc_html__( 'Headline with custom Google fonts', 'avantage' ),
	);

	return $templates;
}

add_filter( 'bt_bb_fe_templates', 'avantage_bt_bb_fe_templates' );
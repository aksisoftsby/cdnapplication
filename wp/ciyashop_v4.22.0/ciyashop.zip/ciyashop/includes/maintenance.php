<?php
/**
 * Check to see if the current page is the login/register page
 * Use this in conjunction with is_admin() to separate the front-end from the back-end of your theme
 *
 * @return bool
 * @package CiyaShop
 */

if ( ! function_exists( 'ciyashop_is_login_page' ) ) {
	/**
	 * Ciyashop is login page
	 */
	function ciyashop_is_login_page() {
		return in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ), true ) || ( 'index.php' === $GLOBALS['pagenow'] && strpos( $_SERVER['REQUEST_URI'], 'wp-register.php' ) !== false );
	}
}

/***
 * Allow access to site even site is under maintenance.
 */
function ciyashop_access_allowed_under_maintenance() {
	global $ciyashop_options;

	$access_allowed = false;

	if ( defined( 'WP_CLI' ) ) {
		$access_allowed = true;
	}

	if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
		$access_allowed = true;
	}

	if ( ciyashop_is_login_page() ) {
		$access_allowed = true;
	}

	if ( is_admin() ) {
		$access_allowed = true;
	}

	if ( is_user_logged_in() ) {
		$allowed_roles_k = 'comingsoon_allowed_user_roles';
		$allowed_roles   = ( isset( $ciyashop_options[ $allowed_roles_k ] ) && ! empty( $ciyashop_options[ $allowed_roles_k ] ) ) ? $ciyashop_options[ $allowed_roles_k ] : array();
		$current_user    = wp_get_current_user();

		if ( ! empty( array_intersect( $current_user->roles, $allowed_roles ) ) ) {
			$access_allowed = true;
		}

		if (
			( current_user_can( 'administrator' ) )
			|| current_user_can( 'manage_network' )
		) {
			$access_allowed = true;
		}
	}

	$access_allowed = apply_filters( 'ciyashop_access_allowed_under_maintenance', $access_allowed );

	return $access_allowed;
}

/**
 * Check if site is in undermaintatance.
 */
function ciyashop_under_maintenance() {
	$access_allowed = ciyashop_access_allowed_under_maintenance();
	if ( $access_allowed ) {
		return;
	}

	/**
	 * Fires before maintenance content.
	 *
	 * @visible true
	 */
	do_action( 'ciyashop_maintenance_before' );

	$is_maintenance_enabled = ciyashop_is_maintenance_enabled();

	if ( $is_maintenance_enabled ) {
		do_action( 'ciyashop_before_maintenance_content' );

		$maintenance_mode = ciyashop_get_maintenance_mode();

		get_template_part( 'template-parts/maintenance/maintenance' );

		do_action( 'ciyashop_after_maintenance_content' );
		exit();
	}
}
add_action( 'wp_loaded', 'ciyashop_under_maintenance', 21 );

function ciyashop_maintenance_body_class_callback() {
	add_filter( 'body_class', 'ciyashop_maintenance_body_class' );
}
add_action( 'ciyashop_before_maintenance_content', 'ciyashop_maintenance_body_class_callback' );

/**
 * Ciyashop maintenance body class
 *
 * @param string $classes .
 */
function ciyashop_maintenance_body_class( $classes ) {
	$access_allowed = ciyashop_access_allowed_under_maintenance();
	if ( $access_allowed ) {
		return;
	}

	$is_maintenance_enabled = ciyashop_is_maintenance_enabled();

	if ( $is_maintenance_enabled ) {

		$maintenance_mode = ciyashop_get_maintenance_mode();

		$classes[] = 'tc_maintenance';
		$classes[] = 'tc_maintenance_mode-' . $maintenance_mode;
	}

	return $classes;
}

function ciyashop_is_maintenance_enabled() {
	global $ciyashop_options;

	$is_maintenance_enabled = isset( $ciyashop_options['enable_maintenance'] ) ? $ciyashop_options['enable_maintenance'] : 0;
	$is_maintenance_enabled = filter_var( $is_maintenance_enabled, FILTER_VALIDATE_BOOLEAN );
	$is_maintenance_enabled = apply_filters( 'ciyashop_is_maintenance_enabled', $is_maintenance_enabled );

	return $is_maintenance_enabled;
}

function ciyashop_get_maintenance_mode() {
	global $ciyashop_options;

	$maintenance_mode = isset( $ciyashop_options['maintenance_mode'] ) && in_array( $ciyashop_options['maintenance_mode'], array( 'maintenance', 'comingsoon' ), true ) ? $ciyashop_options['maintenance_mode'] : 'maintenance';
	$maintenance_mode = apply_filters( 'ciyashop_get_maintenance_mode', $maintenance_mode );

	return $maintenance_mode;
}

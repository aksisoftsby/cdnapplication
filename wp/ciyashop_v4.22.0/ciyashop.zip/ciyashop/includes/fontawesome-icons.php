<?php
if ( ! function_exists( 'ciyashop_fontawesome_icons' ) ) {
	function ciyashop_fontawesome_icons() {
		$fontawesome_icons = array(
			'Accessibility' => array(
				array(
					'fab fa-accessible-icon' => 'Accessible Icon (accessibility,handicap,person,wheelchair,wheelchair-alt)',
				),
				array(
					'fas fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'far fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'fas fa-audio-description' => 'Audio Description (blind,narration,video,visual)',
				),
				array(
					'fas fa-braille' => 'Braille (alphabet,blind,dots,raised,vision)',
				),
				array(
					'fas fa-circle-info' => 'Circle Info (info-circle,details,help,information,more,support)',
				),
				array(
					'fas fa-circle-question' => 'Circle Question (question-circle,help,information,support,unknown)',
				),
				array(
					'far fa-circle-question' => 'Circle Question (question-circle,help,information,support,unknown)',
				),
				array(
					'fas fa-closed-captioning' => 'Closed Captioning (cc,deaf,hearing,subtitle,subtitling,text,video)',
				),
				array(
					'far fa-closed-captioning' => 'Closed Captioning (cc,deaf,hearing,subtitle,subtitling,text,video)',
				),
				array(
					'fas fa-ear-deaf' => 'Ear Deaf (deaf,deafness,hard-of-hearing,ear,hearing,sign language)',
				),
				array(
					'fas fa-ear-listen' => 'Ear Listen (assistive-listening-systems,amplify,audio,deaf,ear,headset,hearing,sound)',
				),
				array(
					'fas fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'far fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'fas fa-eye-low-vision' => 'Eye Low Vision (low-vision,blind,eye,sight)',
				),
				array(
					'fas fa-fingerprint' => 'Fingerprint (human,id,identification,lock,smudge,touch,unique,unlock)',
				),
				array(
					'fas fa-hands' => 'Hands (sign-language,signing,Translate,asl,deaf,hands)',
				),
				array(
					'fas fa-hands-asl-interpreting' => 'Hands Asl Interpreting (american-sign-language-interpreting,asl-interpreting,hands-american-sign-language-interpreting,asl,deaf,finger,hand,interpret,speak)',
				),
				array(
					'fas fa-handshake-angle' => 'Handshake Angle (hands-helping,aid,assistance,handshake,partnership,volunteering)',
				),
				array(
					'fas fa-person-cane' => 'Person Cane (aging,cane,elderly,old,staff)',
				),
				array(
					'fas fa-person-walking-with-cane' => 'Person Walking With Cane (blind,blind,cane)',
				),
				array(
					'fas fa-phone-volume' => 'Phone Volume (volume-control-phone,call,earphone,number,sound,support,telephone,voice,volume-control-phone)',
				),
				array(
					'fas fa-question' => 'Question (?,Question Mark,help,information,mark,outlined,punctuation,question,red question mark,support,unknown,white question mark)',
				),
				array(
					'fas fa-tty' => 'Tty (teletype,communication,deaf,telephone,teletypewriter,text)',
				),
				array(
					'fas fa-universal-access' => 'Universal Access (users-people)',
				),
				array(
					'fas fa-wheelchair' => 'Wheelchair (users-people)',
				),
				array(
					'fas fa-wheelchair-move' => 'Wheelchair Move (wheelchair-alt,access,handicap,impairment,physical,wheelchair symbol)',
				),
			),
			'Alert' => array(
				array(
					'fas fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'far fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'fas fa-bell-slash' => 'Bell Slash (alert,bell,bell with slash,cancel,disabled,forbidden,mute,notification,off,quiet,reminder,silent)',
				),
				array(
					'far fa-bell-slash' => 'Bell Slash (alert,bell,bell with slash,cancel,disabled,forbidden,mute,notification,off,quiet,reminder,silent)',
				),
				array(
					'fas fa-circle-exclamation' => 'Circle Exclamation (exclamation-circle,affect,alert,damage,danger,error,important,notice,notification,notify,problem,warning)',
				),
				array(
					'fas fa-circle-radiation' => 'Circle Radiation (radiation-alt,danger,dangerous,deadly,hazard,nuclear,radioactive,sign,warning)',
				),
				array(
					'fas fa-exclamation' => 'Exclamation (!,Exclamation Mark,alert,danger,error,exclamation,important,mark,notice,notification,notify,outlined,problem,punctuation,red exclamation mark,warning,white exclamation mark)',
				),
				array(
					'fas fa-question' => 'Question (?,Question Mark,help,information,mark,outlined,punctuation,question,red question mark,support,unknown,white question mark)',
				),
				array(
					'fas fa-radiation' => 'Radiation (danger,dangerous,deadly,hazard,nuclear,radioactive,warning)',
				),
				array(
					'fas fa-skull-crossbones' => 'Skull Crossbones (Black Skull and Crossbones,Dungeons & Dragons,alert,bones,crossbones,d&d,danger,dangerous area,dead,deadly,death,dnd,face,fantasy,halloween,holiday,jolly-roger,monster,pirate,poison,skeleton,skull,skull and crossbones,warning)',
				),
				array(
					'fas fa-triangle-exclamation' => 'Triangle Exclamation (exclamation-triangle,warning,alert,danger,error,important,notice,notification,notify,problem,warnin,warning)',
				),
			),
			'Alphabet' => array(
				array(
					'fas fa-a' => 'A (Latin Capital Letter A,Latin Small Letter A,letter)',
				),
				array(
					'fas fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'far fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'fas fa-b' => 'B (Latin Capital Letter B,Latin Small Letter B,letter)',
				),
				array(
					'fas fa-c' => 'C (Latin Capital Letter C,Latin Small Letter C,letter)',
				),
				array(
					'fas fa-circle-h' => 'Circle H (hospital-symbol,Circled Latin Capital Letter H,clinic,covid-19,emergency,letter,map)',
				),
				array(
					'fas fa-d' => 'D (Latin Capital Letter D,Latin Small Letter D,letter)',
				),
				array(
					'fas fa-e' => 'E (Latin Capital Letter E,Latin Small Letter E,letter)',
				),
				array(
					'fas fa-f' => 'F (Latin Capital Letter F,Latin Small Letter F,letter)',
				),
				array(
					'fas fa-g' => 'G (Latin Capital Letter G,Latin Small Letter G,letter)',
				),
				array(
					'fas fa-h' => 'H (Latin Capital Letter H,Latin Small Letter H,letter)',
				),
				array(
					'fas fa-i' => 'I (Latin Capital Letter I,Latin Small Letter I,letter)',
				),
				array(
					'fas fa-j' => 'J (Latin Capital Letter J,Latin Small Letter J,letter)',
				),
				array(
					'fas fa-k' => 'K (Latin Capital Letter K,Latin Small Letter K,letter)',
				),
				array(
					'fas fa-l' => 'L (Latin Capital Letter L,Latin Small Letter L,letter)',
				),
				array(
					'fas fa-m' => 'M (Latin Capital Letter M,Latin Small Letter M,letter)',
				),
				array(
					'fas fa-n' => 'N (Latin Capital Letter N,Latin Small Letter N,letter,nay,no)',
				),
				array(
					'fas fa-o' => 'O (Latin Capital Letter O,Latin Small Letter O,letter)',
				),
				array(
					'fas fa-p' => 'P (Latin Capital Letter P,Latin Small Letter P,letter)',
				),
				array(
					'fas fa-q' => 'Q (Latin Capital Letter Q,Latin Small Letter Q,letter)',
				),
				array(
					'fas fa-r' => 'R (Latin Capital Letter R,Latin Small Letter R,letter)',
				),
				array(
					'fas fa-s' => 'S (Latin Capital Letter S,Latin Small Letter S,letter)',
				),
				array(
					'fas fa-square-h' => 'Square H (h-square,directions,emergency,hospital,hotel,letter,map)',
				),
				array(
					'fas fa-t' => 'T (Latin Capital Letter T,Latin Small Letter T,letter)',
				),
				array(
					'fas fa-u' => 'U (Latin Capital Letter U,Latin Small Letter U,letter)',
				),
				array(
					'fas fa-v' => 'V (Latin Capital Letter V,Latin Small Letter V,letter)',
				),
				array(
					'fas fa-w' => 'W (Latin Capital Letter W,Latin Small Letter W,letter)',
				),
				array(
					'fas fa-x' => 'X (Latin Capital Letter X,Latin Small Letter X,letter)',
				),
				array(
					'fas fa-y' => 'Y (Latin Capital Letter Y,Latin Small Letter Y,letter,yay,yes)',
				),
				array(
					'fas fa-z' => 'Z (Latin Capital Letter Z,Latin Small Letter Z,letter)',
				),
			),
			'Animals' => array(
				array(
					'fas fa-bugs' => 'Bugs (bedbug,infestation,lice,plague,ticks)',
				),
				array(
					'fas fa-cat' => 'Cat (cat,feline,halloween,holiday,kitten,kitty,meow,pet)',
				),
				array(
					'fas fa-cow' => 'Cow (agriculture,animal,beef,bovine,co,cow,farm,fauna,livestock,mammal,milk,moo)',
				),
				array(
					'fas fa-crow' => 'Crow (bird,bullfrog,fauna,halloween,holiday,toad)',
				),
				array(
					'fas fa-dog' => 'Dog (animal,canine,dog,fauna,mammal,pet,pooch,puppy,woof)',
				),
				array(
					'fas fa-dove' => 'Dove (bird,dove,fauna,fly,flying,peace,war)',
				),
				array(
					'fas fa-dragon' => 'Dragon (Dungeons & Dragons,d&d,dnd,dragon,fairy tale,fantasy,fire,lizard,serpent)',
				),
				array(
					'fas fa-feather' => 'Feather (bird,feather,flight,light,plucked,plumage,quill,write)',
				),
				array(
					'fas fa-feather-pointed' => 'Feather Pointed (feather-alt,bird,light,plucked,quill,write)',
				),
				array(
					'fas fa-fish' => 'Fish (Pisces,fauna,fish,gold,seafood,swimming,zodiac)',
				),
				array(
					'fas fa-fish-fins' => 'Fish Fins (fish,fishery,pisces,seafood)',
				),
				array(
					'fas fa-frog' => 'Frog (amphibian,bullfrog,fauna,hop,kermit,kiss,prince,ribbit,toad,wart)',
				),
				array(
					'fas fa-hippo' => 'Hippo (animal,fauna,hippo,hippopotamus,hungry,mammal)',
				),
				array(
					'fas fa-horse' => 'Horse (equestrian,equus,fauna,horse,mammmal,mare,neigh,pony,racehorse,racing)',
				),
				array(
					'fas fa-horse-head' => 'Horse Head (equus,fauna,mammmal,mare,neigh,pony)',
				),
				array(
					'fas fa-kiwi-bird' => 'Kiwi Bird (bird,fauna,new zealand)',
				),
				array(
					'fas fa-locust' => 'Locust (horde,infestation,locust,plague,swarm)',
				),
				array(
					'fas fa-mosquito' => 'Mosquito (bite,bug,mosquito,west nile)',
				),
				array(
					'fas fa-otter' => 'Otter (animal,badger,fauna,fishing,fur,mammal,marten,otter,playful)',
				),
				array(
					'fas fa-paw' => 'Paw (animal,cat,dog,pet,print)',
				),
				array(
					'fas fa-shield-cat' => 'Shield Cat (animal,feline,pet,protect,safety,veterinary)',
				),
				array(
					'fas fa-shield-dog' => 'Shield Dog (animal,canine,pet,protect,safety,veterinary)',
				),
				array(
					'fas fa-shrimp' => 'Shrimp (allergy,crustacean,prawn,seafood,shellfish,shrimp,tail)',
				),
				array(
					'fas fa-spider' => 'Spider (arachnid,bug,charlotte,crawl,eight,halloween,insect,spider)',
				),
				array(
					'fas fa-worm' => 'Worm (dirt,garden,worm,wriggle)',
				),
			),
			'Arrows' => array(
				array(
					'fas fa-angle-down' => 'Angle Down (Down Arrowhead,arrow,caret,download,expand)',
				),
				array(
					'fas fa-angle-left' => 'Angle Left (Single Left-Pointing Angle Quotation Mark,arrow,back,caret,less,previous)',
				),
				array(
					'fas fa-angle-right' => 'Angle Right (Single Right-Pointing Angle Quotation Mark,arrow,care,forward,more,next)',
				),
				array(
					'fas fa-angle-up' => 'Angle Up (Up Arrowhead,arrow,caret,collapse,upload)',
				),
				array(
					'fas fa-angles-down' => 'Angles Down (angle-double-down,arrows,caret,download,expand)',
				),
				array(
					'fas fa-angles-left' => 'Angles Left (angle-double-left,Left-Pointing Double Angle Quotation Mark,arrows,back,caret,laquo,previous,quote)',
				),
				array(
					'fas fa-angles-right' => 'Angles Right (angle-double-right,Right-Pointing Double Angle Quotation Mark,arrows,caret,forward,more,next,quote,raquo)',
				),
				array(
					'fas fa-angles-up' => 'Angles Up (angle-double-up,arrows,caret,collapse,upload)',
				),
				array(
					'fas fa-arrow-down' => 'Arrow Down (Downwards Arrow,download)',
				),
				array(
					'fas fa-arrow-down-1-9' => 'Arrow Down 1 9 (sort-numeric-asc,sort-numeric-down,arrange,filter,numbers,order,sort-numeric-asc)',
				),
				array(
					'fas fa-arrow-down-9-1' => 'Arrow Down 9 1 (sort-numeric-desc,sort-numeric-down-alt,arrange,filter,numbers,order,sort-numeric-asc)',
				),
				array(
					'fas fa-arrow-down-a-z' => 'Arrow Down A Z (sort-alpha-asc,sort-alpha-down,alphabetical,arrange,filter,order,sort-alpha-asc)',
				),
				array(
					'fas fa-arrow-down-long' => 'Arrow Down Long (long-arrow-down,download,long-arrow-down)',
				),
				array(
					'fas fa-arrow-down-short-wide' => 'Arrow Down Short Wide (sort-amount-desc,sort-amount-down-alt,arrange,filter,order,sort-amount-asc)',
				),
				array(
					'fas fa-arrow-down-up-across-line' => 'Arrow Down Up Across Line (border,crossing,transfer)',
				),
				array(
					'fas fa-arrow-down-up-lock' => 'Arrow Down Up Lock (border,closed,crossing,lockdown,quarantine,transfer)',
				),
				array(
					'fas fa-arrow-down-wide-short' => 'Arrow Down Wide Short (sort-amount-asc,sort-amount-down,arrange,filter,number,order,sort-amount-asc)',
				),
				array(
					'fas fa-arrow-down-z-a' => 'Arrow Down Z A (sort-alpha-desc,sort-alpha-down-alt,alphabetical,arrange,filter,order,sort-alpha-asc)',
				),
				array(
					'fas fa-arrow-left' => 'Arrow Left (Leftwards Arrow,back,previous)',
				),
				array(
					'fas fa-arrow-left-long' => 'Arrow Left Long (long-arrow-left,back,long-arrow-left,previous)',
				),
				array(
					'fas fa-arrow-pointer' => 'Arrow Pointer (mouse-pointer,arrow,cursor,select)',
				),
				array(
					'fas fa-arrow-right' => 'Arrow Right (Rightwards Arrow,forward,next)',
				),
				array(
					'fas fa-arrow-right-arrow-left' => 'Arrow Right Arrow Left (exchange,Rightwards Arrow Over Leftwards Arrow,arrow,arrows,reciprocate,return,swap,transfer)',
				),
				array(
					'fas fa-arrow-right-from-bracket' => 'Arrow Right From Bracket (sign-out,arrow,exit,leave,log out,logout)',
				),
				array(
					'fas fa-arrow-right-long' => 'Arrow Right Long (long-arrow-right,forward,long-arrow-right,next)',
				),
				array(
					'fas fa-arrow-right-to-bracket' => 'Arrow Right To Bracket (sign-in,arrow,enter,join,log in,login,sign in,sign up,sign-in,signin,signup)',
				),
				array(
					'fas fa-arrow-rotate-left' => 'Arrow Rotate Left (arrow-left-rotate,arrow-rotate-back,arrow-rotate-backward,undo,Anticlockwise Open Circle Arrow,back,control z,exchange,oops,return,rotate,swap)',
				),
				array(
					'fas fa-arrow-rotate-right' => 'Arrow Rotate Right (arrow-right-rotate,arrow-rotate-forward,redo,Clockwise Open Circle Arrow,forward,refresh,reload,repeat)',
				),
				array(
					'fas fa-arrow-trend-down' => 'Arrow Trend Down (line,stocks,trend)',
				),
				array(
					'fas fa-arrow-trend-up' => 'Arrow Trend Up (line,stocks,trend)',
				),
				array(
					'fas fa-arrow-turn-down' => 'Arrow Turn Down (level-down,arrow)',
				),
				array(
					'fas fa-arrow-turn-up' => 'Arrow Turn Up (level-up,arrow)',
				),
				array(
					'fas fa-arrow-up' => 'Arrow Up (Upwards Arrow,forward,upload)',
				),
				array(
					'fas fa-arrow-up-1-9' => 'Arrow Up 1 9 (sort-numeric-up,arrange,filter,numbers,order,sort-numeric-desc)',
				),
				array(
					'fas fa-arrow-up-9-1' => 'Arrow Up 9 1 (sort-numeric-up-alt,arrange,filter,numbers,order,sort-numeric-desc)',
				),
				array(
					'fas fa-arrow-up-a-z' => 'Arrow Up A Z (sort-alpha-up,alphabetical,arrange,filter,order,sort-alpha-desc)',
				),
				array(
					'fas fa-arrow-up-from-bracket' => 'Arrow Up From Bracket (share,transfer,upload)',
				),
				array(
					'fas fa-arrow-up-long' => 'Arrow Up Long (long-arrow-up,long-arrow-up,upload)',
				),
				array(
					'fas fa-arrow-up-right-dots' => 'Arrow Up Right Dots (growth,increase,population)',
				),
				array(
					'fas fa-arrow-up-right-from-square' => 'Arrow Up Right From Square (external-link,new,open,send,share)',
				),
				array(
					'fas fa-arrow-up-short-wide' => 'Arrow Up Short Wide (sort-amount-up-alt,arrange,filter,order,sort-amount-desc)',
				),
				array(
					'fas fa-arrow-up-wide-short' => 'Arrow Up Wide Short (sort-amount-up,arrange,filter,order,sort-amount-desc)',
				),
				array(
					'fas fa-arrow-up-z-a' => 'Arrow Up Z A (sort-alpha-up-alt,alphabetical,arrange,filter,order,sort-alpha-desc)',
				),
				array(
					'fas fa-arrows-down-to-line' => 'Arrows Down To Line (scale down,sink)',
				),
				array(
					'fas fa-arrows-left-right' => 'Arrows Left Right (arrows-h,expand,horizontal,landscape,resize,wide)',
				),
				array(
					'fas fa-arrows-left-right-to-line' => 'Arrows Left Right To Line (analysis,expand,gap)',
				),
				array(
					'fas fa-arrows-rotate' => 'Arrows Rotate (refresh,sync,Clockwise Right and Left Semicircle Arrows,exchange,refresh,reload,rotate,swap)',
				),
				array(
					'fas fa-arrows-spin' => 'Arrows Spin (cycle,rotate,spin,whirl)',
				),
				array(
					'fas fa-arrows-split-up-and-left' => 'Arrows Split Up And Left (agile,split)',
				),
				array(
					'fas fa-arrows-to-circle' => 'Arrows To Circle (center,concentrate,coordinate,coordination,focal point,focus)',
				),
				array(
					'fas fa-arrows-to-dot' => 'Arrows To Dot (assembly point,center,condense,focus,minimize)',
				),
				array(
					'fas fa-arrows-to-eye' => 'Arrows To Eye (center,coordinated assessment,focus)',
				),
				array(
					'fas fa-arrows-turn-right' => 'Arrows Turn Right (arrows)',
				),
				array(
					'fas fa-arrows-turn-to-dots' => 'Arrows Turn To Dots (destination,nexus)',
				),
				array(
					'fas fa-arrows-up-down' => 'Arrows Up Down (arrows-v,expand,portrait,resize,tall,vertical)',
				),
				array(
					'fas fa-arrows-up-down-left-right' => 'Arrows Up Down Left Right (arrows,arrow,arrows,bigger,enlarge,expand,fullscreen,move,position,reorder,resize)',
				),
				array(
					'fas fa-arrows-up-to-line' => 'Arrows Up To Line (rise,scale up)',
				),
				array(
					'fas fa-caret-down' => 'Caret Down (arrow,dropdown,expand,menu,more,triangle)',
				),
				array(
					'fas fa-caret-left' => 'Caret Left (arrow,back,previous,triangle)',
				),
				array(
					'fas fa-caret-right' => 'Caret Right (arrow,forward,next,triangle)',
				),
				array(
					'fas fa-caret-up' => 'Caret Up (arrow,collapse,triangle)',
				),
				array(
					'fas fa-chevron-down' => 'Chevron Down (arrow,download,expand)',
				),
				array(
					'fas fa-chevron-left' => 'Chevron Left (Left-Pointing Angle Bracket,arrow,back,bracket,previous)',
				),
				array(
					'fas fa-chevron-right' => 'Chevron Right (Right-Pointing Angle Bracket,arrow,bracket,forward,next)',
				),
				array(
					'fas fa-chevron-up' => 'Chevron Up (arrow,collapse,upload)',
				),
				array(
					'fas fa-circle-arrow-down' => 'Circle Arrow Down (arrow-circle-down,download)',
				),
				array(
					'fas fa-circle-arrow-left' => 'Circle Arrow Left (arrow-circle-left,back,previous)',
				),
				array(
					'fas fa-circle-arrow-right' => 'Circle Arrow Right (arrow-circle-right,forward,next)',
				),
				array(
					'fas fa-circle-arrow-up' => 'Circle Arrow Up (arrow-circle-up,upload)',
				),
				array(
					'fas fa-circle-chevron-down' => 'Circle Chevron Down (chevron-circle-down,arrow,download,dropdown,menu,more)',
				),
				array(
					'fas fa-circle-chevron-left' => 'Circle Chevron Left (chevron-circle-left,arrow,back,previous)',
				),
				array(
					'fas fa-circle-chevron-right' => 'Circle Chevron Right (chevron-circle-right,arrow,forward,next)',
				),
				array(
					'fas fa-circle-chevron-up' => 'Circle Chevron Up (chevron-circle-up,arrow,collapse,upload)',
				),
				array(
					'fas fa-circle-down' => 'Circle Down (arrow-alt-circle-down,arrow-circle-o-down,download)',
				),
				array(
					'far fa-circle-down' => 'Circle Down (arrow-alt-circle-down,arrow-circle-o-down,download)',
				),
				array(
					'fas fa-circle-left' => 'Circle Left (arrow-alt-circle-left,arrow-circle-o-left,back,previous)',
				),
				array(
					'far fa-circle-left' => 'Circle Left (arrow-alt-circle-left,arrow-circle-o-left,back,previous)',
				),
				array(
					'fas fa-circle-right' => 'Circle Right (arrow-alt-circle-right,arrow-circle-o-right,forward,next)',
				),
				array(
					'far fa-circle-right' => 'Circle Right (arrow-alt-circle-right,arrow-circle-o-right,forward,next)',
				),
				array(
					'fas fa-circle-up' => 'Circle Up (arrow-alt-circle-up,arrow-circle-o-up)',
				),
				array(
					'far fa-circle-up' => 'Circle Up (arrow-alt-circle-up,arrow-circle-o-up)',
				),
				array(
					'fas fa-clock-rotate-left' => 'Clock Rotate Left (history,Rewind,clock,reverse,time,time machine,time travel)',
				),
				array(
					'fas fa-cloud-arrow-down' => 'Cloud Arrow Down (cloud-download,cloud-download-alt,download,export,save)',
				),
				array(
					'fas fa-cloud-arrow-up' => 'Cloud Arrow Up (cloud-upload,cloud-upload-alt,import,save,upload)',
				),
				array(
					'fas fa-down-left-and-up-right-to-center' => 'Down Left And Up Right To Center (compress-alt,collapse,fullscreen,minimize,move,resize,shrink,smaller)',
				),
				array(
					'fas fa-down-long' => 'Down Long (long-arrow-alt-down,download,long-arrow-down)',
				),
				array(
					'fas fa-download' => 'Download (export,hard drive,save,transfer)',
				),
				array(
					'fas fa-left-long' => 'Left Long (long-arrow-alt-left,back,long-arrow-left,previous)',
				),
				array(
					'fas fa-left-right' => 'Left Right (arrows-alt-h,arrow,arrows-h,expand,horizontal,landscape,left-right arrow,resize,wide)',
				),
				array(
					'fas fa-location-arrow' => 'Location Arrow (address,compass,coordinate,direction,gps,map,navigation,place)',
				),
				array(
					'fas fa-maximize' => 'Maximize (expand-arrows-alt,bigger,enlarge,fullscreen,move,resize)',
				),
				array(
					'fas fa-recycle' => 'Recycle (Recycling Symbol For Generic Materials,Universal Recycling Symbol,Waste,compost,garbage,recycle,recycling symbol,reuse,trash)',
				),
				array(
					'fas fa-repeat' => 'Repeat (arrow,clockwise,flip,reload,repeat,repeat button,rewind,switch)',
				),
				array(
					'fas fa-reply' => 'Reply (mail-reply,mail,message,respond)',
				),
				array(
					'fas fa-reply-all' => 'Reply All (mail-reply-all,mail,message,respond)',
				),
				array(
					'fas fa-retweet' => 'Retweet (refresh,reload,share,swap)',
				),
				array(
					'fas fa-right-from-bracket' => 'Right From Bracket (sign-out-alt,arrow,exit,leave,log out,logout,sign-out)',
				),
				array(
					'fas fa-right-left' => 'Right Left (exchange-alt,arrow,arrows,exchange,reciprocate,return,swap,transfer)',
				),
				array(
					'fas fa-right-long' => 'Right Long (long-arrow-alt-right,forward,long-arrow-right,next)',
				),
				array(
					'fas fa-right-to-bracket' => 'Right To Bracket (sign-in-alt,arrow,enter,join,log in,login,sign in,sign up,sign-in,signin,signup)',
				),
				array(
					'fas fa-rotate' => 'Rotate (sync-alt,anticlockwise,arrow,counterclockwise,counterclockwise arrows button,exchange,refresh,reload,rotate,swap,withershins)',
				),
				array(
					'fas fa-rotate-left' => 'Rotate Left (rotate-back,rotate-backward,undo-alt,back,control z,exchange,oops,return,swap)',
				),
				array(
					'fas fa-rotate-right' => 'Rotate Right (redo-alt,rotate-forward,forward,refresh,reload,repeat)',
				),
				array(
					'fas fa-share' => 'Share (arrow-turn-right,mail-forward,forward,save,send,social)',
				),
				array(
					'fas fa-share-from-square' => 'Share From Square (share-square,forward,save,send,social)',
				),
				array(
					'far fa-share-from-square' => 'Share From Square (share-square,forward,save,send,social)',
				),
				array(
					'fas fa-shuffle' => 'Shuffle (random,arrow,arrows,crossed,shuffle,shuffle tracks button,sort,swap,switch,transfer)',
				),
				array(
					'fas fa-sort' => 'Sort (unsorted,filter,order)',
				),
				array(
					'fas fa-sort-down' => 'Sort Down (sort-desc,arrow,descending,filter,order,sort-desc)',
				),
				array(
					'fas fa-sort-up' => 'Sort Up (sort-asc,arrow,ascending,filter,order,sort-asc)',
				),
				array(
					'fas fa-square-arrow-up-right' => 'Square Arrow Up Right (external-link-square,diagonal,new,open,send,share)',
				),
				array(
					'fas fa-square-caret-down' => 'Square Caret Down (caret-square-down,arrow,caret-square-o-down,dropdown,expand,menu,more,triangle)',
				),
				array(
					'far fa-square-caret-down' => 'Square Caret Down (caret-square-down,arrow,caret-square-o-down,dropdown,expand,menu,more,triangle)',
				),
				array(
					'fas fa-square-caret-left' => 'Square Caret Left (caret-square-left,arrow,back,caret-square-o-left,previous,triangle)',
				),
				array(
					'far fa-square-caret-left' => 'Square Caret Left (caret-square-left,arrow,back,caret-square-o-left,previous,triangle)',
				),
				array(
					'fas fa-square-caret-right' => 'Square Caret Right (caret-square-right,arrow,caret-square-o-right,forward,next,triangle)',
				),
				array(
					'far fa-square-caret-right' => 'Square Caret Right (caret-square-right,arrow,caret-square-o-right,forward,next,triangle)',
				),
				array(
					'fas fa-square-caret-up' => 'Square Caret Up (caret-square-up,arrow,caret-square-o-up,collapse,triangle,upload)',
				),
				array(
					'far fa-square-caret-up' => 'Square Caret Up (caret-square-up,arrow,caret-square-o-up,collapse,triangle,upload)',
				),
				array(
					'fas fa-square-up-right' => 'Square Up Right (external-link-square-alt,arrow,diagonal,direction,external-link-square,intercardinal,new,northeast,open,share,up-right arrow)',
				),
				array(
					'fas fa-turn-down' => 'Turn Down (level-down-alt,arrow,down,level-down,right arrow curving down)',
				),
				array(
					'fas fa-turn-up' => 'Turn Up (level-up-alt,arrow,level-up,right arrow curving up)',
				),
				array(
					'fas fa-up-down' => 'Up Down (arrows-alt-v,Up Down Black Arrow,arrow,arrows-v,expand,portrait,resize,tall,up-down arrow,vertical)',
				),
				array(
					'fas fa-up-down-left-right' => 'Up Down Left Right (arrows-alt,arrow,arrows,bigger,enlarge,expand,fullscreen,move,position,reorder,resize)',
				),
				array(
					'fas fa-up-long' => 'Up Long (long-arrow-alt-up,long-arrow-up,upload)',
				),
				array(
					'fas fa-up-right-and-down-left-from-center' => 'Up Right And Down Left From Center (expand-alt,arrows,bigger,enlarge,fullscreen,resize)',
				),
				array(
					'fas fa-up-right-from-square' => 'Up Right From Square (external-link-alt,external-link,new,open,share)',
				),
				array(
					'fas fa-upload' => 'Upload (hard drive,import,publish)',
				),
			),
			'Astronomy' => array(
				array(
					'fas fa-binoculars' => 'Binoculars (glasses,magnify,scenic,spyglass,view)',
				),
				array(
					'fas fa-globe' => 'Globe (all,coordinates,country,earth,global,globe,globe with meridians,gps,internet,language,localize,location,map,meridians,network,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-meteor' => 'Meteor (armageddon,asteroid,comet,shooting star,space)',
				),
				array(
					'fas fa-moon' => 'Moon (Power Sleep Symbol,contrast,crescent,crescent moon,dark,lunar,moon,night)',
				),
				array(
					'far fa-moon' => 'Moon (Power Sleep Symbol,contrast,crescent,crescent moon,dark,lunar,moon,night)',
				),
				array(
					'fas fa-satellite' => 'Satellite (communications,hardware,orbit,satellite,space)',
				),
				array(
					'fas fa-satellite-dish' => 'Satellite Dish (SETI,antenna,communications,dish,hardware,radar,receiver,satellite,satellite antenna,saucer,signal,space)',
				),
				array(
					'fas fa-shuttle-space' => 'Shuttle Space (space-shuttle,astronaut,machine,nasa,rocket,space,transportation)',
				),
				array(
					'fas fa-user-astronaut' => 'User Astronaut (avatar,clothing,cosmonaut,nasa,space,suit)',
				),
			),
			'Automotive' => array(
				array(
					'fas fa-bus' => 'Bus (bus,oncoming,oncoming bus,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-bus-simple' => 'Bus Simple (bus-alt,mta,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car' => 'Car (automobile,auto,automobile,car,oncoming,oncoming automobile,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car-battery' => 'Car Battery (battery-car,auto,electric,mechanic,power)',
				),
				array(
					'fas fa-car-burst' => 'Car Burst (car-crash,accident,auto,automobile,insurance,sedan,transportation,vehicle,wreck)',
				),
				array(
					'fas fa-car-on' => 'Car On (alarm,car,carjack,warning)',
				),
				array(
					'fas fa-car-rear' => 'Car Rear (car-alt,auto,automobile,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car-side' => 'Car Side (auto,automobile,car,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car-tunnel' => 'Car Tunnel (road,tunnel)',
				),
				array(
					'fas fa-caravan' => 'Caravan (camper,motor home,rv,trailer,travel)',
				),
				array(
					'fas fa-charging-station' => 'Charging Station (electric,ev,tesla,vehicle)',
				),
				array(
					'fas fa-gas-pump' => 'Gas Pump (car,diesel,fuel,fuel pump,fuelpump,gas,gasoline,petrol,pump,station)',
				),
				array(
					'fas fa-gauge' => 'Gauge (dashboard,gauge-med,tachometer-alt-average,dashboard,fast,odometer,speed,speedometer)',
				),
				array(
					'fas fa-gauge-high' => 'Gauge High (tachometer-alt,tachometer-alt-fast,dashboard,fast,odometer,speed,speedometer)',
				),
				array(
					'fas fa-gauge-simple' => 'Gauge Simple (gauge-simple-med,tachometer-average,dashboard,fast,odometer,speed,speedometer)',
				),
				array(
					'fas fa-gauge-simple-high' => 'Gauge Simple High (tachometer,tachometer-fast,dashboard,fast,odometer,speed,speedometer)',
				),
				array(
					'fas fa-motorcycle' => 'Motorcycle (bike,machine,motorcycle,racing,transportation,vehicle)',
				),
				array(
					'fas fa-oil-can' => 'Oil Can (auto,crude,gasoline,grease,lubricate,petroleum)',
				),
				array(
					'fas fa-spray-can-sparkles' => 'Spray Can Sparkles (air-freshener,car,clean,deodorize,fresh,pine,scent)',
				),
				array(
					'fas fa-taxi' => 'Taxi (cab,cab,cabbie,car,car service,lyft,machine,oncoming,oncoming taxi,taxi,transportation,travel,uber,vehicle)',
				),
				array(
					'fas fa-trailer' => 'Trailer (carry,haul,moving,travel)',
				),
				array(
					'fas fa-truck' => 'Truck (Black Truck,cargo,delivery,delivery truck,shipping,truck,vehicle)',
				),
				array(
					'fas fa-truck-field' => 'Truck Field (supplies,truck)',
				),
				array(
					'fas fa-truck-field-un' => 'Truck Field Un (supplies,truck,united nations)',
				),
				array(
					'fas fa-truck-medical' => 'Truck Medical (ambulance,ambulance,clinic,covid-19,emergency,emt,er,help,hospital,mobile,support,vehicle)',
				),
				array(
					'fas fa-truck-monster' => 'Truck Monster (offroad,vehicle,wheel)',
				),
				array(
					'fas fa-truck-pickup' => 'Truck Pickup (cargo,pick-up,pickup,pickup truck,truck,vehicle)',
				),
				array(
					'fas fa-van-shuttle' => 'Van Shuttle (shuttle-van,airport,bus,machine,minibus,public-transportation,transportation,travel,vehicle)',
				),
			),
			'Brands' => array(
				array(
					'fab fa-42-group' => '42.group (innosoft)',
				),
				array(
					'fab fa-500px' => '500px',
				),
				array(
					'fab fa-accessible-icon' => 'Accessible Icon (accessibility,handicap,person,wheelchair,wheelchair-alt)',
				),
				array(
					'fab fa-accusoft' => 'Accusoft',
				),
				array(
					'fab fa-adn' => 'App.net',
				),
				array(
					'fab fa-adversal' => 'Adversal',
				),
				array(
					'fab fa-affiliatetheme' => 'affiliatetheme',
				),
				array(
					'fab fa-airbnb' => 'Airbnb',
				),
				array(
					'fab fa-algolia' => 'Algolia',
				),
				array(
					'fab fa-alipay' => 'Alipay',
				),
				array(
					'fab fa-amazon' => 'Amazon',
				),
				array(
					'fab fa-amazon-pay' => 'Amazon Pay',
				),
				array(
					'fab fa-amilia' => 'Amilia',
				),
				array(
					'fab fa-android' => 'Android (robot)',
				),
				array(
					'fab fa-angellist' => 'AngelList',
				),
				array(
					'fab fa-angrycreative' => 'Angry Creative',
				),
				array(
					'fab fa-angular' => 'Angular',
				),
				array(
					'fab fa-app-store' => 'App Store',
				),
				array(
					'fab fa-app-store-ios' => 'iOS App Store',
				),
				array(
					'fab fa-apper' => 'Apper Systems AB',
				),
				array(
					'fab fa-apple' => 'Apple (fruit,ios,mac,operating system,os,osx)',
				),
				array(
					'fab fa-apple-pay' => 'Apple Pay',
				),
				array(
					'fab fa-artstation' => 'Artstation',
				),
				array(
					'fab fa-asymmetrik' => 'Asymmetrik, Ltd.',
				),
				array(
					'fab fa-atlassian' => 'Atlassian',
				),
				array(
					'fab fa-audible' => 'Audible',
				),
				array(
					'fab fa-autoprefixer' => 'Autoprefixer',
				),
				array(
					'fab fa-avianex' => 'avianex',
				),
				array(
					'fab fa-aviato' => 'Aviato',
				),
				array(
					'fab fa-aws' => 'Amazon Web Services (AWS)',
				),
				array(
					'fab fa-bandcamp' => 'Bandcamp',
				),
				array(
					'fab fa-battle-net' => 'Battle.net',
				),
				array(
					'fab fa-behance' => 'Behance',
				),
				array(
					'fab fa-bilibili' => 'Bilibili',
				),
				array(
					'fab fa-bimobject' => 'BIMobject',
				),
				array(
					'fab fa-bitbucket' => 'Bitbucket (atlassian,bitbucket-square,git)',
				),
				array(
					'fab fa-bitcoin' => 'Bitcoin',
				),
				array(
					'fab fa-bity' => 'Bity',
				),
				array(
					'fab fa-black-tie' => 'Font Awesome Black Tie',
				),
				array(
					'fab fa-blackberry' => 'BlackBerry',
				),
				array(
					'fab fa-blogger' => 'Blogger',
				),
				array(
					'fab fa-blogger-b' => 'Blogger B',
				),
				array(
					'fab fa-bluetooth' => 'Bluetooth (signal)',
				),
				array(
					'fab fa-bluetooth-b' => 'Bluetooth',
				),
				array(
					'fab fa-bootstrap' => 'Bootstrap',
				),
				array(
					'fab fa-bots' => 'Bots',
				),
				array(
					'fab fa-btc' => 'BTC',
				),
				array(
					'fab fa-buffer' => 'Buffer',
				),
				array(
					'fab fa-buromobelexperte' => 'Büromöbel-Experte GmbH & Co. KG.',
				),
				array(
					'fab fa-buy-n-large' => 'Buy n Large',
				),
				array(
					'fab fa-buysellads' => 'BuySellAds',
				),
				array(
					'fab fa-canadian-maple-leaf' => 'Canadian Maple Leaf (canada,flag,flora,nature,plant)',
				),
				array(
					'fab fa-cc-amazon-pay' => 'Amazon Pay Credit Card',
				),
				array(
					'fab fa-cc-amex' => 'American Express Credit Card (amex)',
				),
				array(
					'fab fa-cc-apple-pay' => 'Apple Pay Credit Card',
				),
				array(
					'fab fa-cc-diners-club' => 'Diner\'s Club Credit Card',
				),
				array(
					'fab fa-cc-discover' => 'Discover Credit Card',
				),
				array(
					'fab fa-cc-jcb' => 'JCB Credit Card',
				),
				array(
					'fab fa-cc-mastercard' => 'MasterCard Credit Card',
				),
				array(
					'fab fa-cc-paypal' => 'Paypal Credit Card',
				),
				array(
					'fab fa-cc-stripe' => 'Stripe Credit Card',
				),
				array(
					'fab fa-cc-visa' => 'Visa Credit Card',
				),
				array(
					'fab fa-centercode' => 'Centercode',
				),
				array(
					'fab fa-centos' => 'Centos (linux,operating system,os)',
				),
				array(
					'fab fa-chrome' => 'Chrome (browser)',
				),
				array(
					'fab fa-chromecast' => 'Chromecast',
				),
				array(
					'fab fa-cloudflare' => 'Cloudflare',
				),
				array(
					'fab fa-cloudscale' => 'cloudscale.ch',
				),
				array(
					'fab fa-cloudsmith' => 'Cloudsmith',
				),
				array(
					'fab fa-cloudversify' => 'cloudversify',
				),
				array(
					'fab fa-cmplid' => 'Cmplid',
				),
				array(
					'fab fa-codepen' => 'Codepen',
				),
				array(
					'fab fa-codiepie' => 'Codie Pie',
				),
				array(
					'fab fa-confluence' => 'Confluence (atlassian)',
				),
				array(
					'fab fa-connectdevelop' => 'Connect Develop',
				),
				array(
					'fab fa-contao' => 'Contao',
				),
				array(
					'fab fa-cotton-bureau' => 'Cotton Bureau (clothing,t-shirts,tshirts)',
				),
				array(
					'fab fa-cpanel' => 'cPanel',
				),
				array(
					'fab fa-creative-commons' => 'Creative Commons',
				),
				array(
					'fab fa-creative-commons-by' => 'Creative Commons Attribution',
				),
				array(
					'fab fa-creative-commons-nc' => 'Creative Commons Noncommercial',
				),
				array(
					'fab fa-creative-commons-nc-eu' => 'Creative Commons Noncommercial (Euro Sign)',
				),
				array(
					'fab fa-creative-commons-nc-jp' => 'Creative Commons Noncommercial (Yen Sign)',
				),
				array(
					'fab fa-creative-commons-nd' => 'Creative Commons No Derivative Works',
				),
				array(
					'fab fa-creative-commons-pd' => 'Creative Commons Public Domain',
				),
				array(
					'fab fa-creative-commons-pd-alt' => 'Alternate Creative Commons Public Domain',
				),
				array(
					'fab fa-creative-commons-remix' => 'Creative Commons Remix',
				),
				array(
					'fab fa-creative-commons-sa' => 'Creative Commons Share Alike',
				),
				array(
					'fab fa-creative-commons-sampling' => 'Creative Commons Sampling',
				),
				array(
					'fab fa-creative-commons-sampling-plus' => 'Creative Commons Sampling +',
				),
				array(
					'fab fa-creative-commons-share' => 'Creative Commons Share',
				),
				array(
					'fab fa-creative-commons-zero' => 'Creative Commons CC0',
				),
				array(
					'fab fa-critical-role' => 'Critical Role (Dungeons & Dragons,d&d,dnd,fantasy,game,gaming,tabletop)',
				),
				array(
					'fab fa-css3' => 'CSS 3 Logo (code)',
				),
				array(
					'fab fa-css3-alt' => 'Alternate CSS3 Logo',
				),
				array(
					'fab fa-cuttlefish' => 'Cuttlefish',
				),
				array(
					'fab fa-d-and-d' => 'Dungeons & Dragons',
				),
				array(
					'fab fa-d-and-d-beyond' => 'D&D Beyond (Dungeons & Dragons,d&d,dnd,fantasy,gaming,tabletop)',
				),
				array(
					'fab fa-dailymotion' => 'dailymotion',
				),
				array(
					'fab fa-dashcube' => 'DashCube',
				),
				array(
					'fab fa-debian' => 'Debian',
				),
				array(
					'fab fa-deezer' => 'Deezer',
				),
				array(
					'fab fa-delicious' => 'Delicious',
				),
				array(
					'fab fa-deploydog' => 'deploy.dog',
				),
				array(
					'fab fa-deskpro' => 'Deskpro',
				),
				array(
					'fab fa-dev' => 'DEV',
				),
				array(
					'fab fa-deviantart' => 'deviantART',
				),
				array(
					'fab fa-dhl' => 'DHL (Dalsey,Hillblom and Lynn,german,package,shipping)',
				),
				array(
					'fab fa-diaspora' => 'Diaspora',
				),
				array(
					'fab fa-digg' => 'Digg Logo',
				),
				array(
					'fab fa-digital-ocean' => 'Digital Ocean',
				),
				array(
					'fab fa-discord' => 'Discord',
				),
				array(
					'fab fa-discourse' => 'Discourse',
				),
				array(
					'fab fa-dochub' => 'DocHub',
				),
				array(
					'fab fa-docker' => 'Docker',
				),
				array(
					'fab fa-draft2digital' => 'Draft2digital',
				),
				array(
					'fab fa-dribbble' => 'Dribbble',
				),
				array(
					'fab fa-dropbox' => 'Dropbox',
				),
				array(
					'fab fa-drupal' => 'Drupal Logo',
				),
				array(
					'fab fa-dyalog' => 'Dyalog',
				),
				array(
					'fab fa-earlybirds' => 'Earlybirds',
				),
				array(
					'fab fa-ebay' => 'eBay',
				),
				array(
					'fab fa-edge' => 'Edge Browser (browser,ie)',
				),
				array(
					'fab fa-edge-legacy' => 'Edge Legacy Browser',
				),
				array(
					'fab fa-elementor' => 'Elementor',
				),
				array(
					'fab fa-ello' => 'Ello',
				),
				array(
					'fab fa-ember' => 'Ember',
				),
				array(
					'fab fa-empire' => 'Galactic Empire',
				),
				array(
					'fab fa-envira' => 'Envira Gallery (leaf)',
				),
				array(
					'fab fa-erlang' => 'Erlang',
				),
				array(
					'fab fa-ethereum' => 'Ethereum',
				),
				array(
					'fab fa-etsy' => 'Etsy',
				),
				array(
					'fab fa-evernote' => 'Evernote',
				),
				array(
					'fab fa-expeditedssl' => 'ExpeditedSSL',
				),
				array(
					'fab fa-facebook' => 'Facebook (facebook-official,social network)',
				),
				array(
					'fab fa-facebook-f' => 'Facebook F (facebook)',
				),
				array(
					'fab fa-facebook-messenger' => 'Facebook Messenger',
				),
				array(
					'fab fa-fantasy-flight-games' => 'Fantasy Flight-games (Dungeons & Dragons,d&d,dnd,fantasy,game,gaming,tabletop)',
				),
				array(
					'fab fa-fedex' => 'FedEx (Federal Express,package,shipping)',
				),
				array(
					'fab fa-fedora' => 'Fedora (linux,operating system,os)',
				),
				array(
					'fab fa-figma' => 'Figma (app,design,interface)',
				),
				array(
					'fab fa-firefox' => 'Firefox (browser)',
				),
				array(
					'fab fa-firefox-browser' => 'Firefox Browser (browser)',
				),
				array(
					'fab fa-first-order' => 'First Order',
				),
				array(
					'fab fa-first-order-alt' => 'Alternate First Order',
				),
				array(
					'fab fa-firstdraft' => 'firstdraft',
				),
				array(
					'fab fa-flickr' => 'Flickr',
				),
				array(
					'fab fa-flipboard' => 'Flipboard',
				),
				array(
					'fab fa-fly' => 'Fly',
				),
				array(
					'fab fa-font-awesome' => 'Font Awesome (font-awesome-flag,font-awesome-logo-full,awesome,flag,font,icons,typeface)',
				),
				array(
					'fab fa-fonticons' => 'Fonticons',
				),
				array(
					'fab fa-fonticons-fi' => 'Fonticons Fi',
				),
				array(
					'fab fa-fort-awesome' => 'Fort Awesome (castle)',
				),
				array(
					'fab fa-fort-awesome-alt' => 'Alternate Fort Awesome (castle)',
				),
				array(
					'fab fa-forumbee' => 'Forumbee',
				),
				array(
					'fab fa-foursquare' => 'Foursquare',
				),
				array(
					'fab fa-free-code-camp' => 'freeCodeCamp',
				),
				array(
					'fab fa-freebsd' => 'FreeBSD',
				),
				array(
					'fab fa-fulcrum' => 'Fulcrum',
				),
				array(
					'fab fa-galactic-republic' => 'Galactic Republic (politics,star wars)',
				),
				array(
					'fab fa-galactic-senate' => 'Galactic Senate (star wars)',
				),
				array(
					'fab fa-get-pocket' => 'Get Pocket',
				),
				array(
					'fab fa-gg' => 'GG Currency',
				),
				array(
					'fab fa-gg-circle' => 'GG Currency Circle',
				),
				array(
					'fab fa-git' => 'Git',
				),
				array(
					'fab fa-git-alt' => 'Git Alt',
				),
				array(
					'fab fa-github' => 'GitHub (octocat)',
				),
				array(
					'fab fa-github-alt' => 'Alternate GitHub (octocat)',
				),
				array(
					'fab fa-gitkraken' => 'GitKraken',
				),
				array(
					'fab fa-gitlab' => 'GitLab (Axosoft)',
				),
				array(
					'fab fa-gitter' => 'Gitter',
				),
				array(
					'fab fa-glide' => 'Glide',
				),
				array(
					'fab fa-glide-g' => 'Glide G',
				),
				array(
					'fab fa-gofore' => 'Gofore',
				),
				array(
					'fab fa-golang' => 'Go',
				),
				array(
					'fab fa-goodreads' => 'Goodreads',
				),
				array(
					'fab fa-goodreads-g' => 'Goodreads G',
				),
				array(
					'fab fa-google' => 'Google Logo',
				),
				array(
					'fab fa-google-drive' => 'Google Drive',
				),
				array(
					'fab fa-google-pay' => 'Google Pay',
				),
				array(
					'fab fa-google-play' => 'Google Play',
				),
				array(
					'fab fa-google-plus' => 'Google Plus (google-plus-circle,google-plus-official)',
				),
				array(
					'fab fa-google-plus-g' => 'Google Plus G (google-plus,social network)',
				),
				array(
					'fab fa-google-wallet' => 'Google Wallet',
				),
				array(
					'fab fa-gratipay' => 'Gratipay (Gittip) (favorite,heart,like,love)',
				),
				array(
					'fab fa-grav' => 'Grav',
				),
				array(
					'fab fa-gripfire' => 'Gripfire, Inc.',
				),
				array(
					'fab fa-grunt' => 'Grunt',
				),
				array(
					'fab fa-guilded' => 'Guilded',
				),
				array(
					'fab fa-gulp' => 'Gulp',
				),
				array(
					'fab fa-hacker-news' => 'Hacker News',
				),
				array(
					'fab fa-hackerrank' => 'Hackerrank',
				),
				array(
					'fab fa-hashnode' => 'Hashnode',
				),
				array(
					'fab fa-hips' => 'Hips',
				),
				array(
					'fab fa-hire-a-helper' => 'HireAHelper',
				),
				array(
					'fab fa-hive' => 'Hive Blockchain Network',
				),
				array(
					'fab fa-hooli' => 'Hooli',
				),
				array(
					'fab fa-hornbill' => 'Hornbill',
				),
				array(
					'fab fa-hotjar' => 'Hotjar',
				),
				array(
					'fab fa-houzz' => 'Houzz',
				),
				array(
					'fab fa-html5' => 'HTML 5 Logo',
				),
				array(
					'fab fa-hubspot' => 'HubSpot',
				),
				array(
					'fab fa-ideal' => 'iDeal',
				),
				array(
					'fab fa-imdb' => 'IMDB',
				),
				array(
					'fab fa-instagram' => 'Instagram',
				),
				array(
					'fab fa-instalod' => 'InstaLOD',
				),
				array(
					'fab fa-intercom' => 'Intercom (app,customer,messenger)',
				),
				array(
					'fab fa-internet-explorer' => 'Internet-explorer (browser,ie)',
				),
				array(
					'fab fa-invision' => 'InVision (app,design,interface)',
				),
				array(
					'fab fa-ioxhost' => 'ioxhost',
				),
				array(
					'fab fa-itch-io' => 'itch.io',
				),
				array(
					'fab fa-itunes' => 'iTunes',
				),
				array(
					'fab fa-itunes-note' => 'Itunes Note',
				),
				array(
					'fab fa-java' => 'Java',
				),
				array(
					'fab fa-jedi-order' => 'Jedi Order (star wars)',
				),
				array(
					'fab fa-jenkins' => 'Jenkis',
				),
				array(
					'fab fa-jira' => 'Jira (atlassian)',
				),
				array(
					'fab fa-joget' => 'Joget',
				),
				array(
					'fab fa-joomla' => 'Joomla Logo',
				),
				array(
					'fab fa-js' => 'JavaScript (JS)',
				),
				array(
					'fab fa-jsfiddle' => 'jsFiddle',
				),
				array(
					'fab fa-kaggle' => 'Kaggle',
				),
				array(
					'fab fa-keybase' => 'Keybase',
				),
				array(
					'fab fa-keycdn' => 'KeyCDN',
				),
				array(
					'fab fa-kickstarter' => 'Kickstarter',
				),
				array(
					'fab fa-kickstarter-k' => 'Kickstarter K',
				),
				array(
					'fab fa-korvue' => 'KORVUE',
				),
				array(
					'fab fa-laravel' => 'Laravel',
				),
				array(
					'fab fa-lastfm' => 'last.fm',
				),
				array(
					'fab fa-leanpub' => 'Leanpub',
				),
				array(
					'fab fa-less' => 'Less',
				),
				array(
					'fab fa-line' => 'Line',
				),
				array(
					'fab fa-linkedin' => 'LinkedIn (linkedin-square)',
				),
				array(
					'fab fa-linkedin-in' => 'LinkedIn In (linkedin)',
				),
				array(
					'fab fa-linode' => 'Linode',
				),
				array(
					'fab fa-linux' => 'Linux (tux)',
				),
				array(
					'fab fa-lyft' => 'lyft',
				),
				array(
					'fab fa-magento' => 'Magento',
				),
				array(
					'fab fa-mailchimp' => 'Mailchimp',
				),
				array(
					'fab fa-mandalorian' => 'Mandalorian',
				),
				array(
					'fab fa-markdown' => 'Markdown',
				),
				array(
					'fab fa-mastodon' => 'Mastodon',
				),
				array(
					'fab fa-maxcdn' => 'MaxCDN',
				),
				array(
					'fab fa-mdb' => 'Material Design for Bootstrap',
				),
				array(
					'fab fa-medapps' => 'MedApps',
				),
				array(
					'fab fa-medium' => 'Medium (medium-m)',
				),
				array(
					'fab fa-medrt' => 'MRT',
				),
				array(
					'fab fa-meetup' => 'Meetup',
				),
				array(
					'fab fa-megaport' => 'Megaport',
				),
				array(
					'fab fa-mendeley' => 'Mendeley',
				),
				array(
					'fab fa-meta' => 'Meta',
				),
				array(
					'fab fa-microblog' => 'Micro.blog',
				),
				array(
					'fab fa-microsoft' => 'Microsoft',
				),
				array(
					'fab fa-mix' => 'Mix',
				),
				array(
					'fab fa-mixcloud' => 'Mixcloud',
				),
				array(
					'fab fa-mixer' => 'Mixer',
				),
				array(
					'fab fa-mizuni' => 'Mizuni',
				),
				array(
					'fab fa-modx' => 'MODX',
				),
				array(
					'fab fa-monero' => 'Monero',
				),
				array(
					'fab fa-napster' => 'Napster',
				),
				array(
					'fab fa-neos' => 'Neos',
				),
				array(
					'fab fa-nfc-directional' => 'NFC Directional (connect,data,near field communication,nfc,scan,signal,transfer,wireless)',
				),
				array(
					'fab fa-nfc-symbol' => 'Nfc Symbol (connect,data,near field communication,nfc,scan,signal,transfer,wireless)',
				),
				array(
					'fab fa-nimblr' => 'Nimblr',
				),
				array(
					'fab fa-node' => 'Node.js',
				),
				array(
					'fab fa-node-js' => 'Node.js JS',
				),
				array(
					'fab fa-npm' => 'npm',
				),
				array(
					'fab fa-ns8' => 'NS8',
				),
				array(
					'fab fa-nutritionix' => 'Nutritionix',
				),
				array(
					'fab fa-octopus-deploy' => 'Octopus Deploy',
				),
				array(
					'fab fa-odnoklassniki' => 'Odnoklassniki',
				),
				array(
					'fab fa-odysee' => 'Odysee',
				),
				array(
					'fab fa-old-republic' => 'Old Republic (politics,star wars)',
				),
				array(
					'fab fa-opencart' => 'OpenCart',
				),
				array(
					'fab fa-openid' => 'OpenID',
				),
				array(
					'fab fa-opera' => 'Opera',
				),
				array(
					'fab fa-optin-monster' => 'Optin Monster',
				),
				array(
					'fab fa-orcid' => 'ORCID',
				),
				array(
					'fab fa-osi' => 'Open Source Initiative',
				),
				array(
					'fab fa-padlet' => 'Padlet',
				),
				array(
					'fab fa-page4' => 'page4 Corporation',
				),
				array(
					'fab fa-pagelines' => 'Pagelines (eco,flora,leaf,leaves,nature,plant,tree)',
				),
				array(
					'fab fa-palfed' => 'Palfed',
				),
				array(
					'fab fa-patreon' => 'Patreon',
				),
				array(
					'fab fa-paypal' => 'Paypal',
				),
				array(
					'fab fa-perbyte' => 'PerByte',
				),
				array(
					'fab fa-periscope' => 'Periscope',
				),
				array(
					'fab fa-phabricator' => 'Phabricator',
				),
				array(
					'fab fa-phoenix-framework' => 'Phoenix Framework',
				),
				array(
					'fab fa-phoenix-squadron' => 'Phoenix Squadron',
				),
				array(
					'fab fa-php' => 'PHP',
				),
				array(
					'fab fa-pied-piper' => 'Pied Piper Logo',
				),
				array(
					'fab fa-pied-piper-alt' => 'Alternate Pied Piper Logo (Old)',
				),
				array(
					'fab fa-pied-piper-hat' => 'Pied Piper Hat (Old) (clothing)',
				),
				array(
					'fab fa-pied-piper-pp' => 'Pied Piper PP Logo (Old)',
				),
				array(
					'fab fa-pinterest' => 'Pinterest',
				),
				array(
					'fab fa-pinterest-p' => 'Pinterest P',
				),
				array(
					'fab fa-pix' => 'Pix',
				),
				array(
					'fab fa-playstation' => 'PlayStation',
				),
				array(
					'fab fa-product-hunt' => 'Product Hunt',
				),
				array(
					'fab fa-pushed' => 'Pushed',
				),
				array(
					'fab fa-python' => 'Python',
				),
				array(
					'fab fa-qq' => 'QQ',
				),
				array(
					'fab fa-quinscape' => 'QuinScape',
				),
				array(
					'fab fa-quora' => 'Quora',
				),
				array(
					'fab fa-r-project' => 'R Project',
				),
				array(
					'fab fa-raspberry-pi' => 'Raspberry Pi',
				),
				array(
					'fab fa-ravelry' => 'Ravelry',
				),
				array(
					'fab fa-react' => 'React',
				),
				array(
					'fab fa-reacteurope' => 'ReactEurope',
				),
				array(
					'fab fa-readme' => 'ReadMe',
				),
				array(
					'fab fa-rebel' => 'Rebel Alliance',
				),
				array(
					'fab fa-red-river' => 'red river',
				),
				array(
					'fab fa-reddit' => 'reddit Logo',
				),
				array(
					'fab fa-reddit-alien' => 'reddit Alien',
				),
				array(
					'fab fa-redhat' => 'Redhat (linux,operating system,os)',
				),
				array(
					'fab fa-renren' => 'Renren',
				),
				array(
					'fab fa-replyd' => 'replyd',
				),
				array(
					'fab fa-researchgate' => 'Researchgate',
				),
				array(
					'fab fa-resolving' => 'Resolving',
				),
				array(
					'fab fa-rev' => 'Rev.io',
				),
				array(
					'fab fa-rocketchat' => 'Rocket.Chat',
				),
				array(
					'fab fa-rockrms' => 'Rockrms',
				),
				array(
					'fab fa-rust' => 'Rust',
				),
				array(
					'fab fa-safari' => 'Safari (browser)',
				),
				array(
					'fab fa-salesforce' => 'Salesforce',
				),
				array(
					'fab fa-sass' => 'Sass',
				),
				array(
					'fab fa-schlix' => 'SCHLIX',
				),
				array(
					'fab fa-screenpal' => 'Screenpal',
				),
				array(
					'fab fa-scribd' => 'Scribd',
				),
				array(
					'fab fa-searchengin' => 'Searchengin',
				),
				array(
					'fab fa-sellcast' => 'Sellcast (eercast)',
				),
				array(
					'fab fa-sellsy' => 'Sellsy',
				),
				array(
					'fab fa-servicestack' => 'Servicestack',
				),
				array(
					'fab fa-shirtsinbulk' => 'Shirts in Bulk',
				),
				array(
					'fab fa-shopify' => 'Shopify',
				),
				array(
					'fab fa-shopware' => 'Shopware',
				),
				array(
					'fab fa-simplybuilt' => 'SimplyBuilt',
				),
				array(
					'fab fa-sistrix' => 'SISTRIX',
				),
				array(
					'fab fa-sith' => 'Sith',
				),
				array(
					'fab fa-sitrox' => 'Sitrox',
				),
				array(
					'fab fa-sketch' => 'Sketch (app,design,interface)',
				),
				array(
					'fab fa-skyatlas' => 'skyatlas',
				),
				array(
					'fab fa-skype' => 'Skype',
				),
				array(
					'fab fa-slack' => 'Slack Logo (slack-hash,anchor,hash,hashtag)',
				),
				array(
					'fab fa-slideshare' => 'Slideshare',
				),
				array(
					'fab fa-snapchat' => 'Snapchat (snapchat-ghost)',
				),
				array(
					'fab fa-soundcloud' => 'SoundCloud',
				),
				array(
					'fab fa-sourcetree' => 'Sourcetree',
				),
				array(
					'fab fa-space-awesome' => 'Space Awesome (adventure,rocket,ship,shuttle)',
				),
				array(
					'fab fa-speakap' => 'Speakap',
				),
				array(
					'fab fa-speaker-deck' => 'Speaker Deck',
				),
				array(
					'fab fa-spotify' => 'Spotify',
				),
				array(
					'fab fa-square-behance' => 'Behance Square (behance-square)',
				),
				array(
					'fab fa-square-dribbble' => 'Dribbble Square (dribbble-square)',
				),
				array(
					'fab fa-square-facebook' => 'Facebook Square (facebook-square,social network)',
				),
				array(
					'fab fa-square-font-awesome' => 'Font Awesome in Square',
				),
				array(
					'fab fa-square-font-awesome-stroke' => 'Font Awesome in Square with Stroke Outline (font-awesome-alt)',
				),
				array(
					'fab fa-square-git' => 'Git Square (git-square)',
				),
				array(
					'fab fa-square-github' => 'GitHub Square (github-square,octocat)',
				),
				array(
					'fab fa-square-gitlab' => 'Square Gitlab (gitlab-square)',
				),
				array(
					'fab fa-square-google-plus' => 'Google Plus Square (google-plus-square,social network)',
				),
				array(
					'fab fa-square-hacker-news' => 'Hacker News Square (hacker-news-square)',
				),
				array(
					'fab fa-square-instagram' => 'Instagram Square (instagram-square)',
				),
				array(
					'fab fa-square-js' => 'JavaScript (JS) Square (js-square)',
				),
				array(
					'fab fa-square-lastfm' => 'last.fm Square (lastfm-square)',
				),
				array(
					'fab fa-square-odnoklassniki' => 'Odnoklassniki Square (odnoklassniki-square)',
				),
				array(
					'fab fa-square-pied-piper' => 'Pied Piper Square Logo (Old) (pied-piper-square)',
				),
				array(
					'fab fa-square-pinterest' => 'Pinterest Square (pinterest-square)',
				),
				array(
					'fab fa-square-reddit' => 'reddit Square (reddit-square)',
				),
				array(
					'fab fa-square-snapchat' => 'Snapchat Square (snapchat-square)',
				),
				array(
					'fab fa-square-steam' => 'Steam Square (steam-square)',
				),
				array(
					'fab fa-square-threads' => 'Square Threads',
				),
				array(
					'fab fa-square-tumblr' => 'Tumblr Square (tumblr-square)',
				),
				array(
					'fab fa-square-twitter' => 'Square Twitter (twitter-square,social network,tweet)',
				),
				array(
					'fab fa-square-viadeo' => 'Viadeo Square (viadeo-square)',
				),
				array(
					'fab fa-square-vimeo' => 'Vimeo Square (vimeo-square)',
				),
				array(
					'fab fa-square-whatsapp' => 'What\'s App Square (whatsapp-square)',
				),
				array(
					'fab fa-square-x-twitter' => 'Square X Twitter ( elon, x,twitter)',
				),
				array(
					'fab fa-square-xing' => 'Xing Square (xing-square)',
				),
				array(
					'fab fa-square-youtube' => 'YouTube Square (youtube-square)',
				),
				array(
					'fab fa-squarespace' => 'Squarespace',
				),
				array(
					'fab fa-stack-exchange' => 'Stack Exchange',
				),
				array(
					'fab fa-stack-overflow' => 'Stack Overflow',
				),
				array(
					'fab fa-stackpath' => 'Stackpath',
				),
				array(
					'fab fa-staylinked' => 'StayLinked',
				),
				array(
					'fab fa-steam' => 'Steam',
				),
				array(
					'fab fa-steam-symbol' => 'Steam Symbol',
				),
				array(
					'fab fa-sticker-mule' => 'Sticker Mule',
				),
				array(
					'fab fa-strava' => 'Strava',
				),
				array(
					'fab fa-stripe' => 'Stripe',
				),
				array(
					'fab fa-stripe-s' => 'Stripe S',
				),
				array(
					'fab fa-stubber' => 'Stubber',
				),
				array(
					'fab fa-studiovinari' => 'Studio Vinari',
				),
				array(
					'fab fa-stumbleupon' => 'StumbleUpon Logo',
				),
				array(
					'fab fa-stumbleupon-circle' => 'StumbleUpon Circle',
				),
				array(
					'fab fa-superpowers' => 'Superpowers',
				),
				array(
					'fab fa-supple' => 'Supple',
				),
				array(
					'fab fa-suse' => 'Suse (linux,operating system,os)',
				),
				array(
					'fab fa-swift' => 'Swift',
				),
				array(
					'fab fa-symfony' => 'Symfony',
				),
				array(
					'fab fa-teamspeak' => 'Teamspeak',
				),
				array(
					'fab fa-telegram' => 'Telegram (telegram-plane)',
				),
				array(
					'fab fa-tencent-weibo' => 'Tencent Weibo',
				),
				array(
					'fab fa-the-red-yeti' => 'The Red Yeti',
				),
				array(
					'fab fa-themeco' => 'Themeco',
				),
				array(
					'fab fa-themeisle' => 'ThemeIsle',
				),
				array(
					'fab fa-think-peaks' => 'Think Peaks',
				),
				array(
					'fab fa-threads' => 'Threads',
				),
				array(
					'fab fa-tiktok' => 'TikTok',
				),
				array(
					'fab fa-trade-federation' => 'Trade Federation',
				),
				array(
					'fab fa-trello' => 'Trello (atlassian)',
				),
				array(
					'fab fa-tumblr' => 'Tumblr',
				),
				array(
					'fab fa-twitch' => 'Twitch',
				),
				array(
					'fab fa-twitter' => 'Twitter (social network,tweet)',
				),
				array(
					'fab fa-typo3' => 'Typo3',
				),
				array(
					'fab fa-uber' => 'Uber',
				),
				array(
					'fab fa-ubuntu' => 'Ubuntu (linux,operating system,os)',
				),
				array(
					'fab fa-uikit' => 'UIkit',
				),
				array(
					'fab fa-umbraco' => 'Umbraco',
				),
				array(
					'fab fa-uncharted' => 'Uncharted Software',
				),
				array(
					'fab fa-uniregistry' => 'Uniregistry',
				),
				array(
					'fab fa-unity' => 'Unity 3D',
				),
				array(
					'fab fa-unsplash' => 'Unsplash',
				),
				array(
					'fab fa-untappd' => 'Untappd',
				),
				array(
					'fab fa-ups' => 'UPS (United Parcel Service,package,shipping)',
				),
				array(
					'fab fa-usb' => 'USB',
				),
				array(
					'fab fa-usps' => 'United States Postal Service (american,package,shipping,usa)',
				),
				array(
					'fab fa-ussunnah' => 'us-Sunnah Foundation',
				),
				array(
					'fab fa-vaadin' => 'Vaadin',
				),
				array(
					'fab fa-viacoin' => 'Viacoin',
				),
				array(
					'fab fa-viadeo' => 'Viadeo',
				),
				array(
					'fab fa-viber' => 'Viber',
				),
				array(
					'fab fa-vimeo' => 'Vimeo',
				),
				array(
					'fab fa-vimeo-v' => 'Vimeo (vimeo)',
				),
				array(
					'fab fa-vine' => 'Vine',
				),
				array(
					'fab fa-vk' => 'VK',
				),
				array(
					'fab fa-vnv' => 'VNV',
				),
				array(
					'fab fa-vuejs' => 'Vue.js',
				),
				array(
					'fab fa-watchman-monitoring' => 'Watchman Monitoring',
				),
				array(
					'fab fa-waze' => 'Waze',
				),
				array(
					'fab fa-weebly' => 'Weebly',
				),
				array(
					'fab fa-weibo' => 'Weibo',
				),
				array(
					'fab fa-weixin' => 'Weixin (WeChat)',
				),
				array(
					'fab fa-whatsapp' => 'What\'s App',
				),
				array(
					'fab fa-whmcs' => 'WHMCS',
				),
				array(
					'fab fa-wikipedia-w' => 'Wikipedia W',
				),
				array(
					'fab fa-windows' => 'Windows (microsoft,operating system,os)',
				),
				array(
					'fab fa-wirsindhandwerk' => 'wirsindhandwerk (wsh)',
				),
				array(
					'fab fa-wix' => 'Wix',
				),
				array(
					'fab fa-wizards-of-the-coast' => 'Wizards of the Coast (Dungeons & Dragons,d&d,dnd,fantasy,game,gaming,tabletop)',
				),
				array(
					'fab fa-wodu' => 'Wodu',
				),
				array(
					'fab fa-wolf-pack-battalion' => 'Wolf Pack Battalion',
				),
				array(
					'fab fa-wordpress' => 'WordPress Logo',
				),
				array(
					'fab fa-wordpress-simple' => 'Wordpress Simple',
				),
				array(
					'fab fa-wpbeginner' => 'WPBeginner',
				),
				array(
					'fab fa-wpexplorer' => 'WPExplorer',
				),
				array(
					'fab fa-wpforms' => 'WPForms',
				),
				array(
					'fab fa-wpressr' => 'wpressr (rendact,rendact)',
				),
				array(
					'fab fa-x-twitter' => 'X Twitter (	elon, twitter, x)',
				),
				array(
					'fab fa-xbox' => 'Xbox',
				),
				array(
					'fab fa-xing' => 'Xing',
				),
				array(
					'fab fa-y-combinator' => 'Y Combinator',
				),
				array(
					'fab fa-yahoo' => 'Yahoo Logo',
				),
				array(
					'fab fa-yammer' => 'Yammer',
				),
				array(
					'fab fa-yandex' => 'Yandex',
				),
				array(
					'fab fa-yandex-international' => 'Yandex International',
				),
				array(
					'fab fa-yarn' => 'Yarn',
				),
				array(
					'fab fa-yelp' => 'Yelp',
				),
				array(
					'fab fa-yoast' => 'Yoast',
				),
				array(
					'fab fa-youtube' => 'YouTube (film,video,youtube-play,youtube-square)',
				),
				array(
					'fab fa-zhihu' => 'Zhihu',
				),
			),
			'Buildings' => array(
				array(
					'fas fa-archway' => 'Archway (arc,monument,road,street,tunnel)',
				),
				array(
					'fas fa-arrow-right-to-city' => 'Arrow Right To City (building,city,exodus,rural,urban)',
				),
				array(
					'fas fa-building' => 'Building (apartment,building,business,city,company,office,office building,urban,work)',
				),
				array(
					'far fa-building' => 'Building (apartment,building,business,city,company,office,office building,urban,work)',
				),
				array(
					'fas fa-building-circle-arrow-right' => 'Building Circle Arrow Right (building,city,distribution center,office)',
				),
				array(
					'fas fa-building-circle-check' => 'Building Circle Check (building,city,not affected,office,ok,okay)',
				),
				array(
					'fas fa-building-circle-exclamation' => 'Building Circle Exclamation (affected,building,city,office)',
				),
				array(
					'fas fa-building-circle-xmark' => 'Building Circle Xmark (building,city,destroy,office)',
				),
				array(
					'fas fa-building-columns' => 'Building Columns (bank,institution,museum,university,bank,building,college,education,institution,museum,students)',
				),
				array(
					'fas fa-building-flag' => 'Building Flag ( city,building,diplomat,embassy,flag,headquarters,united nations)',
				),
				array(
					'fas fa-building-lock' => 'Building Lock (building,city,closed,lock,lockdown,quarantine,secure)',
				),
				array(
					'fas fa-building-ngo' => 'Building Ngo ( city,building,non governmental organization,office)',
				),
				array(
					'fas fa-building-shield' => 'Building Shield (building,city,police,protect,safety)',
				),
				array(
					'fas fa-building-un' => 'Building Un (building,city,office,united nations)',
				),
				array(
					'fas fa-building-user' => 'Building User (apartment,building,city)',
				),
				array(
					'fas fa-building-wheat' => 'Building Wheat (agriculture,building,city,usda)',
				),
				array(
					'fas fa-campground' => 'Campground (camping,fall,outdoors,teepee,tent,tipi)',
				),
				array(
					'fas fa-church' => 'Church (Christian,building,cathedral,chapel,church,community,cross,religion)',
				),
				array(
					'fas fa-city' => 'City (buildings,busy,city,cityscape,skyscrapers,urban,windows)',
				),
				array(
					'fas fa-dungeon' => 'Dungeon (Dungeons & Dragons,building,d&d,dnd,door,entrance,fantasy,gate)',
				),
				array(
					'fas fa-gopuram' => 'Gopuram (building,entrance,hinduism,temple,tower)',
				),
				array(
					'fas fa-hospital' => 'Hospital (hospital-alt,hospital-wide,building,covid-19,doctor,emergency room,hospital,medical center,medicine)',
				),
				array(
					'far fa-hospital' => 'Hospital (hospital-alt,hospital-wide,building,covid-19,doctor,emergency room,hospital,medical center,medicine)',
				),
				array(
					'fas fa-hospital-user' => 'Hospital User (covid-19,doctor,network,patient,primary care)',
				),
				array(
					'fas fa-hotel' => 'Hotel (building,hotel,inn,lodging,motel,resort,travel)',
				),
				array(
					'fas fa-house' => 'House (home,home-alt,home-lg-alt,abode,building,home,house,main,residence)',
				),
				array(
					'fas fa-house-chimney' => 'House Chimney (home-lg,abode,building,chimney,house,main,residence,smokestack)',
				),
				array(
					'fas fa-house-chimney-crack' => 'House Chimney Crack (house-damage,building,devastation,disaster,earthquake,home,insurance)',
				),
				array(
					'fas fa-house-chimney-medical' => 'House Chimney Medical (clinic-medical,covid-19,doctor,general practitioner,hospital,infirmary,medicine,office,outpatient)',
				),
				array(
					'fas fa-house-chimney-window' => 'House Chimney Window (abode,building,family,home,residence)',
				),
				array(
					'fas fa-house-circle-check' => 'House Circle Check (abode,home,house,not affected,ok,okay)',
				),
				array(
					'fas fa-house-circle-exclamation' => 'House Circle Exclamation (abode,affected,home,house)',
				),
				array(
					'fas fa-house-circle-xmark' => 'House Circle Xmark (abode,destroy,home,house)',
				),
				array(
					'fas fa-house-crack' => 'House Crack (building,devastation,disaster,earthquake,home,insurance)',
				),
				array(
					'fas fa-house-fire' => 'House Fire (burn,emergency,home)',
				),
				array(
					'fas fa-house-flag' => 'House Flag (camp,home)',
				),
				array(
					'fas fa-house-lock' => 'House Lock (closed,home,house,lockdown,quarantine)',
				),
				array(
					'fas fa-house-medical' => 'House Medical (covid-19,doctor,facility,general practitioner,health,hospital,infirmary,medicine,office,outpatient)',
				),
				array(
					'fas fa-house-medical-circle-check' => 'House Medical Circle Check (clinic,hospital,not affected,ok,okay)',
				),
				array(
					'fas fa-house-medical-circle-exclamation' => 'House Medical Circle Exclamation (affected,clinic,hospital)',
				),
				array(
					'fas fa-house-medical-circle-xmark' => 'House Medical Circle Xmark (clinic,destroy,hospital)',
				),
				array(
					'fas fa-house-medical-flag' => 'House Medical Flag (clinic,hospital,mash)',
				),
				array(
					'fas fa-igloo' => 'Igloo (dome,dwelling,eskimo,home,house,ice,snow)',
				),
				array(
					'fas fa-industry' => 'Industry (building,factory,industrial,manufacturing,mill,warehouse)',
				),
				array(
					'fas fa-kaaba' => 'Kaaba (Muslim,building,cube,islam,kaaba,muslim,religion)',
				),
				array(
					'fas fa-landmark' => 'Landmark (building,classical,historic,memorable,monument,museum,politics)',
				),
				array(
					'fas fa-landmark-dome' => 'Landmark Dome (landmark-alt,building,historic,memorable,monument,politics)',
				),
				array(
					'fas fa-landmark-flag' => 'Landmark Flag (capitol,flag,landmark,memorial)',
				),
				array(
					'fas fa-monument' => 'Monument (building,historic,landmark,memorable)',
				),
				array(
					'fas fa-mosque' => 'Mosque (Muslim,building,islam,landmark,mosque,muslim,religion)',
				),
				array(
					'fas fa-mountain-city' => 'Mountain City (location,rural,urban)',
				),
				array(
					'fas fa-oil-well' => 'Oil Well (drill,oil,rig)',
				),
				array(
					'fas fa-place-of-worship' => 'Place Of Worship (building,church,holy,mosque,synagogue)',
				),
				array(
					'fas fa-school' => 'School (building,education,learn,school,student,teacher)',
				),
				array(
					'fas fa-school-circle-check' => 'School Circle Check (not affected,ok,okay,schoolhouse)',
				),
				array(
					'fas fa-school-circle-exclamation' => 'School Circle Exclamation (affected,schoolhouse)',
				),
				array(
					'fas fa-school-circle-xmark' => 'School Circle Xmark (destroy,schoolhouse)',
				),
				array(
					'fas fa-school-flag' => 'School Flag (educate,flag,school,schoolhouse)',
				),
				array(
					'fas fa-school-lock' => 'School Lock (closed,lockdown,quarantine,schoolhouse)',
				),
				array(
					'fas fa-shop' => 'Shop (store-alt,bodega,building,buy,market,purchase,shopping,store)',
				),
				array(
					'fas fa-shop-lock' => 'Shop Lock (bodega,building,buy,closed,lock,lockdown,market,purchase,quarantine,shop,shopping,store)',
				),
				array(
					'fas fa-store' => 'Store (bodega,building,buy,market,purchase,shopping,store)',
				),
				array(
					'fas fa-synagogue' => 'Synagogue (Jew,Jewish,building,jewish,judaism,religion,star of david,synagogue,temple)',
				),
				array(
					'fas fa-tent' => 'Tent (bivouac,campground,refugee,shelter,tent)',
				),
				array(
					'fas fa-tent-arrow-down-to-line' => 'Tent Arrow Down To Line (permanent,refugee,shelter)',
				),
				array(
					'fas fa-tent-arrow-left-right' => 'Tent Arrow Left Right (refugee,shelter,transition)',
				),
				array(
					'fas fa-tent-arrow-turn-left' => 'Tent Arrow Turn Left (refugee,shelter,temporary)',
				),
				array(
					'fas fa-tent-arrows-down' => 'Tent Arrows Down (refugee,shelter,spontaneous)',
				),
				array(
					'fas fa-tents' => 'Tents (bivouac,campground,refugee,shelter,tent)',
				),
				array(
					'fas fa-toilet-portable' => 'Toilet Portable (outhouse,toilet)',
				),
				array(
					'fas fa-toilets-portable' => 'Toilets Portable (outhouse,toilet)',
				),
				array(
					'fas fa-torii-gate' => 'Torii Gate (building,religion,shinto,shinto shrine,shintoism,shrine)',
				),
				array(
					'fas fa-tower-observation' => 'Tower Observation (fire tower,view)',
				),
				array(
					'fas fa-tree-city' => 'Tree City (building,city,urban)',
				),
				array(
					'fas fa-vihara' => 'Vihara (buddhism,buddhist,building,monastery)',
				),
				array(
					'fas fa-warehouse' => 'Warehouse (building,capacity,garage,inventory,storage)',
				),
			),
			'Business' => array(
				array(
					'fas fa-address-book' => 'Address Book (contact-book,contact,directory,index,little black book,rolodex)',
				),
				array(
					'far fa-address-book' => 'Address Book (contact-book,contact,directory,index,little black book,rolodex)',
				),
				array(
					'fas fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'far fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'fas fa-arrows-spin' => 'Arrows Spin (cycle,rotate,spin,whirl)',
				),
				array(
					'fas fa-arrows-to-dot' => 'Arrows To Dot (assembly point,center,condense,focus,minimize)',
				),
				array(
					'fas fa-arrows-to-eye' => 'Arrows To Eye (center,coordinated assessment,focus)',
				),
				array(
					'fas fa-bars-progress' => 'Bars Progress (tasks-alt,checklist,downloading,downloads,loading,poll,progress,project management,settings,to do)',
				),
				array(
					'fas fa-bars-staggered' => 'Bars Staggered (reorder,stream,flow,list,timeline)',
				),
				array(
					'fas fa-book' => 'Book (book,cover,decorated,diary,documentation,journal,library,notebook,notebook with decorative cover,read,research)',
				),
				array(
					'fas fa-box-archive' => 'Box Archive (archive,box,package,save,storage)',
				),
				array(
					'fas fa-boxes-packing' => 'Boxes Packing (archive,box,package,storage,supplies)',
				),
				array(
					'fas fa-briefcase' => 'Briefcase (bag,briefcas,briefcase,business,luggage,office,work)',
				),
				array(
					'fas fa-building' => 'Building (apartment,building,business,city,company,office,office building,urban,work)',
				),
				array(
					'far fa-building' => 'Building (apartment,building,business,city,company,office,office building,urban,work)',
				),
				array(
					'fas fa-bullhorn' => 'Bullhorn (Bullhorn,announcement,broadcast,loud,louder,loudspeaker,megaphone,public address,share)',
				),
				array(
					'fas fa-bullseye' => 'Bullseye (archery,goal,objective,strategy,target)',
				),
				array(
					'fas fa-business-time' => 'Business Time (briefcase-clock,alarm,briefcase,business socks,clock,flight of the conchords,reminder,wednesday)',
				),
				array(
					'fas fa-cake-candles' => 'Cake Candles (birthday-cake,cake,anniversary,bakery,birthday,birthday cake,cake,candles,celebration,dessert,frosting,holiday,party,pastry,sweet)',
				),
				array(
					'fas fa-calculator' => 'Calculator (Pocket Calculator,abacus,addition,arithmetic,counting,math,multiplication,subtraction)',
				),
				array(
					'fas fa-calendar' => 'Calendar (calendar,calendar-o,date,day,event,month,schedule,tear-off calendar,time,when,year)',
				),
				array(
					'far fa-calendar' => 'Calendar (calendar,calendar-o,date,day,event,month,schedule,tear-off calendar,time,when,year)',
				),
				array(
					'fas fa-calendar-days' => 'Calendar Days (calendar-alt,calendar,date,day,event,month,schedule,time,when,year)',
				),
				array(
					'far fa-calendar-days' => 'Calendar Days (calendar-alt,calendar,date,day,event,month,schedule,time,when,year)',
				),
				array(
					'fas fa-certificate' => 'Certificate (badge,star,verified)',
				),
				array(
					'fas fa-chart-line' => 'Chart Line (line-chart,activity,analytics,chart,dashboard,gain,graph,increase,line)',
				),
				array(
					'fas fa-chart-pie' => 'Chart Pie (pie-chart,analytics,chart,diagram,graph,pie)',
				),
				array(
					'fas fa-chart-simple' => 'Chart Simple (analytics,bar,chart,column,graph,row,trend)',
				),
				array(
					'fas fa-city' => 'City (buildings,busy,city,cityscape,skyscrapers,urban,windows)',
				),
				array(
					'fas fa-clipboard' => 'Clipboard (clipboar,clipboard,copy,notes,paste,record)',
				),
				array(
					'far fa-clipboard' => 'Clipboard (clipboar,clipboard,copy,notes,paste,record)',
				),
				array(
					'fas fa-clipboard-question' => 'Clipboard Question (assistance,interview,query,question)',
				),
				array(
					'fas fa-compass' => 'Compass (compass,directions,directory,location,magnetic,menu,navigation,orienteering,safari,travel)',
				),
				array(
					'far fa-compass' => 'Compass (compass,directions,directory,location,magnetic,menu,navigation,orienteering,safari,travel)',
				),
				array(
					'fas fa-copy' => 'Copy (clone,duplicate,file,files-o,paper,paste)',
				),
				array(
					'far fa-copy' => 'Copy (clone,duplicate,file,files-o,paper,paste)',
				),
				array(
					'fas fa-copyright' => 'Copyright (brand,c,copyright,mark,register,trademark)',
				),
				array(
					'far fa-copyright' => 'Copyright (brand,c,copyright,mark,register,trademark)',
				),
				array(
					'fas fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'far fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-envelope-circle-check' => 'Envelope Circle Check (check,email,envelope,mail,not affected,ok,okay,read,sent)',
				),
				array(
					'fas fa-envelope-open' => 'Envelope Open (e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'far fa-envelope-open' => 'Envelope Open (e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-eraser' => 'Eraser (art,delete,remove,rubber)',
				),
				array(
					'fas fa-fax' => 'Fax (Fax Icon,business,communicate,copy,facsimile,fax,fax machine,send)',
				),
				array(
					'fas fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'far fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'fas fa-file-circle-plus' => 'File Circle Plus (add,document,file,new,page,paper,pdf)',
				),
				array(
					'fas fa-file-lines' => 'File Lines (file-alt,file-text,Document,Document with Text,document,file-text,invoice,new,page,pdf)',
				),
				array(
					'far fa-file-lines' => 'File Lines (file-alt,file-text,Document,Document with Text,document,file-text,invoice,new,page,pdf)',
				),
				array(
					'fas fa-floppy-disk' => 'Floppy Disk (save,Black Hard Shell Floppy Disk,computer,disk,download,floppy,floppy disk,floppy-o)',
				),
				array(
					'far fa-floppy-disk' => 'Floppy Disk (save,Black Hard Shell Floppy Disk,computer,disk,download,floppy,floppy disk,floppy-o)',
				),
				array(
					'fas fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'far fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'fas fa-folder-minus' => 'Folder Minus (archive,delete,directory,document,file,negative,remove)',
				),
				array(
					'fas fa-folder-open' => 'Folder Open (Open Folder,archive,directory,document,empty,file,folder,new,open,open file folder)',
				),
				array(
					'far fa-folder-open' => 'Folder Open (Open Folder,archive,directory,document,empty,file,folder,new,open,open file folder)',
				),
				array(
					'fas fa-folder-plus' => 'Folder Plus (add,archive,create,directory,document,file,new,positive)',
				),
				array(
					'fas fa-folder-tree' => 'Folder Tree (archive,directory,document,file,search,structure)',
				),
				array(
					'fas fa-glasses' => 'Glasses (hipster,nerd,reading,sight,spectacles,vision)',
				),
				array(
					'fas fa-globe' => 'Globe (all,coordinates,country,earth,global,globe,globe with meridians,gps,internet,language,localize,location,map,meridians,network,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-highlighter' => 'Highlighter (edit,marker,sharpie,update,write)',
				),
				array(
					'fas fa-house-laptop' => 'House Laptop (laptop-house,computer,covid-19,device,office,remote,work from home)',
				),
				array(
					'fas fa-industry' => 'Industry (building,factory,industrial,manufacturing,mill,warehouse)',
				),
				array(
					'fas fa-landmark' => 'Landmark (building,classical,historic,memorable,monument,museum,politics)',
				),
				array(
					'fas fa-laptop-file' => 'Laptop File (computer,education,laptop,learning,remote work)',
				),
				array(
					'fas fa-list-check' => 'List Check (tasks,checklist,downloading,downloads,loading,progress,project management,settings,to do)',
				),
				array(
					'fas fa-magnifying-glass-arrow-right' => 'Magnifying Glass Arrow Right (find,next,search)',
				),
				array(
					'fas fa-magnifying-glass-chart' => 'Magnifying Glass Chart ( data, graph, intelligence,analysis,chart,market)',
				),
				array(
					'fas fa-marker' => 'Marker (design,edit,sharpie,update,write)',
				),
				array(
					'fas fa-mug-saucer' => 'Mug Saucer (coffee,beverage,breakfast,cafe,drink,fall,morning,mug,seasonal,tea)',
				),
				array(
					'fas fa-network-wired' => 'Network Wired (computer,connect,ethernet,internet,intranet)',
				),
				array(
					'fas fa-note-sticky' => 'Note Sticky (sticky-note,message,note,paper,reminder,sticker)',
				),
				array(
					'far fa-note-sticky' => 'Note Sticky (sticky-note,message,note,paper,reminder,sticker)',
				),
				array(
					'fas fa-paperclip' => 'Paperclip (attach,attachment,connect,link,papercli,paperclip)',
				),
				array(
					'fas fa-paste' => 'Paste (file-clipboard,clipboard,copy,document,paper)',
				),
				array(
					'far fa-paste' => 'Paste (file-clipboard,clipboard,copy,document,paper)',
				),
				array(
					'fas fa-pen' => 'Pen (ballpoint,design,edit,pen,update,write)',
				),
				array(
					'fas fa-pen-clip' => 'Pen Clip (pen-alt,design,edit,update,write)',
				),
				array(
					'fas fa-pen-fancy' => 'Pen Fancy (black nib,design,edit,fountain,fountain pen,nib,pen,update,write)',
				),
				array(
					'fas fa-pen-nib' => 'Pen Nib (design,edit,fountain pen,update,write)',
				),
				array(
					'fas fa-pen-to-square' => 'Pen To Square (edit,edit,pen,pencil,update,write)',
				),
				array(
					'far fa-pen-to-square' => 'Pen To Square (edit,edit,pen,pencil,update,write)',
				),
				array(
					'fas fa-pencil' => 'Pencil (pencil-alt,Lower Left Pencil,design,draw,edit,lead,pencil,update,write)',
				),
				array(
					'fas fa-percent' => 'Percent (percentage,Percent Sign,discount,fraction,proportion,rate,ratio)',
				),
				array(
					'fas fa-person-chalkboard' => 'Person Chalkboard (blackboard,instructor,keynote,lesson,presentation,teacher)',
				),
				array(
					'fas fa-phone' => 'Phone (Left Hand Telephone Receiver,call,earphone,number,phone,receiver,support,telephone,telephone receiver,voice)',
				),
				array(
					'fas fa-phone-flip' => 'Phone Flip (phone-alt,Right Hand Telephone Receiver,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-phone-slash' => 'Phone Slash (call,cancel,earphone,mute,number,support,telephone,voice)',
				),
				array(
					'fas fa-phone-volume' => 'Phone Volume (volume-control-phone,call,earphone,number,sound,support,telephone,voice,volume-control-phone)',
				),
				array(
					'fas fa-print' => 'Print (Print Screen Symbol,Printer Icon,business,computer,copy,document,office,paper,printer)',
				),
				array(
					'fas fa-registered' => 'Registered (copyright,mark,r,registered,trademark)',
				),
				array(
					'far fa-registered' => 'Registered (copyright,mark,r,registered,trademark)',
				),
				array(
					'fas fa-scale-balanced' => 'Scale Balanced (balance-scale,Libra,balance,balance scale,balanced,justice,law,legal,measure,rule,scale,weight,zodiac)',
				),
				array(
					'fas fa-scale-unbalanced' => 'Scale Unbalanced (balance-scale-left,justice,legal,measure,unbalanced,weight)',
				),
				array(
					'fas fa-scale-unbalanced-flip' => 'Scale Unbalanced Flip (balance-scale-right,justice,legal,measure,unbalanced,weight)',
				),
				array(
					'fas fa-scissors' => 'Scissors (cut,Black Safety Scissors,White Scissors,clip,cutting,scissors,snip,tool)',
				),
				array(
					'fas fa-signature' => 'Signature (John Hancock,cursive,name,writing)',
				),
				array(
					'fas fa-sitemap' => 'Sitemap (directory,hierarchy,ia,information architecture,organization)',
				),
				array(
					'fas fa-socks' => 'Socks (business socks,business time,clothing,feet,flight of the conchords,socks,stocking,wednesday)',
				),
				array(
					'fas fa-square-envelope' => 'Square Envelope (envelope-square,e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-square-pen' => 'Square Pen (pen-square,pencil-square,edit,pencil-square,update,write)',
				),
				array(
					'fas fa-square-phone' => 'Square Phone (phone-square,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-square-phone-flip' => 'Square Phone Flip (phone-square-alt,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-square-poll-horizontal' => 'Square Poll Horizontal (poll-h,chart,graph,results,survey,trend,vote,voting)',
				),
				array(
					'fas fa-square-poll-vertical' => 'Square Poll Vertical (poll,chart,graph,results,survey,trend,vote,voting)',
				),
				array(
					'fas fa-stapler' => 'Stapler (desktop,milton,office,paperclip,staple)',
				),
				array(
					'fas fa-table' => 'Table (data,excel,spreadsheet)',
				),
				array(
					'fas fa-table-columns' => 'Table Columns (columns,browser,dashboard,organize,panes,split)',
				),
				array(
					'fas fa-tag' => 'Tag (discount,labe,label,price,shopping)',
				),
				array(
					'fas fa-tags' => 'Tags (discount,label,price,shopping)',
				),
				array(
					'fas fa-thumbtack' => 'Thumbtack (thumb-tack,Black Pushpin,coordinates,location,marker,pin,pushpin,thumb-tack)',
				),
				array(
					'fas fa-timeline' => 'Timeline (chronological,deadline,history,linear)',
				),
				array(
					'fas fa-trademark' => 'Trademark (copyright,mark,register,symbol,tm,trade mark,trademark)',
				),
				array(
					'fas fa-vault' => 'Vault (bank,important,lock,money,safe)',
				),
				array(
					'fas fa-wallet' => 'Wallet (billfold,cash,currency,money)',
				),
			),
			'Camping' => array(
				array(
					'fas fa-binoculars' => 'Binoculars (glasses,magnify,scenic,spyglass,view)',
				),
				array(
					'fas fa-bottle-water' => 'Bottle Water (h2o,plastic,water)',
				),
				array(
					'fas fa-bucket' => 'Bucket (bucket,pail,sandcastle)',
				),
				array(
					'fas fa-campground' => 'Campground (camping,fall,outdoors,teepee,tent,tipi)',
				),
				array(
					'fas fa-caravan' => 'Caravan (camper,motor home,rv,trailer,travel)',
				),
				array(
					'fas fa-compass' => 'Compass (compass,directions,directory,location,magnetic,menu,navigation,orienteering,safari,travel)',
				),
				array(
					'far fa-compass' => 'Compass (compass,directions,directory,location,magnetic,menu,navigation,orienteering,safari,travel)',
				),
				array(
					'fas fa-faucet' => 'Faucet (covid-19,drinking,drip,house,hygiene,kitchen,potable,potable water,sanitation,sink,water)',
				),
				array(
					'fas fa-faucet-drip' => 'Faucet Drip (drinking,drip,house,hygiene,kitchen,potable,potable water,sanitation,sink,water)',
				),
				array(
					'fas fa-fire' => 'Fire (burn,caliente,fire,flame,heat,hot,popular,tool)',
				),
				array(
					'fas fa-fire-burner' => 'Fire Burner (cook,fire,flame,kitchen,stove)',
				),
				array(
					'fas fa-fire-flame-curved' => 'Fire Flame Curved (fire-alt,burn,caliente,flame,heat,hot,popular)',
				),
				array(
					'fas fa-frog' => 'Frog (amphibian,bullfrog,fauna,hop,kermit,kiss,prince,ribbit,toad,wart)',
				),
				array(
					'fas fa-kit-medical' => 'Kit Medical (first-aid,emergency,emt,health,medical,rescue)',
				),
				array(
					'fas fa-map' => 'Map (address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel,world,world map)',
				),
				array(
					'far fa-map' => 'Map (address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel,world,world map)',
				),
				array(
					'fas fa-map-location' => 'Map Location (map-marked,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-map-location-dot' => 'Map Location Dot (map-marked-alt,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-mattress-pillow' => 'Mattress Pillow (air mattress,mattress,pillow,rest,sleep)',
				),
				array(
					'fas fa-mosquito' => 'Mosquito (bite,bug,mosquito,west nile)',
				),
				array(
					'fas fa-mosquito-net' => 'Mosquito Net (bite,malaria,mosquito,net)',
				),
				array(
					'fas fa-mountain' => 'Mountain (cold,glacier,hiking,hill,landscape,mountain,snow,snow-capped mountain,travel,view)',
				),
				array(
					'fas fa-mountain-sun' => 'Mountain Sun (country,hiking,landscape,rural,travel,view)',
				),
				array(
					'fas fa-people-roof' => 'People Roof (family,group,manage,people,safe,shelter)',
				),
				array(
					'fas fa-person-hiking' => 'Person Hiking (hiking,autumn,fall,hike,mountain,outdoors,summer,walk)',
				),
				array(
					'fas fa-person-shelter' => 'Person Shelter (house,inside,roof,safe,safety,shelter)',
				),
				array(
					'fas fa-route' => 'Route (directions,navigation,travel)',
				),
				array(
					'fas fa-signs-post' => 'Signs Post (map-signs,directions,directory,map,signage,wayfinding)',
				),
				array(
					'fas fa-tarp' => 'Tarp (protection,tarp,tent,waterproof)',
				),
				array(
					'fas fa-tarp-droplet' => 'Tarp Droplet (protection,tarp,tent,waterproof)',
				),
				array(
					'fas fa-tent' => 'Tent (bivouac,campground,refugee,shelter,tent)',
				),
				array(
					'fas fa-tent-arrow-down-to-line' => 'Tent Arrow Down To Line (permanent,refugee,shelter)',
				),
				array(
					'fas fa-tent-arrow-left-right' => 'Tent Arrow Left Right (refugee,shelter,transition)',
				),
				array(
					'fas fa-tent-arrow-turn-left' => 'Tent Arrow Turn Left (refugee,shelter,temporary)',
				),
				array(
					'fas fa-tent-arrows-down' => 'Tent Arrows Down (refugee,shelter,spontaneous)',
				),
				array(
					'fas fa-tents' => 'Tents (bivouac,campground,refugee,shelter,tent)',
				),
				array(
					'fas fa-toilet-paper' => 'Toilet Paper (bathroom,covid-19,halloween,holiday,lavatory,paper towels,prank,privy,restroom,roll,roll of paper,toilet,toilet paper,wipe)',
				),
				array(
					'fas fa-trailer' => 'Trailer (carry,haul,moving,travel)',
				),
				array(
					'fas fa-tree' => 'Tree (bark,evergreen tree,fall,flora,forest,nature,plant,seasonal,tree)',
				),
			),
			'Charity' => array(
				array(
					'fas fa-circle-dollar-to-slot' => 'Circle Dollar To Slot (donate,contribute,generosity,gift,give)',
				),
				array(
					'fas fa-dollar-sign' => 'Dollar Sign (dollar,usd,Dollar Sign,currency,dollar,heavy dollar sign,money)',
				),
				array(
					'fas fa-dove' => 'Dove (bird,dove,fauna,fly,flying,peace,war)',
				),
				array(
					'fas fa-gift' => 'Gift (box,celebration,christmas,generosity,gift,giving,holiday,party,present,wrapped,wrapped gift,xmas)',
				),
				array(
					'fas fa-globe' => 'Globe (all,coordinates,country,earth,global,globe,globe with meridians,gps,internet,language,localize,location,map,meridians,network,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-hand-holding-dollar' => 'Hand Holding Dollar (hand-holding-usd,$,carry,dollar sign,donation,giving,lift,money,price)',
				),
				array(
					'fas fa-hand-holding-droplet' => 'Hand Holding Droplet (hand-holding-water,carry,covid-19,drought,grow,lift,sanitation)',
				),
				array(
					'fas fa-hand-holding-hand' => 'Hand Holding Hand (care,give,help,hold,protect)',
				),
				array(
					'fas fa-hand-holding-heart' => 'Hand Holding Heart (carry,charity,gift,lift,package)',
				),
				array(
					'fas fa-hands-holding-child' => 'Hands Holding Child (care,give,help,hold,protect)',
				),
				array(
					'fas fa-hands-holding-circle' => 'Hands Holding Circle (circle,gift,protection)',
				),
				array(
					'fas fa-handshake' => 'Handshake (agreement,greeting,meeting,partnership)',
				),
				array(
					'far fa-handshake' => 'Handshake (agreement,greeting,meeting,partnership)',
				),
				array(
					'fas fa-handshake-angle' => 'Handshake Angle (hands-helping,aid,assistance,handshake,partnership,volunteering)',
				),
				array(
					'fas fa-handshake-simple' => 'Handshake Simple (handshake-alt,agreement,greeting,hand,handshake,meeting,partnership,shake)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fas fa-leaf' => 'Leaf (eco,flora,nature,plant,vegan)',
				),
				array(
					'fas fa-parachute-box' => 'Parachute Box (aid,assistance,goods,relief,rescue,supplies)',
				),
				array(
					'fas fa-piggy-bank' => 'Piggy Bank (bank,save,savings)',
				),
				array(
					'fas fa-ribbon' => 'Ribbon (badge,cause,celebration,lapel,pin,reminder,reminder ribbon,ribbon)',
				),
				array(
					'fas fa-seedling' => 'Seedling (sprout,environment,flora,grow,plant,sapling,seedling,vegan,young)',
				),
			),
			'Charts + Diagrams' => array(
				array(
					'fas fa-bars-progress' => 'Bars Progress (tasks-alt,checklist,downloading,downloads,loading,poll,progress,project management,settings,to do)',
				),
				array(
					'fas fa-chart-area' => 'Chart Area (area-chart,analytics,area,chart,graph)',
				),
				array(
					'fas fa-chart-bar' => 'Chart Bar (bar-chart,analytics,bar,chart,graph)',
				),
				array(
					'far fa-chart-bar' => 'Chart Bar (bar-chart,analytics,bar,chart,graph)',
				),
				array(
					'fas fa-chart-column' => 'Chart Column (bar,bar chart,chart,graph,track,trend)',
				),
				array(
					'fas fa-chart-gantt' => 'Chart Gantt (chart,graph,track,trend)',
				),
				array(
					'fas fa-chart-line' => 'Chart Line (line-chart,activity,analytics,chart,dashboard,gain,graph,increase,line)',
				),
				array(
					'fas fa-chart-pie' => 'Chart Pie (pie-chart,analytics,chart,diagram,graph,pie)',
				),
				array(
					'fas fa-chart-simple' => 'Chart Simple (analytics,bar,chart,column,graph,row,trend)',
				),
				array(
					'fas fa-circle-half-stroke' => 'Circle Half Stroke (adjust,Circle with Left Half Black,adjust,chart,contrast,dark,fill,light,pie,progress,saturation)',
				),
				array(
					'fas fa-diagram-next' => 'Diagram Next (cells,chart,gantt,row,subtask,successor,table)',
				),
				array(
					'fas fa-diagram-predecessor' => 'Diagram Predecessor (cells,chart,gantt,predecessor,previous,row,subtask,table)',
				),
				array(
					'fas fa-diagram-project' => 'Diagram Project (project-diagram,chart,graph,network,pert)',
				),
				array(
					'fas fa-diagram-successor' => 'Diagram Successor (cells,chart,gantt,next,row,subtask,successor,table)',
				),
				array(
					'fas fa-square-poll-horizontal' => 'Square Poll Horizontal (poll-h,chart,graph,results,survey,trend,vote,voting)',
				),
				array(
					'fas fa-square-poll-vertical' => 'Square Poll Vertical (poll,chart,graph,results,survey,trend,vote,voting)',
				),
			),
			'Childhood' => array(
				array(
					'fas fa-apple-whole' => 'Apple Whole (apple-alt,apple,fall,fruit,fuji,green,green apple,macintosh,orchard,red,red apple,seasonal,vegan)',
				),
				array(
					'fas fa-baby' => 'Baby (users-people)',
				),
				array(
					'fas fa-baby-carriage' => 'Baby Carriage (carriage-baby,buggy,carrier,infant,push,stroller,transportation,walk,wheels)',
				),
				array(
					'fas fa-baseball-bat-ball' => 'Baseball Bat Ball (bat,league,mlb,slugger,softball,sport)',
				),
				array(
					'fas fa-bath' => 'Bath (bathtub,bath,bathtub,clean,shower,tub,wash)',
				),
				array(
					'fas fa-bucket' => 'Bucket (bucket,pail,sandcastle)',
				),
				array(
					'fas fa-cake-candles' => 'Cake Candles (birthday-cake,cake,anniversary,bakery,birthday,birthday cake,cake,candles,celebration,dessert,frosting,holiday,party,pastry,sweet)',
				),
				array(
					'fas fa-child' => 'Child (boy,girl,kid,toddler,young,youth)',
				),
				array(
					'fas fa-child-dress' => 'Child Dress (boy,girl,kid,toddler,young,youth)',
				),
				array(
					'fas fa-child-reaching' => 'Child Reaching (boy,girl,kid,toddler,young,youth)',
				),
				array(
					'fas fa-children' => 'Children (boy,child,girl,kid,kids,young,youth)',
				),
				array(
					'fas fa-cookie' => 'Cookie (baked good,chips,chocolate,cookie,dessert,eat,snack,sweet,treat)',
				),
				array(
					'fas fa-cookie-bite' => 'Cookie Bite (baked good,bitten,chips,chocolate,eat,snack,sweet,treat)',
				),
				array(
					'fas fa-cubes-stacked' => 'Cubes Stacked (blocks,cubes,sugar)',
				),
				array(
					'fas fa-gamepad' => 'Gamepad (arcade,controller,d-pad,joystick,video,video game)',
				),
				array(
					'fas fa-hands-holding-child' => 'Hands Holding Child (care,give,help,hold,protect)',
				),
				array(
					'fas fa-ice-cream' => 'Ice Cream (chocolate,cone,cream,dessert,frozen,ice,ice cream,scoop,sorbet,sweet,vanilla,yogurt)',
				),
				array(
					'fas fa-mitten' => 'Mitten (clothing,cold,glove,hands,knitted,seasonal,warmth)',
				),
				array(
					'fas fa-person-biking' => 'Person Biking (biking,bicycle,bike,biking,cyclist,pedal,person biking,summer,wheel)',
				),
				array(
					'fas fa-person-breastfeeding' => 'Person Breastfeeding (baby,child,infant,mother,nutrition,sustenance)',
				),
				array(
					'fas fa-puzzle-piece' => 'Puzzle Piece (add-on,addon,clue,game,interlocking,jigsaw,piece,puzzle,puzzle piece,section)',
				),
				array(
					'fas fa-robot' => 'Robot (android,automate,computer,cyborg,face,monster,robot)',
				),
				array(
					'fas fa-school' => 'School (building,education,learn,school,student,teacher)',
				),
				array(
					'fas fa-shapes' => 'Shapes (triangle-circle-square,blocks,build,circle,square,triangle)',
				),
				array(
					'fas fa-snowman' => 'Snowman (cold,decoration,frost,frosty,holiday,snow,snowman,snowman without snow)',
				),
			),
			'Clothing + Fashion' => array(
				array(
					'fas fa-glasses' => 'Glasses (hipster,nerd,reading,sight,spectacles,vision)',
				),
				array(
					'fas fa-graduation-cap' => 'Graduation Cap (mortar-board,cap,celebration,ceremony,clothing,college,graduate,graduation,graduation cap,hat,learning,school,student)',
				),
				array(
					'fas fa-hat-cowboy' => 'Hat Cowboy (buckaroo,horse,jackeroo,john b.,old west,pardner,ranch,rancher,rodeo,western,wrangler)',
				),
				array(
					'fas fa-hat-cowboy-side' => 'Hat Cowboy Side (buckaroo,horse,jackeroo,john b.,old west,pardner,ranch,rancher,rodeo,western,wrangler)',
				),
				array(
					'fas fa-hat-wizard' => 'Hat Wizard (Dungeons & Dragons,accessory,buckle,clothing,d&d,dnd,fantasy,halloween,head,holiday,mage,magic,pointy,witch)',
				),
				array(
					'fas fa-mitten' => 'Mitten (clothing,cold,glove,hands,knitted,seasonal,warmth)',
				),
				array(
					'fas fa-shirt' => 'Shirt (t-shirt,tshirt,clothing,fashion,garment,shirt,short sleeve,t-shirt,tshirt)',
				),
				array(
					'fas fa-shoe-prints' => 'Shoe Prints (feet,footprints,steps,walk)',
				),
				array(
					'fas fa-socks' => 'Socks (business socks,business time,clothing,feet,flight of the conchords,socks,stocking,wednesday)',
				),
				array(
					'fas fa-user-tie' => 'User Tie (avatar,business,clothing,formal,professional,suit)',
				),
				array(
					'fas fa-vest' => 'Vest (biker,fashion,style)',
				),
				array(
					'fas fa-vest-patches' => 'Vest Patches (biker,fashion,style)',
				),
			),
			'Coding' => array(
				array(
					'fas fa-barcode' => 'Barcode (info,laser,price,scan,upc)',
				),
				array(
					'fas fa-bars' => 'Bars (navicon,checklist,drag,hamburger,list,menu,nav,navigation,ol,reorder,settings,todo,ul)',
				),
				array(
					'fas fa-bars-staggered' => 'Bars Staggered (reorder,stream,flow,list,timeline)',
				),
				array(
					'fas fa-bath' => 'Bath (bathtub,bath,bathtub,clean,shower,tub,wash)',
				),
				array(
					'fas fa-box-archive' => 'Box Archive (archive,box,package,save,storage)',
				),
				array(
					'fas fa-bug' => 'Bug (beetle,error,glitch,insect,repair,report)',
				),
				array(
					'fas fa-bug-slash' => 'Bug Slash (beetle,fix,glitch,insect,optimize,repair,report,warning)',
				),
				array(
					'fas fa-circle-nodes' => 'Circle Nodes (cluster,connect,network)',
				),
				array(
					'fas fa-code' => 'Code (brackets,code,development,html)',
				),
				array(
					'fas fa-code-branch' => 'Code Branch (branch,git,github,rebase,svn,vcs,version)',
				),
				array(
					'fas fa-code-commit' => 'Code Commit (commit,git,github,hash,rebase,svn,vcs,version)',
				),
				array(
					'fas fa-code-compare' => 'Code Compare (compare,git,github,svn,version)',
				),
				array(
					'fas fa-code-fork' => 'Code Fork (fork,git,github,svn,version)',
				),
				array(
					'fas fa-code-merge' => 'Code Merge (git,github,merge,pr,rebase,svn,vcs,version)',
				),
				array(
					'fas fa-code-pull-request' => 'Code Pull Request (git,github,pr,svn,version)',
				),
				array(
					'fas fa-cube' => 'Cube (3d,block,dice,package,square,tesseract)',
				),
				array(
					'fas fa-cubes' => 'Cubes (3d,block,dice,package,pyramid,square,stack,tesseract)',
				),
				array(
					'fas fa-diagram-project' => 'Diagram Project (project-diagram,chart,graph,network,pert)',
				),
				array(
					'fas fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'far fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'fas fa-file-code' => 'File Code (css,development,document,html)',
				),
				array(
					'far fa-file-code' => 'File Code (css,development,document,html)',
				),
				array(
					'fas fa-file-lines' => 'File Lines (file-alt,file-text,Document,Document with Text,document,file-text,invoice,new,page,pdf)',
				),
				array(
					'far fa-file-lines' => 'File Lines (file-alt,file-text,Document,Document with Text,document,file-text,invoice,new,page,pdf)',
				),
				array(
					'fas fa-filter' => 'Filter (funnel,options,separate,sort)',
				),
				array(
					'fas fa-fire-extinguisher' => 'Fire Extinguisher (burn,caliente,extinguish,fire,fire extinguisher,fire fighter,flame,heat,hot,quench,rescue)',
				),
				array(
					'fas fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'far fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'fas fa-folder-open' => 'Folder Open (Open Folder,archive,directory,document,empty,file,folder,new,open,open file folder)',
				),
				array(
					'far fa-folder-open' => 'Folder Open (Open Folder,archive,directory,document,empty,file,folder,new,open,open file folder)',
				),
				array(
					'fas fa-font-awesome' => 'Font Awesome (font-awesome-flag,font-awesome-logo-full,awesome,flag,font,icons,typeface)',
				),
				array(
					'far fa-font-awesome' => 'Font Awesome (font-awesome-flag,font-awesome-logo-full,awesome,flag,font,icons,typeface)',
				),
				array(
					'fab fa-font-awesome' => 'Font Awesome (font-awesome-flag,font-awesome-logo-full,awesome,flag,font,icons,typeface)',
				),
				array(
					'fas fa-gear' => 'Gear (cog,cog,cogwheel,gear,mechanical,settings,sprocket,tool,wheel)',
				),
				array(
					'fas fa-gears' => 'Gears (cogs,gears,mechanical,settings,sprocket,wheel)',
				),
				array(
					'fas fa-keyboard' => 'Keyboard (accessory,computer,edit,input,keyboard,text,type,write)',
				),
				array(
					'far fa-keyboard' => 'Keyboard (accessory,computer,edit,input,keyboard,text,type,write)',
				),
				array(
					'fas fa-laptop-code' => 'Laptop Code (computer,cpu,dell,demo,develop,device,mac,macbook,machine,pc)',
				),
				array(
					'fas fa-microchip' => 'Microchip (cpu,hardware,processor,technology)',
				),
				array(
					'fas fa-mug-saucer' => 'Mug Saucer (coffee,beverage,breakfast,cafe,drink,fall,morning,mug,seasonal,tea)',
				),
				array(
					'fas fa-network-wired' => 'Network Wired (computer,connect,ethernet,internet,intranet)',
				),
				array(
					'fas fa-notdef' => 'Notdef (close,missing)',
				),
				array(
					'fas fa-qrcode' => 'Qrcode (barcode,info,information,scan)',
				),
				array(
					'fas fa-rectangle-xmark' => 'Rectangle Xmark (rectangle-times,times-rectangle,window-close,browser,cancel,computer,development)',
				),
				array(
					'far fa-rectangle-xmark' => 'Rectangle Xmark (rectangle-times,times-rectangle,window-close,browser,cancel,computer,development)',
				),
				array(
					'fas fa-shield' => 'Shield (shield-blank,achievement,armor,award,block,cleric,defend,defense,holy,paladin,protect,safety,security,shield,weapon,winner)',
				),
				array(
					'fas fa-shield-halved' => 'Shield Halved (shield-alt,achievement,armor,award,block,cleric,defend,defense,holy,paladin,security,shield,weapon,winner)',
				),
				array(
					'fas fa-sitemap' => 'Sitemap (directory,hierarchy,ia,information architecture,organization)',
				),
				array(
					'fas fa-terminal' => 'Terminal (code,coding,command,console,development,prompt,terminal)',
				),
				array(
					'fas fa-user-secret' => 'User Secret (detective,sleuth,spy,users-people)',
				),
				array(
					'fas fa-window-maximize' => 'Window Maximize (Maximize,browser,computer,development,expand)',
				),
				array(
					'far fa-window-maximize' => 'Window Maximize (Maximize,browser,computer,development,expand)',
				),
				array(
					'fas fa-window-minimize' => 'Window Minimize (Minimize,browser,collapse,computer,development)',
				),
				array(
					'far fa-window-minimize' => 'Window Minimize (Minimize,browser,collapse,computer,development)',
				),
				array(
					'fas fa-window-restore' => 'Window Restore (browser,computer,development)',
				),
				array(
					'far fa-window-restore' => 'Window Restore (browser,computer,development)',
				),
			),
			'Communication' => array(
				array(
					'fas fa-address-book' => 'Address Book (contact-book,contact,directory,index,little black book,rolodex)',
				),
				array(
					'far fa-address-book' => 'Address Book (contact-book,contact,directory,index,little black book,rolodex)',
				),
				array(
					'fas fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'far fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'fas fa-at' => 'At (Commercial At,address,author,e-mail,email,fluctuate,handle)',
				),
				array(
					'fas fa-blender-phone' => 'Blender Phone (appliance,cocktail,fantasy,milkshake,mixer,puree,silly,smoothie)',
				),
				array(
					'fab fa-bluetooth-b' => 'Bluetooth',
				),
				array(
					'fas fa-bullhorn' => 'Bullhorn (Bullhorn,announcement,broadcast,loud,louder,loudspeaker,megaphone,public address,share)',
				),
				array(
					'fas fa-comment' => 'Comment (Right Speech Bubble,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'far fa-comment' => 'Comment (Right Speech Bubble,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'fas fa-comment-dots' => 'Comment Dots (commenting,balloon,bubble,chat,comic,commenting,conversation,dialog,feedback,message,more,note,notification,reply,sms,speech,speech balloon,texting)',
				),
				array(
					'far fa-comment-dots' => 'Comment Dots (commenting,balloon,bubble,chat,comic,commenting,conversation,dialog,feedback,message,more,note,notification,reply,sms,speech,speech balloon,texting)',
				),
				array(
					'fas fa-comment-medical' => 'Comment Medical (advice,bubble,chat,commenting,conversation,diagnose,feedback,message,note,notification,prescription,sms,speech,texting)',
				),
				array(
					'fas fa-comment-slash' => 'Comment Slash (bubble,cancel,chat,commenting,conversation,feedback,message,mute,note,notification,quiet,sms,speech,texting)',
				),
				array(
					'fas fa-comment-sms' => 'Comment Sms (sms,chat,conversation,message,mobile,notification,phone,sms,texting)',
				),
				array(
					'fas fa-comments' => 'Comments (Two Speech Bubbles,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'far fa-comments' => 'Comments (Two Speech Bubbles,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'fas fa-ear-listen' => 'Ear Listen (assistive-listening-systems,amplify,audio,deaf,ear,headset,hearing,sound)',
				),
				array(
					'fas fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'far fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-envelope-circle-check' => 'Envelope Circle Check (check,email,envelope,mail,not affected,ok,okay,read,sent)',
				),
				array(
					'fas fa-envelope-open' => 'Envelope Open (e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'far fa-envelope-open' => 'Envelope Open (e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-face-frown' => 'Face Frown (frown,disapprove,emoticon,face,frown,frowning face,rating,sad)',
				),
				array(
					'far fa-face-frown' => 'Face Frown (frown,disapprove,emoticon,face,frown,frowning face,rating,sad)',
				),
				array(
					'fas fa-face-meh' => 'Face Meh (meh,deadpan,emoticon,face,meh,neutral,neutral face,rating)',
				),
				array(
					'far fa-face-meh' => 'Face Meh (meh,deadpan,emoticon,face,meh,neutral,neutral face,rating)',
				),
				array(
					'fas fa-face-smile' => 'Face Smile (smile,approve,emoticon,face,happy,rating,satisfied,slightly smiling face,smile)',
				),
				array(
					'far fa-face-smile' => 'Face Smile (smile,approve,emoticon,face,happy,rating,satisfied,slightly smiling face,smile)',
				),
				array(
					'fas fa-fax' => 'Fax (Fax Icon,business,communicate,copy,facsimile,fax,fax machine,send)',
				),
				array(
					'fas fa-hands-asl-interpreting' => 'Hands Asl Interpreting (american-sign-language-interpreting,asl-interpreting,hands-american-sign-language-interpreting,asl,deaf,finger,hand,interpret,speak)',
				),
				array(
					'fas fa-icons' => 'Icons (heart-music-camera-bolt,bolt,emoji,heart,image,music,photo,symbols)',
				),
				array(
					'fas fa-inbox' => 'Inbox (archive,desk,email,mail,message)',
				),
				array(
					'fas fa-language' => 'Language (dialect,idiom,localize,speech,translate,vernacular)',
				),
				array(
					'fas fa-message' => 'Message (comment-alt,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'far fa-message' => 'Message (comment-alt,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'fas fa-microphone' => 'Microphone (address,audio,information,podcast,public,record,sing,sound,voice)',
				),
				array(
					'fas fa-microphone-lines' => 'Microphone Lines (microphone-alt,audio,mic,microphone,music,podcast,record,sing,sound,studio,studio microphone,voice)',
				),
				array(
					'fas fa-microphone-lines-slash' => 'Microphone Lines Slash (microphone-alt-slash,audio,disable,mute,podcast,record,sing,sound,voice)',
				),
				array(
					'fas fa-microphone-slash' => 'Microphone Slash (audio,disable,mute,podcast,record,sing,sound,voice)',
				),
				array(
					'fas fa-mobile' => 'Mobile (mobile-android,mobile-phone,android,call,cell,cell phone,device,mobile,mobile phone,number,phone,screen,telephone,text)',
				),
				array(
					'fas fa-mobile-button' => 'Mobile Button (apple,call,cell phone,device,iphone,number,screen,telephone)',
				),
				array(
					'fas fa-mobile-retro' => 'Mobile Retro (cellphone,cellular,phone)',
				),
				array(
					'fas fa-mobile-screen' => 'Mobile Screen (mobile-android-alt,android,call,cell phone,device,number,screen,telephone,text)',
				),
				array(
					'fas fa-mobile-screen-button' => 'Mobile Screen Button (mobile-alt,apple,call,cell phone,device,iphone,number,screen,telephone)',
				),
				array(
					'fas fa-paper-plane' => 'Paper Plane (air,float,fold,mail,paper,send)',
				),
				array(
					'far fa-paper-plane' => 'Paper Plane (air,float,fold,mail,paper,send)',
				),
				array(
					'fas fa-phone' => 'Phone (Left Hand Telephone Receiver,call,earphone,number,phone,receiver,support,telephone,telephone receiver,voice)',
				),
				array(
					'fas fa-phone-flip' => 'Phone Flip (phone-alt,Right Hand Telephone Receiver,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-phone-slash' => 'Phone Slash (call,cancel,earphone,mute,number,support,telephone,voice)',
				),
				array(
					'fas fa-phone-volume' => 'Phone Volume (volume-control-phone,call,earphone,number,sound,support,telephone,voice,volume-control-phone)',
				),
				array(
					'fas fa-poo' => 'Poo (crap,dung,face,monster,pile of poo,poo,poop,shit,smile,turd)',
				),
				array(
					'fas fa-quote-left' => 'Quote Left (quote-left-alt,Left Double Quotation Mark,mention,note,phrase,text,type)',
				),
				array(
					'fas fa-quote-right' => 'Quote Right (quote-right-alt,Right Double Quotation Mark,mention,note,phrase,text,type)',
				),
				array(
					'fas fa-square-envelope' => 'Square Envelope (envelope-square,e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-square-phone' => 'Square Phone (phone-square,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-square-phone-flip' => 'Square Phone Flip (phone-square-alt,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-square-rss' => 'Square Rss (rss-square,blog,feed,journal,news,writing)',
				),
				array(
					'fas fa-tower-cell' => 'Tower Cell (airwaves,antenna,communication,radio,reception,waves)',
				),
				array(
					'fas fa-tty' => 'Tty (teletype,communication,deaf,telephone,teletypewriter,text)',
				),
				array(
					'fas fa-video' => 'Video (video-camera,camera,film,movie,record,video-camera)',
				),
				array(
					'fas fa-video-slash' => 'Video Slash (add,create,film,new,positive,record,video)',
				),
				array(
					'fas fa-voicemail' => 'Voicemail (answer,inbox,message,phone)',
				),
				array(
					'fas fa-walkie-talkie' => 'Walkie Talkie (communication,copy,intercom,over,portable,radio,two way radio)',
				),
			),
			'Connectivity' => array(
				array(
					'fab fa-bluetooth' => 'Bluetooth (signal)',
				),
				array(
					'fas fa-circle-nodes' => 'Circle Nodes (cluster,connect,network)',
				),
				array(
					'fas fa-cloud' => 'Cloud (atmosphere,cloud,fog,overcast,save,upload,weather)',
				),
				array(
					'fas fa-cloud-arrow-down' => 'Cloud Arrow Down (cloud-download,cloud-download-alt,download,export,save)',
				),
				array(
					'fas fa-cloud-arrow-up' => 'Cloud Arrow Up (cloud-upload,cloud-upload-alt,import,save,upload)',
				),
				array(
					'fas fa-ethernet' => 'Ethernet (cable,cat 5,cat 6,connection,hardware,internet,network,wired)',
				),
				array(
					'fas fa-globe' => 'Globe (all,coordinates,country,earth,global,globe,globe with meridians,gps,internet,language,localize,location,map,meridians,network,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-house-signal' => 'House Signal (abode,building,connect,family,home,residence,smart home,wifi)',
				),
				array(
					'fas fa-rss' => 'Rss (feed,blog,feed,journal,news,writing)',
				),
				array(
					'fas fa-satellite-dish' => 'Satellite Dish (SETI,antenna,communications,dish,hardware,radar,receiver,satellite,satellite antenna,saucer,signal,space)',
				),
				array(
					'fas fa-signal' => 'Signal (signal-5,signal-perfect,antenna,antenna bars,bar,bars,cell,graph,mobile,online,phone,reception,status)',
				),
				array(
					'fas fa-tower-broadcast' => 'Tower Broadcast (broadcast-tower,airwaves,antenna,communication,emergency,radio,reception,waves)',
				),
				array(
					'fas fa-tower-cell' => 'Tower Cell (airwaves,antenna,communication,radio,reception,waves)',
				),
				array(
					'fas fa-wifi' => 'Wifi (wifi-3,wifi-strong,connection,hotspot,internet,network,wireless)',
				),
			),
			'Construction' => array(
				array(
					'fas fa-arrow-up-from-ground-water' => 'Arrow Up From Ground Water (groundwater,spring,water supply,water table)',
				),
				array(
					'fas fa-bore-hole' => 'Bore Hole (bore,bury,drill,hole)',
				),
				array(
					'fas fa-brush' => 'Brush (art,bristles,color,handle,paint)',
				),
				array(
					'fas fa-bucket' => 'Bucket (bucket,pail,sandcastle)',
				),
				array(
					'fas fa-compass-drafting' => 'Compass Drafting (drafting-compass,design,map,mechanical drawing,plot,plotting)',
				),
				array(
					'fas fa-dumpster' => 'Dumpster (alley,bin,commercial,trash,waste)',
				),
				array(
					'fas fa-dumpster-fire' => 'Dumpster Fire (alley,bin,commercial,danger,dangerous,euphemism,flame,heat,hot,trash,waste)',
				),
				array(
					'fas fa-hammer' => 'Hammer (admin,fix,hammer,recovery,repair,settings,tool)',
				),
				array(
					'fas fa-helmet-safety' => 'Helmet Safety (hard-hat,hat-hard,construction,hardhat,helmet,safety)',
				),
				array(
					'fas fa-mound' => 'Mound (barrier,hill,pitcher,speedbump)',
				),
				array(
					'fas fa-paint-roller' => 'Paint Roller (acrylic,art,brush,color,fill,paint,pigment,watercolor)',
				),
				array(
					'fas fa-pen-ruler' => 'Pen Ruler (pencil-ruler,design,draft,draw,pencil)',
				),
				array(
					'fas fa-pencil' => 'Pencil (pencil-alt,Lower Left Pencil,design,draw,edit,lead,pencil,update,write)',
				),
				array(
					'fas fa-person-digging' => 'Person Digging (digging,bury,construction,debris,dig,men at work)',
				),
				array(
					'fas fa-ruler' => 'Ruler (design,draft,length,measure,planning,ruler,straight edge,straight ruler)',
				),
				array(
					'fas fa-ruler-combined' => 'Ruler Combined (design,draft,length,measure,planning)',
				),
				array(
					'fas fa-ruler-horizontal' => 'Ruler Horizontal (design,draft,length,measure,planning)',
				),
				array(
					'fas fa-ruler-vertical' => 'Ruler Vertical (design,draft,length,measure,planning)',
				),
				array(
					'fas fa-screwdriver' => 'Screwdriver (admin,fix,mechanic,repair,screw,screwdriver,settings,tool)',
				),
				array(
					'fas fa-screwdriver-wrench' => 'Screwdriver Wrench (tools,admin,fix,repair,screwdriver,settings,tools,wrench)',
				),
				array(
					'fas fa-sheet-plastic' => 'Sheet Plastic (plastic,plastic wrap,protect,tarp,tarpaulin,waterproof)',
				),
				array(
					'fas fa-tarp' => 'Tarp (protection,tarp,tent,waterproof)',
				),
				array(
					'fas fa-tarp-droplet' => 'Tarp Droplet (protection,tarp,tent,waterproof)',
				),
				array(
					'fas fa-toilet-portable' => 'Toilet Portable (outhouse,toilet)',
				),
				array(
					'fas fa-toilets-portable' => 'Toilets Portable (outhouse,toilet)',
				),
				array(
					'fas fa-toolbox' => 'Toolbox (admin,chest,container,fix,mechanic,repair,settings,tool,toolbox,tools)',
				),
				array(
					'fas fa-trowel' => 'Trowel (build,construction,tool)',
				),
				array(
					'fas fa-trowel-bricks' => 'Trowel Bricks (build,construction,reconstruction,tool)',
				),
				array(
					'fas fa-truck-pickup' => 'Truck Pickup (cargo,pick-up,pickup,pickup truck,truck,vehicle)',
				),
				array(
					'fas fa-wrench' => 'Wrench (construction,fix,mechanic,plumbing,settings,spanner,tool,update,wrench)',
				),
			),
			'Design' => array(
				array(
					'fas fa-bezier-curve' => 'Bezier Curve (curves,illustrator,lines,path,vector)',
				),
				array(
					'fas fa-brush' => 'Brush (art,bristles,color,handle,paint)',
				),
				array(
					'fas fa-circle-half-stroke' => 'Circle Half Stroke (adjust,Circle with Left Half Black,adjust,chart,contrast,dark,fill,light,pie,progress,saturation)',
				),
				array(
					'fas fa-circle-nodes' => 'Circle Nodes (cluster,connect,network)',
				),
				array(
					'fas fa-clone' => 'Clone (arrange,copy,duplicate,paste)',
				),
				array(
					'far fa-clone' => 'Clone (arrange,copy,duplicate,paste)',
				),
				array(
					'fas fa-compass-drafting' => 'Compass Drafting (drafting-compass,design,map,mechanical drawing,plot,plotting)',
				),
				array(
					'fas fa-copy' => 'Copy (clone,duplicate,file,files-o,paper,paste)',
				),
				array(
					'far fa-copy' => 'Copy (clone,duplicate,file,files-o,paper,paste)',
				),
				array(
					'fas fa-crop' => 'Crop (design,frame,mask,resize,shrink)',
				),
				array(
					'fas fa-crop-simple' => 'Crop Simple (crop-alt,design,frame,mask,resize,shrink)',
				),
				array(
					'fas fa-crosshairs' => 'Crosshairs (aim,bullseye,gpd,picker,position)',
				),
				array(
					'fas fa-cube' => 'Cube (3d,block,dice,package,square,tesseract)',
				),
				array(
					'fas fa-cubes' => 'Cubes (3d,block,dice,package,pyramid,square,stack,tesseract)',
				),
				array(
					'fas fa-draw-polygon' => 'Draw Polygon (anchors,lines,object,render,shape)',
				),
				array(
					'fas fa-droplet' => 'Droplet (tint,cold,color,comic,drop,droplet,raindrop,sweat,waterdrop)',
				),
				array(
					'fas fa-droplet-slash' => 'Droplet Slash (tint-slash,color,drop,droplet,raindrop,waterdrop)',
				),
				array(
					'fas fa-eraser' => 'Eraser (art,delete,remove,rubber)',
				),
				array(
					'fas fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'far fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'fas fa-eye-dropper' => 'Eye Dropper (eye-dropper-empty,eyedropper,beaker,clone,color,copy,eyedropper,pipette)',
				),
				array(
					'fas fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'far fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'fas fa-fill' => 'Fill (bucket,color,paint,paint bucket)',
				),
				array(
					'fas fa-fill-drip' => 'Fill Drip (bucket,color,drop,paint,paint bucket,spill)',
				),
				array(
					'fas fa-floppy-disk' => 'Floppy Disk (save,Black Hard Shell Floppy Disk,computer,disk,download,floppy,floppy disk,floppy-o)',
				),
				array(
					'far fa-floppy-disk' => 'Floppy Disk (save,Black Hard Shell Floppy Disk,computer,disk,download,floppy,floppy disk,floppy-o)',
				),
				array(
					'fas fa-font-awesome' => 'Font Awesome (font-awesome-flag,font-awesome-logo-full,awesome,flag,font,icons,typeface)',
				),
				array(
					'far fa-font-awesome' => 'Font Awesome (font-awesome-flag,font-awesome-logo-full,awesome,flag,font,icons,typeface)',
				),
				array(
					'fab fa-font-awesome' => 'Font Awesome (font-awesome-flag,font-awesome-logo-full,awesome,flag,font,icons,typeface)',
				),
				array(
					'fas fa-highlighter' => 'Highlighter (edit,marker,sharpie,update,write)',
				),
				array(
					'fas fa-icons' => 'Icons (heart-music-camera-bolt,bolt,emoji,heart,image,music,photo,symbols)',
				),
				array(
					'fas fa-layer-group' => 'Layer Group (arrange,develop,layers,map,stack)',
				),
				array(
					'fas fa-lines-leaning' => 'Lines Leaning (canted,domino,falling,resilience,resilient,tipped)',
				),
				array(
					'fas fa-marker' => 'Marker (design,edit,sharpie,update,write)',
				),
				array(
					'fas fa-object-group' => 'Object Group (combine,copy,design,merge,select)',
				),
				array(
					'far fa-object-group' => 'Object Group (combine,copy,design,merge,select)',
				),
				array(
					'fas fa-object-ungroup' => 'Object Ungroup (copy,design,merge,select,separate)',
				),
				array(
					'far fa-object-ungroup' => 'Object Ungroup (copy,design,merge,select,separate)',
				),
				array(
					'fas fa-paint-roller' => 'Paint Roller (acrylic,art,brush,color,fill,paint,pigment,watercolor)',
				),
				array(
					'fas fa-paintbrush' => 'Paintbrush (paint-brush,acrylic,art,brush,color,fill,paint,paintbrush,painting,pigment,watercolor)',
				),
				array(
					'fas fa-palette' => 'Palette (acrylic,art,artist palette,brush,color,fill,museum,paint,painting,palette,pigment,watercolor)',
				),
				array(
					'fas fa-paste' => 'Paste (file-clipboard,clipboard,copy,document,paper)',
				),
				array(
					'far fa-paste' => 'Paste (file-clipboard,clipboard,copy,document,paper)',
				),
				array(
					'fas fa-pen' => 'Pen (ballpoint,design,edit,pen,update,write)',
				),
				array(
					'fas fa-pen-clip' => 'Pen Clip (pen-alt,design,edit,update,write)',
				),
				array(
					'fas fa-pen-fancy' => 'Pen Fancy (black nib,design,edit,fountain,fountain pen,nib,pen,update,write)',
				),
				array(
					'fas fa-pen-nib' => 'Pen Nib (design,edit,fountain pen,update,write)',
				),
				array(
					'fas fa-pen-ruler' => 'Pen Ruler (pencil-ruler,design,draft,draw,pencil)',
				),
				array(
					'fas fa-pen-to-square' => 'Pen To Square (edit,edit,pen,pencil,update,write)',
				),
				array(
					'far fa-pen-to-square' => 'Pen To Square (edit,edit,pen,pencil,update,write)',
				),
				array(
					'fas fa-pencil' => 'Pencil (pencil-alt,Lower Left Pencil,design,draw,edit,lead,pencil,update,write)',
				),
				array(
					'fas fa-ruler-combined' => 'Ruler Combined (design,draft,length,measure,planning)',
				),
				array(
					'fas fa-ruler-horizontal' => 'Ruler Horizontal (design,draft,length,measure,planning)',
				),
				array(
					'fas fa-ruler-vertical' => 'Ruler Vertical (design,draft,length,measure,planning)',
				),
				array(
					'fas fa-scissors' => 'Scissors (cut,Black Safety Scissors,White Scissors,clip,cutting,scissors,snip,tool)',
				),
				array(
					'fas fa-splotch' => 'Splotch (Ink,blob,blotch,glob,stain)',
				),
				array(
					'fas fa-spray-can' => 'Spray Can (Paint,aerosol,design,graffiti,tag)',
				),
				array(
					'fas fa-stamp' => 'Stamp (art,certificate,imprint,rubber,seal)',
				),
				array(
					'fas fa-stapler' => 'Stapler (desktop,milton,office,paperclip,staple)',
				),
				array(
					'fas fa-swatchbook' => 'Swatchbook (Pantone,color,design,hue,palette)',
				),
				array(
					'fas fa-vector-square' => 'Vector Square (anchors,lines,object,render,shape)',
				),
				array(
					'fas fa-wand-magic' => 'Wand Magic (magic,autocomplete,automatic,mage,magic,spell,wand,witch,wizard)',
				),
				array(
					'fas fa-wand-magic-sparkles' => 'Wand Magic Sparkles (magic-wand-sparkles,auto,magic,magic wand,trick,witch,wizard)',
				),
			),
			'Devices + Hardware' => array(
				array(
					'fas fa-blender-phone' => 'Blender Phone (appliance,cocktail,fantasy,milkshake,mixer,puree,silly,smoothie)',
				),
				array(
					'fas fa-camera' => 'Camera (camera-alt,image,lens,photo,picture,record,shutter,video)',
				),
				array(
					'fas fa-camera-retro' => 'Camera Retro (camera,image,lens,photo,picture,record,shutter,video)',
				),
				array(
					'fas fa-car-battery' => 'Car Battery (battery-car,auto,electric,mechanic,power)',
				),
				array(
					'fas fa-compact-disc' => 'Compact Disc (Optical Disc Icon,album,blu-ray,bluray,cd,computer,disc,disk,dvd,media,movie,music,optical,optical disk,record,video,vinyl)',
				),
				array(
					'fas fa-computer' => 'Computer (computer,desktop,display,monitor,tower)',
				),
				array(
					'fas fa-computer-mouse' => 'Computer Mouse (mouse,click,computer,computer mouse,cursor,input,peripheral)',
				),
				array(
					'fas fa-database' => 'Database (computer,development,directory,memory,storage)',
				),
				array(
					'fas fa-desktop' => 'Desktop (desktop-alt,computer,cpu,demo,desktop,desktop computer,device,imac,machine,monitor,pc,screen)',
				),
				array(
					'fas fa-display' => 'Display (Screen,computer,desktop,imac)',
				),
				array(
					'fas fa-download' => 'Download (export,hard drive,save,transfer)',
				),
				array(
					'fas fa-ethernet' => 'Ethernet (cable,cat 5,cat 6,connection,hardware,internet,network,wired)',
				),
				array(
					'fas fa-fax' => 'Fax (Fax Icon,business,communicate,copy,facsimile,fax,fax machine,send)',
				),
				array(
					'fas fa-floppy-disk' => 'Floppy Disk (save,Black Hard Shell Floppy Disk,computer,disk,download,floppy,floppy disk,floppy-o)',
				),
				array(
					'far fa-floppy-disk' => 'Floppy Disk (save,Black Hard Shell Floppy Disk,computer,disk,download,floppy,floppy disk,floppy-o)',
				),
				array(
					'fas fa-gamepad' => 'Gamepad (arcade,controller,d-pad,joystick,video,video game)',
				),
				array(
					'fas fa-hard-drive' => 'Hard Drive (hdd,Hard Disk,cpu,hard drive,harddrive,machine,save,storage)',
				),
				array(
					'far fa-hard-drive' => 'Hard Drive (hdd,Hard Disk,cpu,hard drive,harddrive,machine,save,storage)',
				),
				array(
					'fas fa-headphones' => 'Headphones (audio,earbud,headphone,listen,music,sound,speaker)',
				),
				array(
					'fas fa-house-laptop' => 'House Laptop (laptop-house,computer,covid-19,device,office,remote,work from home)',
				),
				array(
					'fas fa-keyboard' => 'Keyboard (accessory,computer,edit,input,keyboard,text,type,write)',
				),
				array(
					'far fa-keyboard' => 'Keyboard (accessory,computer,edit,input,keyboard,text,type,write)',
				),
				array(
					'fas fa-laptop' => 'Laptop (computer,cpu,dell,demo,device,laptop,mac,macbook,machine,pc,personal)',
				),
				array(
					'fas fa-laptop-file' => 'Laptop File (computer,education,laptop,learning,remote work)',
				),
				array(
					'fas fa-memory' => 'Memory (DIMM,RAM,hardware,storage,technology)',
				),
				array(
					'fas fa-microchip' => 'Microchip (cpu,hardware,processor,technology)',
				),
				array(
					'fas fa-mobile' => 'Mobile (mobile-android,mobile-phone,android,call,cell,cell phone,device,mobile,mobile phone,number,phone,screen,telephone,text)',
				),
				array(
					'fas fa-mobile-button' => 'Mobile Button (apple,call,cell phone,device,iphone,number,screen,telephone)',
				),
				array(
					'fas fa-mobile-retro' => 'Mobile Retro (cellphone,cellular,phone)',
				),
				array(
					'fas fa-mobile-screen' => 'Mobile Screen (mobile-android-alt,android,call,cell phone,device,number,screen,telephone,text)',
				),
				array(
					'fas fa-mobile-screen-button' => 'Mobile Screen Button (mobile-alt,apple,call,cell phone,device,iphone,number,screen,telephone)',
				),
				array(
					'fas fa-plug' => 'Plug (connect,electric,electric plug,electricity,online,plug,power)',
				),
				array(
					'fas fa-power-off' => 'Power Off (Power Symbol,cancel,computer,on,reboot,restart)',
				),
				array(
					'fas fa-print' => 'Print (Print Screen Symbol,Printer Icon,business,computer,copy,document,office,paper,printer)',
				),
				array(
					'fas fa-satellite' => 'Satellite (communications,hardware,orbit,satellite,space)',
				),
				array(
					'fas fa-satellite-dish' => 'Satellite Dish (SETI,antenna,communications,dish,hardware,radar,receiver,satellite,satellite antenna,saucer,signal,space)',
				),
				array(
					'fas fa-sd-card' => 'Sd Card (image,memory,photo,save)',
				),
				array(
					'fas fa-server' => 'Server (computer,cpu,database,hardware,network)',
				),
				array(
					'fas fa-sim-card' => 'Sim Card (hard drive,hardware,portable,storage,technology,tiny)',
				),
				array(
					'fas fa-tablet' => 'Tablet (tablet-android,device,kindle,screen)',
				),
				array(
					'fas fa-tablet-button' => 'Tablet Button (apple,device,ipad,kindle,screen)',
				),
				array(
					'fas fa-tablet-screen-button' => 'Tablet Screen Button (tablet-alt,apple,device,ipad,kindle,screen)',
				),
				array(
					'fas fa-tachograph-digital' => 'Tachograph Digital (digital-tachograph,data,distance,speed,tachometer)',
				),
				array(
					'fas fa-tv' => 'Tv (television,tv-alt,computer,display,monitor,television)',
				),
				array(
					'fas fa-upload' => 'Upload (hard drive,import,publish)',
				),
				array(
					'fas fa-walkie-talkie' => 'Walkie Talkie (communication,copy,intercom,over,portable,radio,two way radio)',
				),
			),
			'Disaster + Crisis' => array(
				array(
					'fas fa-biohazard' => 'Biohazard (biohazard,covid-19,danger,dangerous,epidemic,hazmat,medical,pandemic,radioactive,sign,toxic,waste,zombie)',
				),
				array(
					'fas fa-bugs' => 'Bugs (bedbug,infestation,lice,plague,ticks)',
				),
				array(
					'fas fa-burst' => 'Burst (boom,crash,explosion)',
				),
				array(
					'fas fa-child-combatant' => 'Child Combatant (child-rifle,combatant)',
				),
				array(
					'fas fa-circle-radiation' => 'Circle Radiation (radiation-alt,danger,dangerous,deadly,hazard,nuclear,radioactive,sign,warning)',
				),
				array(
					'fas fa-cloud-bolt' => 'Cloud Bolt (thunderstorm,bolt,cloud,cloud with lightning,lightning,precipitation,rain,storm,weather)',
				),
				array(
					'fas fa-cloud-showers-heavy' => 'Cloud Showers Heavy (precipitation,rain,sky,storm)',
				),
				array(
					'fas fa-cloud-showers-water' => 'Cloud Showers Water (cloud,deluge,flood,rain,storm,surge)',
				),
				array(
					'fas fa-helmet-un' => 'Helmet Un (helmet,united nations)',
				),
				array(
					'fas fa-hill-avalanche' => 'Hill Avalanche (mudslide,snow,winter)',
				),
				array(
					'fas fa-hill-rockslide' => 'Hill Rockslide (mudslide)',
				),
				array(
					'fas fa-house-chimney-crack' => 'House Chimney Crack (house-damage,building,devastation,disaster,earthquake,home,insurance)',
				),
				array(
					'fas fa-house-crack' => 'House Crack (building,devastation,disaster,earthquake,home,insurance)',
				),
				array(
					'fas fa-house-fire' => 'House Fire (burn,emergency,home)',
				),
				array(
					'fas fa-house-flood-water' => 'House Flood Water (damage,flood,water)',
				),
				array(
					'fas fa-house-flood-water-circle-arrow-right' => 'House Flood Water Circle Arrow Right (damage,flood,water)',
				),
				array(
					'fas fa-house-tsunami' => 'House Tsunami (damage,flood,tidal wave,wave)',
				),
				array(
					'fas fa-hurricane' => 'Hurricane (coriolis effect,eye,storm,tropical cyclone,typhoon)',
				),
				array(
					'fas fa-locust' => 'Locust (horde,infestation,locust,plague,swarm)',
				),
				array(
					'fas fa-mosquito' => 'Mosquito (bite,bug,mosquito,west nile)',
				),
				array(
					'fas fa-person-drowning' => 'Person Drowning (drown,emergency,swim)',
				),
				array(
					'fas fa-person-rifle' => 'Person Rifle (army,combatant,gun,military,rifle,war)',
				),
				array(
					'fas fa-person-walking-arrow-loop-left' => 'Person Walking Arrow Loop Left (population return,return)',
				),
				array(
					'fas fa-person-walking-arrow-right' => 'Person Walking Arrow Right (exit,internally displaced,leave,refugee)',
				),
				array(
					'fas fa-person-walking-dashed-line-arrow-right' => 'Person Walking Dashed Line Arrow Right (exit,refugee)',
				),
				array(
					'fas fa-plant-wilt' => 'Plant Wilt (drought,planting,vegetation,wilt)',
				),
				array(
					'fas fa-radiation' => 'Radiation (danger,dangerous,deadly,hazard,nuclear,radioactive,warning)',
				),
				array(
					'fas fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'far fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'fas fa-sun-plant-wilt' => 'Sun Plant Wilt (arid,droop,drought)',
				),
				array(
					'fas fa-temperature-arrow-down' => 'Temperature Arrow Down (temperature-down,air conditioner,cold,heater,mercury,thermometer,winter)',
				),
				array(
					'fas fa-temperature-arrow-up' => 'Temperature Arrow Up (temperature-up,air conditioner,cold,heater,mercury,thermometer,winter)',
				),
				array(
					'fas fa-tornado' => 'Tornado (cloud,cyclone,dorothy,landspout,tornado,toto,twister,vortext,waterspout,weather,whirlwind)',
				),
				array(
					'fas fa-volcano' => 'Volcano (caldera,eruption,lava,magma,mountain,smoke,volcano)',
				),
				array(
					'fas fa-wheat-awn-circle-exclamation' => 'Wheat Awn Circle Exclamation (affected,famine,food,gluten,hunger,starve,straw)',
				),
				array(
					'fas fa-wind' => 'Wind (air,blow,breeze,fall,seasonal,weather)',
				),
				array(
					'fas fa-worm' => 'Worm (dirt,garden,worm,wriggle)',
				),
				array(
					'fas fa-xmarks-lines' => 'Xmarks Lines (barricade,barrier,fence,poison,roadblock)',
				),
			),
			'Editing' => array(
				array(
					'fas fa-arrows-rotate' => 'Arrows Rotate (refresh,sync,Clockwise Right and Left Semicircle Arrows,exchange,refresh,reload,rotate,swap)',
				),
				array(
					'fas fa-bandage' => 'Bandage (band-aid,adhesive bandage,bandage,boo boo,first aid,ouch)',
				),
				array(
					'fas fa-bars' => 'Bars (navicon,checklist,drag,hamburger,list,menu,nav,navigation,ol,reorder,settings,todo,ul)',
				),
				array(
					'fas fa-brush' => 'Brush (art,bristles,color,handle,paint)',
				),
				array(
					'fas fa-chart-simple' => 'Chart Simple (analytics,bar,chart,column,graph,row,trend)',
				),
				array(
					'fas fa-check' => 'Check (Check Mark,accept,agree,check,check mark,checkmark,confirm,correct,done,mark,notice,notification,notify,ok,select,success,tick,todo,yes,✓)',
				),
				array(
					'fas fa-check-double' => 'Check Double (accept,agree,checkmark,confirm,correct,done,notice,notification,notify,ok,select,success,tick,todo)',
				),
				array(
					'fas fa-circle-check' => 'Circle Check (check-circle,accept,affected,agree,clear,confirm,correct,done,ok,select,success,tick,todo,yes)',
				),
				array(
					'far fa-circle-check' => 'Circle Check (check-circle,accept,affected,agree,clear,confirm,correct,done,ok,select,success,tick,todo,yes)',
				),
				array(
					'fas fa-circle-half-stroke' => 'Circle Half Stroke (adjust,Circle with Left Half Black,adjust,chart,contrast,dark,fill,light,pie,progress,saturation)',
				),
				array(
					'fas fa-crop' => 'Crop (design,frame,mask,resize,shrink)',
				),
				array(
					'fas fa-crop-simple' => 'Crop Simple (crop-alt,design,frame,mask,resize,shrink)',
				),
				array(
					'fas fa-cube' => 'Cube (3d,block,dice,package,square,tesseract)',
				),
				array(
					'fas fa-delete-left' => 'Delete Left (backspace,Erase to the Left,command,delete,erase,keyboard,undo)',
				),
				array(
					'fas fa-ellipsis' => 'Ellipsis (ellipsis-h,dots,drag,kebab,list,menu,nav,navigation,ol,pacman,reorder,settings,ul)',
				),
				array(
					'fas fa-ellipsis-vertical' => 'Ellipsis Vertical (ellipsis-v,dots,drag,kebab,list,menu,nav,navigation,ol,reorder,settings,ul)',
				),
				array(
					'fas fa-eye-dropper' => 'Eye Dropper (eye-dropper-empty,eyedropper,beaker,clone,color,copy,eyedropper,pipette)',
				),
				array(
					'fas fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'far fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'fas fa-gear' => 'Gear (cog,cog,cogwheel,gear,mechanical,settings,sprocket,tool,wheel)',
				),
				array(
					'fas fa-grip' => 'Grip (grip-horizontal,affordance,drag,drop,grab,handle)',
				),
				array(
					'fas fa-grip-lines' => 'Grip Lines (affordance,drag,drop,grab,handle)',
				),
				array(
					'fas fa-grip-lines-vertical' => 'Grip Lines Vertical (affordance,drag,drop,grab,handle)',
				),
				array(
					'fas fa-grip-vertical' => 'Grip Vertical (affordance,drag,drop,grab,handle)',
				),
				array(
					'fas fa-link' => 'Link (chain,attach,attachment,chain,connect,lin,link)',
				),
				array(
					'fas fa-link-slash' => 'Link Slash (chain-broken,chain-slash,unlink,attachment,chain,chain-broken,remove)',
				),
				array(
					'fas fa-minus' => 'Minus (subtract,En Dash,Minus Sign,collapse,delete,hide,math,minify,minus,negative,remove,sign,trash,−)',
				),
				array(
					'fas fa-paintbrush' => 'Paintbrush (paint-brush,acrylic,art,brush,color,fill,paint,paintbrush,painting,pigment,watercolor)',
				),
				array(
					'fas fa-pen' => 'Pen (ballpoint,design,edit,pen,update,write)',
				),
				array(
					'fas fa-pen-clip' => 'Pen Clip (pen-alt,design,edit,update,write)',
				),
				array(
					'fas fa-pen-fancy' => 'Pen Fancy (black nib,design,edit,fountain,fountain pen,nib,pen,update,write)',
				),
				array(
					'fas fa-pen-nib' => 'Pen Nib (design,edit,fountain pen,update,write)',
				),
				array(
					'fas fa-pen-ruler' => 'Pen Ruler (pencil-ruler,design,draft,draw,pencil)',
				),
				array(
					'fas fa-pen-to-square' => 'Pen To Square (edit,edit,pen,pencil,update,write)',
				),
				array(
					'far fa-pen-to-square' => 'Pen To Square (edit,edit,pen,pencil,update,write)',
				),
				array(
					'fas fa-pencil' => 'Pencil (pencil-alt,Lower Left Pencil,design,draw,edit,lead,pencil,update,write)',
				),
				array(
					'fas fa-plus' => 'Plus (add,+,Plus Sign,add,create,expand,math,new,plus,positive,shape,sign)',
				),
				array(
					'fas fa-rotate' => 'Rotate (sync-alt,anticlockwise,arrow,counterclockwise,counterclockwise arrows button,exchange,refresh,reload,rotate,swap,withershins)',
				),
				array(
					'fas fa-scissors' => 'Scissors (cut,Black Safety Scissors,White Scissors,clip,cutting,scissors,snip,tool)',
				),
				array(
					'fas fa-signature' => 'Signature (John Hancock,cursive,name,writing)',
				),
				array(
					'fas fa-sliders' => 'Sliders (sliders-h,adjust,settings,sliders,toggle)',
				),
				array(
					'fas fa-square-check' => 'Square Check (check-square,accept,agree,box,button,check,check box with check,check mark button,checkmark,confirm,correct,done,mark,ok,select,success,tick,todo,yes,✓)',
				),
				array(
					'far fa-square-check' => 'Square Check (check-square,accept,agree,box,button,check,check box with check,check mark button,checkmark,confirm,correct,done,mark,ok,select,success,tick,todo,yes,✓)',
				),
				array(
					'fas fa-square-pen' => 'Square Pen (pen-square,pencil-square,edit,pencil-square,update,write)',
				),
				array(
					'fas fa-trash' => 'Trash (delete,garbage,hide,remove)',
				),
				array(
					'fas fa-trash-arrow-up' => 'Trash Arrow Up (trash-restore,back,control z,delete,garbage,hide,oops,remove,undo)',
				),
				array(
					'fas fa-trash-can' => 'Trash Can (trash-alt,delete,garbage,hide,remove,trash-o)',
				),
				array(
					'far fa-trash-can' => 'Trash Can (trash-alt,delete,garbage,hide,remove,trash-o)',
				),
				array(
					'fas fa-trash-can-arrow-up' => 'Trash Can Arrow Up (trash-restore-alt,back,control z,delete,garbage,hide,oops,remove,undo)',
				),
				array(
					'fas fa-wand-magic' => 'Wand Magic (magic,autocomplete,automatic,mage,magic,spell,wand,witch,wizard)',
				),
				array(
					'fas fa-wand-magic-sparkles' => 'Wand Magic Sparkles (magic-wand-sparkles,auto,magic,magic wand,trick,witch,wizard)',
				),
				array(
					'fas fa-xmark' => 'Xmark (close,multiply,remove,times,Cancellation X,Multiplication Sign,Multiplication X,cancel,close,cross,cross mark,error,exit,incorrect,mark,multiplication,multiply,notice,notification,notify,problem,sign,wrong,x,×)',
				),
			),
			'Education' => array(
				array(
					'fas fa-apple-whole' => 'Apple Whole (apple-alt,apple,fall,fruit,fuji,green,green apple,macintosh,orchard,red,red apple,seasonal,vegan)',
				),
				array(
					'fas fa-atom' => 'Atom (atheism,atheist,atom,atom symbol,chemistry,electron,ion,isotope,neutron,nuclear,proton,science)',
				),
				array(
					'fas fa-award' => 'Award (honor,praise,prize,recognition,ribbon,trophy)',
				),
				array(
					'fas fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'far fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'fas fa-bell-slash' => 'Bell Slash (alert,bell,bell with slash,cancel,disabled,forbidden,mute,notification,off,quiet,reminder,silent)',
				),
				array(
					'far fa-bell-slash' => 'Bell Slash (alert,bell,bell with slash,cancel,disabled,forbidden,mute,notification,off,quiet,reminder,silent)',
				),
				array(
					'fas fa-book-open' => 'Book Open (Book,book,flyer,library,notebook,open,open book,pamphlet,reading,research)',
				),
				array(
					'fas fa-book-open-reader' => 'Book Open Reader (book-reader,flyer,library,notebook,open book,pamphlet,reading,research)',
				),
				array(
					'fas fa-chalkboard' => 'Chalkboard (blackboard,blackboard,learning,school,teaching,whiteboard,writing)',
				),
				array(
					'fas fa-chalkboard-user' => 'Chalkboard User (chalkboard-teacher,blackboard,instructor,learning,professor,school,whiteboard,writing)',
				),
				array(
					'fas fa-graduation-cap' => 'Graduation Cap (mortar-board,cap,celebration,ceremony,clothing,college,graduate,graduation,graduation cap,hat,learning,school,student)',
				),
				array(
					'fas fa-laptop-code' => 'Laptop Code (computer,cpu,dell,demo,develop,device,mac,macbook,machine,pc)',
				),
				array(
					'fas fa-laptop-file' => 'Laptop File (computer,education,laptop,learning,remote work)',
				),
				array(
					'fas fa-masks-theater' => 'Masks Theater (theater-masks,art,comedy,mask,perform,performing,performing arts,theater,theatre,tragedy)',
				),
				array(
					'fas fa-microscope' => 'Microscope (covid-19,electron,lens,microscope,optics,science,shrink,testing,tool)',
				),
				array(
					'fas fa-music' => 'Music (lyrics,melody,music,musical note,note,sing,sound)',
				),
				array(
					'fas fa-person-chalkboard' => 'Person Chalkboard (blackboard,instructor,keynote,lesson,presentation,teacher)',
				),
				array(
					'fas fa-school' => 'School (building,education,learn,school,student,teacher)',
				),
				array(
					'fas fa-school-circle-check' => 'School Circle Check (not affected,ok,okay,schoolhouse)',
				),
				array(
					'fas fa-school-circle-exclamation' => 'School Circle Exclamation (affected,schoolhouse)',
				),
				array(
					'fas fa-school-circle-xmark' => 'School Circle Xmark (destroy,schoolhouse)',
				),
				array(
					'fas fa-school-flag' => 'School Flag (educate,flag,school,schoolhouse)',
				),
				array(
					'fas fa-school-lock' => 'School Lock (closed,lockdown,quarantine,schoolhouse)',
				),
				array(
					'fas fa-shapes' => 'Shapes (triangle-circle-square,blocks,build,circle,square,triangle)',
				),
				array(
					'fas fa-user-graduate' => 'User Graduate (users-people)',
				),
			),
			'Emoji' => array(
				array(
					'fas fa-face-angry' => 'Face Angry (angry,angry,angry face,disapprove,emoticon,face,mad,upset)',
				),
				array(
					'far fa-face-angry' => 'Face Angry (angry,angry,angry face,disapprove,emoticon,face,mad,upset)',
				),
				array(
					'fas fa-face-dizzy' => 'Face Dizzy (dizzy,dazed,dead,disapprove,emoticon,face)',
				),
				array(
					'far fa-face-dizzy' => 'Face Dizzy (dizzy,dazed,dead,disapprove,emoticon,face)',
				),
				array(
					'fas fa-face-flushed' => 'Face Flushed (flushed,dazed,embarrassed,emoticon,face,flushed,flushed face)',
				),
				array(
					'far fa-face-flushed' => 'Face Flushed (flushed,dazed,embarrassed,emoticon,face,flushed,flushed face)',
				),
				array(
					'fas fa-face-frown' => 'Face Frown (frown,disapprove,emoticon,face,frown,frowning face,rating,sad)',
				),
				array(
					'far fa-face-frown' => 'Face Frown (frown,disapprove,emoticon,face,frown,frowning face,rating,sad)',
				),
				array(
					'fas fa-face-frown-open' => 'Face Frown Open (frown-open,disapprove,emoticon,face,frown,frowning face with open mouth,mouth,open,rating,sad)',
				),
				array(
					'far fa-face-frown-open' => 'Face Frown Open (frown-open,disapprove,emoticon,face,frown,frowning face with open mouth,mouth,open,rating,sad)',
				),
				array(
					'fas fa-face-grimace' => 'Face Grimace (grimace,cringe,emoticon,face,grimace,grimacing face,teeth)',
				),
				array(
					'far fa-face-grimace' => 'Face Grimace (grimace,cringe,emoticon,face,grimace,grimacing face,teeth)',
				),
				array(
					'fas fa-face-grin' => 'Face Grin (grin,emoticon,face,grin,grinning face,laugh,smile)',
				),
				array(
					'far fa-face-grin' => 'Face Grin (grin,emoticon,face,grin,grinning face,laugh,smile)',
				),
				array(
					'fas fa-face-grin-beam' => 'Face Grin Beam (grin-beam,emoticon,eye,face,grinning face with smiling eyes,laugh,mouth,open,smile)',
				),
				array(
					'far fa-face-grin-beam' => 'Face Grin Beam (grin-beam,emoticon,eye,face,grinning face with smiling eyes,laugh,mouth,open,smile)',
				),
				array(
					'fas fa-face-grin-beam-sweat' => 'Face Grin Beam Sweat (grin-beam-sweat,cold,embarass,emoticon,face,grinning face with sweat,open,smile,sweat)',
				),
				array(
					'far fa-face-grin-beam-sweat' => 'Face Grin Beam Sweat (grin-beam-sweat,cold,embarass,emoticon,face,grinning face with sweat,open,smile,sweat)',
				),
				array(
					'fas fa-face-grin-hearts' => 'Face Grin Hearts (grin-hearts,emoticon,eye,face,love,smile,smiling face with heart-eyes)',
				),
				array(
					'far fa-face-grin-hearts' => 'Face Grin Hearts (grin-hearts,emoticon,eye,face,love,smile,smiling face with heart-eyes)',
				),
				array(
					'fas fa-face-grin-squint' => 'Face Grin Squint (grin-squint,emoticon,face,grinning squinting face,laugh,mouth,satisfied,smile)',
				),
				array(
					'far fa-face-grin-squint' => 'Face Grin Squint (grin-squint,emoticon,face,grinning squinting face,laugh,mouth,satisfied,smile)',
				),
				array(
					'fas fa-face-grin-squint-tears' => 'Face Grin Squint Tears (grin-squint-tears,emoticon,face,floor,happy,laugh,rolling,rolling on the floor laughing,smile)',
				),
				array(
					'far fa-face-grin-squint-tears' => 'Face Grin Squint Tears (grin-squint-tears,emoticon,face,floor,happy,laugh,rolling,rolling on the floor laughing,smile)',
				),
				array(
					'fas fa-face-grin-stars' => 'Face Grin Stars (grin-stars,emoticon,eyes,face,grinning,star,star-struck,starry-eyed)',
				),
				array(
					'far fa-face-grin-stars' => 'Face Grin Stars (grin-stars,emoticon,eyes,face,grinning,star,star-struck,starry-eyed)',
				),
				array(
					'fas fa-face-grin-tears' => 'Face Grin Tears (grin-tears,LOL,emoticon,face,face with tears of joy,joy,laugh,tear)',
				),
				array(
					'far fa-face-grin-tears' => 'Face Grin Tears (grin-tears,LOL,emoticon,face,face with tears of joy,joy,laugh,tear)',
				),
				array(
					'fas fa-face-grin-tongue' => 'Face Grin Tongue (grin-tongue,LOL,emoticon,face,face with tongue,tongue)',
				),
				array(
					'far fa-face-grin-tongue' => 'Face Grin Tongue (grin-tongue,LOL,emoticon,face,face with tongue,tongue)',
				),
				array(
					'fas fa-face-grin-tongue-squint' => 'Face Grin Tongue Squint (grin-tongue-squint,LOL,emoticon,eye,face,horrible,squinting face with tongue,taste,tongue)',
				),
				array(
					'far fa-face-grin-tongue-squint' => 'Face Grin Tongue Squint (grin-tongue-squint,LOL,emoticon,eye,face,horrible,squinting face with tongue,taste,tongue)',
				),
				array(
					'fas fa-face-grin-tongue-wink' => 'Face Grin Tongue Wink (grin-tongue-wink,LOL,emoticon,eye,face,joke,tongue,wink,winking face with tongue)',
				),
				array(
					'far fa-face-grin-tongue-wink' => 'Face Grin Tongue Wink (grin-tongue-wink,LOL,emoticon,eye,face,joke,tongue,wink,winking face with tongue)',
				),
				array(
					'fas fa-face-grin-wide' => 'Face Grin Wide (grin-alt,emoticon,face,grinning face with big eyes,laugh,mouth,open,smile)',
				),
				array(
					'far fa-face-grin-wide' => 'Face Grin Wide (grin-alt,emoticon,face,grinning face with big eyes,laugh,mouth,open,smile)',
				),
				array(
					'fas fa-face-grin-wink' => 'Face Grin Wink (grin-wink,emoticon,face,flirt,laugh,smile)',
				),
				array(
					'far fa-face-grin-wink' => 'Face Grin Wink (grin-wink,emoticon,face,flirt,laugh,smile)',
				),
				array(
					'fas fa-face-kiss' => 'Face Kiss (kiss,beso,emoticon,face,kiss,kissing face,love,smooch)',
				),
				array(
					'far fa-face-kiss' => 'Face Kiss (kiss,beso,emoticon,face,kiss,kissing face,love,smooch)',
				),
				array(
					'fas fa-face-kiss-beam' => 'Face Kiss Beam (kiss-beam,beso,emoticon,eye,face,kiss,kissing face with smiling eyes,love,smile,smooch)',
				),
				array(
					'far fa-face-kiss-beam' => 'Face Kiss Beam (kiss-beam,beso,emoticon,eye,face,kiss,kissing face with smiling eyes,love,smile,smooch)',
				),
				array(
					'fas fa-face-kiss-wink-heart' => 'Face Kiss Wink Heart (kiss-wink-heart,beso,emoticon,face,face blowing a kiss,kiss,love,smooch)',
				),
				array(
					'far fa-face-kiss-wink-heart' => 'Face Kiss Wink Heart (kiss-wink-heart,beso,emoticon,face,face blowing a kiss,kiss,love,smooch)',
				),
				array(
					'fas fa-face-laugh' => 'Face Laugh (laugh,LOL,emoticon,face,laugh,smile)',
				),
				array(
					'far fa-face-laugh' => 'Face Laugh (laugh,LOL,emoticon,face,laugh,smile)',
				),
				array(
					'fas fa-face-laugh-beam' => 'Face Laugh Beam (laugh-beam,LOL,beaming face with smiling eyes,emoticon,eye,face,grin,happy,smile)',
				),
				array(
					'far fa-face-laugh-beam' => 'Face Laugh Beam (laugh-beam,LOL,beaming face with smiling eyes,emoticon,eye,face,grin,happy,smile)',
				),
				array(
					'fas fa-face-laugh-squint' => 'Face Laugh Squint (laugh-squint,LOL,emoticon,face,happy,smile)',
				),
				array(
					'far fa-face-laugh-squint' => 'Face Laugh Squint (laugh-squint,LOL,emoticon,face,happy,smile)',
				),
				array(
					'fas fa-face-laugh-wink' => 'Face Laugh Wink (laugh-wink,LOL,emoticon,face,happy,smile)',
				),
				array(
					'far fa-face-laugh-wink' => 'Face Laugh Wink (laugh-wink,LOL,emoticon,face,happy,smile)',
				),
				array(
					'fas fa-face-meh' => 'Face Meh (meh,deadpan,emoticon,face,meh,neutral,neutral face,rating)',
				),
				array(
					'far fa-face-meh' => 'Face Meh (meh,deadpan,emoticon,face,meh,neutral,neutral face,rating)',
				),
				array(
					'fas fa-face-meh-blank' => 'Face Meh Blank (meh-blank,emoticon,face,face without mouth,mouth,neutral,quiet,rating,silent)',
				),
				array(
					'far fa-face-meh-blank' => 'Face Meh Blank (meh-blank,emoticon,face,face without mouth,mouth,neutral,quiet,rating,silent)',
				),
				array(
					'fas fa-face-rolling-eyes' => 'Face Rolling Eyes (meh-rolling-eyes,emoticon,eyeroll,eyes,face,face with rolling eyes,neutral,rating,rolling)',
				),
				array(
					'far fa-face-rolling-eyes' => 'Face Rolling Eyes (meh-rolling-eyes,emoticon,eyeroll,eyes,face,face with rolling eyes,neutral,rating,rolling)',
				),
				array(
					'fas fa-face-sad-cry' => 'Face Sad Cry (sad-cry,cry,emoticon,face,loudly crying face,sad,sob,tear,tears)',
				),
				array(
					'far fa-face-sad-cry' => 'Face Sad Cry (sad-cry,cry,emoticon,face,loudly crying face,sad,sob,tear,tears)',
				),
				array(
					'fas fa-face-sad-tear' => 'Face Sad Tear (sad-tear,cry,crying face,emoticon,face,sad,tear,tears)',
				),
				array(
					'far fa-face-sad-tear' => 'Face Sad Tear (sad-tear,cry,crying face,emoticon,face,sad,tear,tears)',
				),
				array(
					'fas fa-face-smile' => 'Face Smile (smile,approve,emoticon,face,happy,rating,satisfied,slightly smiling face,smile)',
				),
				array(
					'far fa-face-smile' => 'Face Smile (smile,approve,emoticon,face,happy,rating,satisfied,slightly smiling face,smile)',
				),
				array(
					'fas fa-face-smile-beam' => 'Face Smile Beam (smile-beam,blush,emoticon,eye,face,happy,positive,smile,smiling face with smiling eyes)',
				),
				array(
					'far fa-face-smile-beam' => 'Face Smile Beam (smile-beam,blush,emoticon,eye,face,happy,positive,smile,smiling face with smiling eyes)',
				),
				array(
					'fas fa-face-smile-wink' => 'Face Smile Wink (smile-wink,emoticon,face,happy,hint,joke,wink,winking face)',
				),
				array(
					'far fa-face-smile-wink' => 'Face Smile Wink (smile-wink,emoticon,face,happy,hint,joke,wink,winking face)',
				),
				array(
					'fas fa-face-surprise' => 'Face Surprise (surprise,emoticon,face,face with open mouth,mouth,open,shocked,sympathy)',
				),
				array(
					'far fa-face-surprise' => 'Face Surprise (surprise,emoticon,face,face with open mouth,mouth,open,shocked,sympathy)',
				),
				array(
					'fas fa-face-tired' => 'Face Tired (tired,angry,emoticon,face,grumpy,tired,tired face,upset)',
				),
				array(
					'far fa-face-tired' => 'Face Tired (tired,angry,emoticon,face,grumpy,tired,tired face,upset)',
				),
			),
			'Energy' => array(
				array(
					'fas fa-arrow-up-from-ground-water' => 'Arrow Up From Ground Water (groundwater,spring,water supply,water table)',
				),
				array(
					'fas fa-atom' => 'Atom (atheism,atheist,atom,atom symbol,chemistry,electron,ion,isotope,neutron,nuclear,proton,science)',
				),
				array(
					'fas fa-battery-empty' => 'Battery Empty (battery-0,charge,dead,power,status)',
				),
				array(
					'fas fa-battery-full' => 'Battery Full (battery,battery-5,batter,battery,charge,power,status)',
				),
				array(
					'fas fa-battery-half' => 'Battery Half (battery-3,charge,power,status)',
				),
				array(
					'fas fa-battery-quarter' => 'Battery Quarter (battery-2,charge,low,power,status)',
				),
				array(
					'fas fa-battery-three-quarters' => 'Battery Three Quarters (battery-4,charge,power,status)',
				),
				array(
					'fas fa-bolt' => 'Bolt (zap,charge,danger,electric,electricity,flash,high voltage,lightning,voltage,weather,zap)',
				),
				array(
					'fas fa-car-battery' => 'Car Battery (battery-car,auto,electric,mechanic,power)',
				),
				array(
					'fas fa-charging-station' => 'Charging Station (electric,ev,tesla,vehicle)',
				),
				array(
					'fas fa-circle-radiation' => 'Circle Radiation (radiation-alt,danger,dangerous,deadly,hazard,nuclear,radioactive,sign,warning)',
				),
				array(
					'fas fa-explosion' => 'Explosion (blast,blowup,boom,crash,detonation,explosion)',
				),
				array(
					'fas fa-fan' => 'Fan (ac,air conditioning,blade,blower,cool,hot)',
				),
				array(
					'fas fa-fire' => 'Fire (burn,caliente,fire,flame,heat,hot,popular,tool)',
				),
				array(
					'fas fa-fire-flame-curved' => 'Fire Flame Curved (fire-alt,burn,caliente,flame,heat,hot,popular)',
				),
				array(
					'fas fa-fire-flame-simple' => 'Fire Flame Simple (burn,caliente,energy,fire,flame,gas,heat,hot)',
				),
				array(
					'fas fa-gas-pump' => 'Gas Pump (car,diesel,fuel,fuel pump,fuelpump,gas,gasoline,petrol,pump,station)',
				),
				array(
					'fas fa-industry' => 'Industry (building,factory,industrial,manufacturing,mill,warehouse)',
				),
				array(
					'fas fa-leaf' => 'Leaf (eco,flora,nature,plant,vegan)',
				),
				array(
					'fas fa-lightbulb' => 'Lightbulb (	comic,	electric,	idea,	innovation,	inspiration,	light,	light bulb, bulb,bulb,comic,electric,energy,idea,inspiration,mechanical)',
				),
				array(
					'far fa-lightbulb' => 'Lightbulb (	comic,	electric,	idea,	innovation,	inspiration,	light,	light bulb, bulb,bulb,comic,electric,energy,idea,inspiration,mechanical)',
				),
				array(
					'fas fa-oil-well' => 'Oil Well (drill,oil,rig)',
				),
				array(
					'fas fa-plug' => 'Plug (connect,electric,electric plug,electricity,online,plug,power)',
				),
				array(
					'fas fa-plug-circle-bolt' => 'Plug Circle Bolt (electric,electricity,plug,power)',
				),
				array(
					'fas fa-plug-circle-check' => 'Plug Circle Check (electric,electricity,not affected,ok,okay,plug,power)',
				),
				array(
					'fas fa-plug-circle-exclamation' => 'Plug Circle Exclamation (affected,electric,electricity,plug,power)',
				),
				array(
					'fas fa-plug-circle-minus' => 'Plug Circle Minus (electric,electricity,plug,power)',
				),
				array(
					'fas fa-plug-circle-plus' => 'Plug Circle Plus (electric,electricity,plug,power)',
				),
				array(
					'fas fa-plug-circle-xmark' => 'Plug Circle Xmark (destroy,electric,electricity,outage,plug,power)',
				),
				array(
					'fas fa-poop' => 'Poop (crap,poop,shit,smile,turd)',
				),
				array(
					'fas fa-power-off' => 'Power Off (Power Symbol,cancel,computer,on,reboot,restart)',
				),
				array(
					'fas fa-radiation' => 'Radiation (danger,dangerous,deadly,hazard,nuclear,radioactive,warning)',
				),
				array(
					'fas fa-seedling' => 'Seedling (sprout,environment,flora,grow,plant,sapling,seedling,vegan,young)',
				),
				array(
					'fas fa-solar-panel' => 'Solar Panel (clean,eco-friendly,energy,green,sun)',
				),
				array(
					'fas fa-sun' => 'Sun (bright,brighten,contrast,day,lighter,rays,sol,solar,star,sun,sunny,weather)',
				),
				array(
					'far fa-sun' => 'Sun (bright,brighten,contrast,day,lighter,rays,sol,solar,star,sun,sunny,weather)',
				),
				array(
					'fas fa-tower-broadcast' => 'Tower Broadcast (broadcast-tower,airwaves,antenna,communication,emergency,radio,reception,waves)',
				),
				array(
					'fas fa-water' => 'Water (lake,liquid,ocean,sea,swim,wet)',
				),
				array(
					'fas fa-wind' => 'Wind (air,blow,breeze,fall,seasonal,weather)',
				),
			),
			'Files' => array(
				array(
					'fas fa-box-archive' => 'Box Archive (archive,box,package,save,storage)',
				),
				array(
					'fas fa-clone' => 'Clone (arrange,copy,duplicate,paste)',
				),
				array(
					'far fa-clone' => 'Clone (arrange,copy,duplicate,paste)',
				),
				array(
					'fas fa-copy' => 'Copy (clone,duplicate,file,files-o,paper,paste)',
				),
				array(
					'far fa-copy' => 'Copy (clone,duplicate,file,files-o,paper,paste)',
				),
				array(
					'fas fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'far fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'fas fa-file-arrow-down' => 'File Arrow Down (file-download,document,export,save)',
				),
				array(
					'fas fa-file-arrow-up' => 'File Arrow Up (file-upload,document,import,page,save)',
				),
				array(
					'fas fa-file-audio' => 'File Audio (document,mp3,music,page,play,sound)',
				),
				array(
					'far fa-file-audio' => 'File Audio (document,mp3,music,page,play,sound)',
				),
				array(
					'fas fa-file-circle-check' => 'File Circle Check (document,file,not affected,ok,okay,paper)',
				),
				array(
					'fas fa-file-circle-exclamation' => 'File Circle Exclamation (document,file,paper)',
				),
				array(
					'fas fa-file-circle-minus' => 'File Circle Minus (document,file,paper)',
				),
				array(
					'fas fa-file-circle-plus' => 'File Circle Plus (add,document,file,new,page,paper,pdf)',
				),
				array(
					'fas fa-file-circle-question' => 'File Circle Question (document,file,paper)',
				),
				array(
					'fas fa-file-circle-xmark' => 'File Circle Xmark (document,file,paper)',
				),
				array(
					'fas fa-file-code' => 'File Code (css,development,document,html)',
				),
				array(
					'far fa-file-code' => 'File Code (css,development,document,html)',
				),
				array(
					'fas fa-file-csv' => 'File Csv (document,excel,numbers,spreadsheets,table)',
				),
				array(
					'fas fa-file-excel' => 'File Excel (csv,document,numbers,spreadsheets,table)',
				),
				array(
					'far fa-file-excel' => 'File Excel (csv,document,numbers,spreadsheets,table)',
				),
				array(
					'fas fa-file-export' => 'File Export (arrow-right-from-file,download,save)',
				),
				array(
					'fas fa-file-image' => 'File Image (Document with Picture,document,image,jpg,photo,png)',
				),
				array(
					'far fa-file-image' => 'File Image (Document with Picture,document,image,jpg,photo,png)',
				),
				array(
					'fas fa-file-import' => 'File Import (arrow-right-to-file,copy,document,send,upload)',
				),
				array(
					'fas fa-file-lines' => 'File Lines (file-alt,file-text,Document,Document with Text,document,file-text,invoice,new,page,pdf)',
				),
				array(
					'far fa-file-lines' => 'File Lines (file-alt,file-text,Document,Document with Text,document,file-text,invoice,new,page,pdf)',
				),
				array(
					'fas fa-file-pdf' => 'File Pdf (acrobat,document,preview,save)',
				),
				array(
					'far fa-file-pdf' => 'File Pdf (acrobat,document,preview,save)',
				),
				array(
					'fas fa-file-pen' => 'File Pen (file-edit,edit,memo,pen,pencil,update,write)',
				),
				array(
					'fas fa-file-powerpoint' => 'File Powerpoint (display,document,keynote,presentation)',
				),
				array(
					'far fa-file-powerpoint' => 'File Powerpoint (display,document,keynote,presentation)',
				),
				array(
					'fas fa-file-shield' => 'File Shield (antivirus,data,document,protect,safe,safety,secure)',
				),
				array(
					'fas fa-file-video' => 'File Video (document,m4v,movie,mp4,play)',
				),
				array(
					'far fa-file-video' => 'File Video (document,m4v,movie,mp4,play)',
				),
				array(
					'fas fa-file-word' => 'File Word (document,edit,page,text,writing)',
				),
				array(
					'far fa-file-word' => 'File Word (document,edit,page,text,writing)',
				),
				array(
					'fas fa-file-zipper' => 'File Zipper (file-archive,.zip,bundle,compress,compression,download,zip)',
				),
				array(
					'far fa-file-zipper' => 'File Zipper (file-archive,.zip,bundle,compress,compression,download,zip)',
				),
				array(
					'fas fa-floppy-disk' => 'Floppy Disk (save,Black Hard Shell Floppy Disk,computer,disk,download,floppy,floppy disk,floppy-o)',
				),
				array(
					'far fa-floppy-disk' => 'Floppy Disk (save,Black Hard Shell Floppy Disk,computer,disk,download,floppy,floppy disk,floppy-o)',
				),
				array(
					'fas fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'far fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'fas fa-folder-closed' => 'Folder Closed (file)',
				),
				array(
					'far fa-folder-closed' => 'Folder Closed (file)',
				),
				array(
					'fas fa-folder-open' => 'Folder Open (Open Folder,archive,directory,document,empty,file,folder,new,open,open file folder)',
				),
				array(
					'far fa-folder-open' => 'Folder Open (Open Folder,archive,directory,document,empty,file,folder,new,open,open file folder)',
				),
				array(
					'fas fa-note-sticky' => 'Note Sticky (sticky-note,message,note,paper,reminder,sticker)',
				),
				array(
					'far fa-note-sticky' => 'Note Sticky (sticky-note,message,note,paper,reminder,sticker)',
				),
				array(
					'fas fa-paste' => 'Paste (file-clipboard,clipboard,copy,document,paper)',
				),
				array(
					'far fa-paste' => 'Paste (file-clipboard,clipboard,copy,document,paper)',
				),
				array(
					'fas fa-photo-film' => 'Photo Film (photo-video,av,film,image,library,media)',
				),
				array(
					'fas fa-scissors' => 'Scissors (cut,Black Safety Scissors,White Scissors,clip,cutting,scissors,snip,tool)',
				),
			),
			'Film + Video' => array(
				array(
					'fas fa-audio-description' => 'Audio Description (blind,narration,video,visual)',
				),
				array(
					'fas fa-circle' => 'Circle (Black Circle,Black Large Circle,black circle,blue,blue circle,brown,brown circle,chart,circle,circle-thin,diameter,dot,ellipse,fill,geometric,green,green circle,notification,orange,orange circle,progress,purple,purple circle,red,red circle,round,white circle,yellow,yellow circle)',
				),
				array(
					'far fa-circle' => 'Circle (Black Circle,Black Large Circle,black circle,blue,blue circle,brown,brown circle,chart,circle,circle-thin,diameter,dot,ellipse,fill,geometric,green,green circle,notification,orange,orange circle,progress,purple,purple circle,red,red circle,round,white circle,yellow,yellow circle)',
				),
				array(
					'fas fa-clapperboard' => 'Clapperboard (camera,clapper,clapper board,director,film,movie,record)',
				),
				array(
					'fas fa-closed-captioning' => 'Closed Captioning (cc,deaf,hearing,subtitle,subtitling,text,video)',
				),
				array(
					'far fa-closed-captioning' => 'Closed Captioning (cc,deaf,hearing,subtitle,subtitling,text,video)',
				),
				array(
					'fas fa-compact-disc' => 'Compact Disc (Optical Disc Icon,album,blu-ray,bluray,cd,computer,disc,disk,dvd,media,movie,music,optical,optical disk,record,video,vinyl)',
				),
				array(
					'fas fa-file-audio' => 'File Audio (document,mp3,music,page,play,sound)',
				),
				array(
					'far fa-file-audio' => 'File Audio (document,mp3,music,page,play,sound)',
				),
				array(
					'fas fa-file-video' => 'File Video (document,m4v,movie,mp4,play)',
				),
				array(
					'far fa-file-video' => 'File Video (document,m4v,movie,mp4,play)',
				),
				array(
					'fas fa-film' => 'Film (cinema,film,film frames,frames,movie,strip,video)',
				),
				array(
					'fas fa-headphones' => 'Headphones (audio,earbud,headphone,listen,music,sound,speaker)',
				),
				array(
					'fas fa-microphone' => 'Microphone (address,audio,information,podcast,public,record,sing,sound,voice)',
				),
				array(
					'fas fa-microphone-lines' => 'Microphone Lines (microphone-alt,audio,mic,microphone,music,podcast,record,sing,sound,studio,studio microphone,voice)',
				),
				array(
					'fas fa-microphone-lines-slash' => 'Microphone Lines Slash (microphone-alt-slash,audio,disable,mute,podcast,record,sing,sound,voice)',
				),
				array(
					'fas fa-microphone-slash' => 'Microphone Slash (audio,disable,mute,podcast,record,sing,sound,voice)',
				),
				array(
					'fas fa-photo-film' => 'Photo Film (photo-video,av,film,image,library,media)',
				),
				array(
					'fas fa-podcast' => 'Podcast (audio,broadcast,music,sound)',
				),
				array(
					'fas fa-square-rss' => 'Square Rss (rss-square,blog,feed,journal,news,writing)',
				),
				array(
					'fas fa-ticket' => 'Ticket (admission,admission tickets,movie,pass,support,ticket)',
				),
				array(
					'fas fa-tower-broadcast' => 'Tower Broadcast (broadcast-tower,airwaves,antenna,communication,emergency,radio,reception,waves)',
				),
				array(
					'fas fa-tower-cell' => 'Tower Cell (airwaves,antenna,communication,radio,reception,waves)',
				),
				array(
					'fas fa-tv' => 'Tv (television,tv-alt,computer,display,monitor,television)',
				),
				array(
					'fas fa-video' => 'Video (video-camera,camera,film,movie,record,video-camera)',
				),
				array(
					'fas fa-video-slash' => 'Video Slash (add,create,film,new,positive,record,video)',
				),
				array(
					'fab fa-youtube' => 'YouTube (film,video,youtube-play,youtube-square)',
				),
			),
			'Food + Beverage' => array(
				array(
					'fas fa-apple-whole' => 'Apple Whole (apple-alt,apple,fall,fruit,fuji,green,green apple,macintosh,orchard,red,red apple,seasonal,vegan)',
				),
				array(
					'fas fa-bacon' => 'Bacon (bacon,blt,breakfast,food,ham,lard,meat,pancetta,pork,rasher)',
				),
				array(
					'fas fa-beer-mug-empty' => 'Beer Mug Empty (beer,alcohol,ale,bar,beverage,brew,brewery,drink,foam,lager,liquor,mug,stein)',
				),
				array(
					'fas fa-blender' => 'Blender (cocktail,milkshake,mixer,puree,smoothie)',
				),
				array(
					'fas fa-bone' => 'Bone (bone,calcium,dog,skeletal,skeleton,tibia)',
				),
				array(
					'fas fa-bottle-droplet' => 'Bottle Droplet (alcohol,drink,oil,olive oil,wine)',
				),
				array(
					'fas fa-bottle-water' => 'Bottle Water (h2o,plastic,water)',
				),
				array(
					'fas fa-bowl-food' => 'Bowl Food (catfood,dogfood,food,rice)',
				),
				array(
					'fas fa-bowl-rice' => 'Bowl Rice (boiled,cooked,cooked rice,rice,steamed)',
				),
				array(
					'fas fa-bread-slice' => 'Bread Slice (bake,bakery,baking,dough,flour,gluten,grain,sandwich,sourdough,toast,wheat,yeast)',
				),
				array(
					'fas fa-burger' => 'Burger (hamburger,bacon,beef,burger,burger king,cheeseburger,fast food,grill,ground beef,mcdonalds,sandwich)',
				),
				array(
					'fas fa-cake-candles' => 'Cake Candles (birthday-cake,cake,anniversary,bakery,birthday,birthday cake,cake,candles,celebration,dessert,frosting,holiday,party,pastry,sweet)',
				),
				array(
					'fas fa-candy-cane' => 'Candy Cane (candy,christmas,holiday,mint,peppermint,striped,xmas)',
				),
				array(
					'fas fa-carrot' => 'Carrot (bugs bunny,carrot,food,orange,vegan,vegetable)',
				),
				array(
					'fas fa-champagne-glasses' => 'Champagne Glasses (glass-cheers,alcohol,bar,beverage,celebrate,celebration,champagne,clink,clinking glasses,drink,glass,holiday,new year\'s eve,party,toast)',
				),
				array(
					'fas fa-cheese' => 'Cheese (cheddar,curd,gouda,melt,parmesan,sandwich,swiss,wedge)',
				),
				array(
					'fas fa-cloud-meatball' => 'Cloud Meatball (FLDSMDFR,food,spaghetti,storm)',
				),
				array(
					'fas fa-cookie' => 'Cookie (baked good,chips,chocolate,cookie,dessert,eat,snack,sweet,treat)',
				),
				array(
					'fas fa-cubes-stacked' => 'Cubes Stacked (blocks,cubes,sugar)',
				),
				array(
					'fas fa-drumstick-bite' => 'Drumstick Bite (bone,chicken,leg,meat,poultry,turkey)',
				),
				array(
					'fas fa-egg' => 'Egg (breakfast,chicken,easter,egg,food,shell,yolk)',
				),
				array(
					'fas fa-fish' => 'Fish (Pisces,fauna,fish,gold,seafood,swimming,zodiac)',
				),
				array(
					'fas fa-fish-fins' => 'Fish Fins (fish,fishery,pisces,seafood)',
				),
				array(
					'fas fa-flask' => 'Flask (beaker,chemicals,experiment,experimental,labs,liquid,potion,science,vial)',
				),
				array(
					'fas fa-glass-water' => 'Glass Water (potable,water)',
				),
				array(
					'fas fa-glass-water-droplet' => 'Glass Water Droplet (potable,water)',
				),
				array(
					'fas fa-hotdog' => 'Hotdog (bun,chili,frankfurt,frankfurter,hot dog,hotdog,kosher,polish,sandwich,sausage,vienna,weiner)',
				),
				array(
					'fas fa-ice-cream' => 'Ice Cream (chocolate,cone,cream,dessert,frozen,ice,ice cream,scoop,sorbet,sweet,vanilla,yogurt)',
				),
				array(
					'fas fa-jar' => 'Jar (jam,jelly,storage)',
				),
				array(
					'fas fa-jar-wheat' => 'Jar Wheat (flour,storage)',
				),
				array(
					'fas fa-lemon' => 'Lemon (citrus,fruit,lemon,lemonade,lime,tart)',
				),
				array(
					'far fa-lemon' => 'Lemon (citrus,fruit,lemon,lemonade,lime,tart)',
				),
				array(
					'fas fa-martini-glass' => 'Martini Glass (glass-martini-alt,alcohol,bar,beverage,cocktail,cocktail glass,drink,glass,liquor)',
				),
				array(
					'fas fa-martini-glass-citrus' => 'Martini Glass Citrus (cocktail,alcohol,beverage,drink,gin,glass,margarita,martini,vodka)',
				),
				array(
					'fas fa-martini-glass-empty' => 'Martini Glass Empty (glass-martini,alcohol,bar,beverage,drink,liquor)',
				),
				array(
					'fas fa-mug-hot' => 'Mug Hot (beverage,caliente,cocoa,coffee,cup,drink,holiday,hot,hot beverage,hot chocolate,steam,steaming,tea,warmth)',
				),
				array(
					'fas fa-mug-saucer' => 'Mug Saucer (coffee,beverage,breakfast,cafe,drink,fall,morning,mug,seasonal,tea)',
				),
				array(
					'fas fa-pepper-hot' => 'Pepper Hot (buffalo wings,capsicum,chili,chilli,habanero,hot,hot pepper,jalapeno,mexican,pepper,spicy,tabasco,vegetable)',
				),
				array(
					'fas fa-pizza-slice' => 'Pizza Slice (cheese,chicago,italian,mozzarella,new york,pepperoni,pie,slice,teenage mutant ninja turtles,tomato)',
				),
				array(
					'fas fa-plate-wheat' => 'Plate Wheat (bowl,hunger,rations,wheat)',
				),
				array(
					'fas fa-seedling' => 'Seedling (sprout,environment,flora,grow,plant,sapling,seedling,vegan,young)',
				),
				array(
					'fas fa-shrimp' => 'Shrimp (allergy,crustacean,prawn,seafood,shellfish,shrimp,tail)',
				),
				array(
					'fas fa-stroopwafel' => 'Stroopwafel (caramel,cookie,dessert,sweets,waffle)',
				),
				array(
					'fas fa-wheat-awn' => 'Wheat Awn (wheat-alt,agriculture,autumn,fall,farming,grain)',
				),
				array(
					'fas fa-wheat-awn-circle-exclamation' => 'Wheat Awn Circle Exclamation (affected,famine,food,gluten,hunger,starve,straw)',
				),
				array(
					'fas fa-whiskey-glass' => 'Whiskey Glass (glass-whiskey,alcohol,bar,beverage,bourbon,drink,glass,liquor,neat,rye,scotch,shot,tumbler,tumbler glass,whisky)',
				),
				array(
					'fas fa-wine-bottle' => 'Wine Bottle (alcohol,beverage,cabernet,drink,glass,grapes,merlot,sauvignon)',
				),
				array(
					'fas fa-wine-glass' => 'Wine Glass (alcohol,bar,beverage,cabernet,drink,glass,grapes,merlot,sauvignon,wine,wine glass)',
				),
				array(
					'fas fa-wine-glass-empty' => 'Wine Glass Empty (wine-glass-alt,alcohol,beverage,cabernet,drink,grapes,merlot,sauvignon)',
				),
			),
			'Fruits + Vegetables' => array(
				array(
					'fas fa-apple-whole' => 'Apple Whole (apple-alt,apple,fall,fruit,fuji,green,green apple,macintosh,orchard,red,red apple,seasonal,vegan)',
				),
				array(
					'fas fa-carrot' => 'Carrot (bugs bunny,carrot,food,orange,vegan,vegetable)',
				),
				array(
					'fas fa-leaf' => 'Leaf (eco,flora,nature,plant,vegan)',
				),
				array(
					'fas fa-lemon' => 'Lemon (citrus,fruit,lemon,lemonade,lime,tart)',
				),
				array(
					'far fa-lemon' => 'Lemon (citrus,fruit,lemon,lemonade,lime,tart)',
				),
				array(
					'fas fa-pepper-hot' => 'Pepper Hot (buffalo wings,capsicum,chili,chilli,habanero,hot,hot pepper,jalapeno,mexican,pepper,spicy,tabasco,vegetable)',
				),
				array(
					'fas fa-seedling' => 'Seedling (sprout,environment,flora,grow,plant,sapling,seedling,vegan,young)',
				),
			),
			'Gaming' => array(
				array(
					'fas fa-book-skull' => 'Book Skull (book-dead,Dungeons & Dragons,crossbones,d&d,dark arts,death,dnd,documentation,evil,fantasy,halloween,holiday,library,necronomicon,read,research,skull,spell)',
				),
				array(
					'fas fa-chess' => 'Chess (board,castle,checkmate,game,king,rook,strategy,tournament)',
				),
				array(
					'fas fa-chess-bishop' => 'Chess Bishop (Black Chess Bishop,board,checkmate,game,strategy)',
				),
				array(
					'far fa-chess-bishop' => 'Chess Bishop (Black Chess Bishop,board,checkmate,game,strategy)',
				),
				array(
					'fas fa-chess-board' => 'Chess Board (board,checkmate,game,strategy)',
				),
				array(
					'fas fa-chess-king' => 'Chess King (Black Chess King,board,checkmate,game,strategy)',
				),
				array(
					'far fa-chess-king' => 'Chess King (Black Chess King,board,checkmate,game,strategy)',
				),
				array(
					'fas fa-chess-knight' => 'Chess Knight (Black Chess Knight,board,checkmate,game,horse,strategy)',
				),
				array(
					'far fa-chess-knight' => 'Chess Knight (Black Chess Knight,board,checkmate,game,horse,strategy)',
				),
				array(
					'fas fa-chess-pawn' => 'Chess Pawn (board,checkmate,chess,chess pawn,dupe,expendable,game,strategy)',
				),
				array(
					'far fa-chess-pawn' => 'Chess Pawn (board,checkmate,chess,chess pawn,dupe,expendable,game,strategy)',
				),
				array(
					'fas fa-chess-queen' => 'Chess Queen (Black Chess Queen,board,checkmate,game,strategy)',
				),
				array(
					'far fa-chess-queen' => 'Chess Queen (Black Chess Queen,board,checkmate,game,strategy)',
				),
				array(
					'fas fa-chess-rook' => 'Chess Rook (Black Chess Rook,board,castle,checkmate,game,strategy)',
				),
				array(
					'far fa-chess-rook' => 'Chess Rook (Black Chess Rook,board,castle,checkmate,game,strategy)',
				),
				array(
					'fab fa-critical-role' => 'Critical Role (Dungeons & Dragons,d&d,dnd,fantasy,game,gaming,tabletop)',
				),
				array(
					'fab fa-d-and-d' => 'Dungeons & Dragons',
				),
				array(
					'fab fa-d-and-d-beyond' => 'D&D Beyond (Dungeons & Dragons,d&d,dnd,fantasy,gaming,tabletop)',
				),
				array(
					'fas fa-diamond' => 'Diamond (card,cards,diamond suit,game,gem,gemstone,poker,suit)',
				),
				array(
					'fas fa-dice' => 'Dice (chance,dice,die,gambling,game,game die,roll)',
				),
				array(
					'fas fa-dice-d20' => 'Dice D20 (Dungeons & Dragons,chance,d&d,dnd,fantasy,gambling,game,roll)',
				),
				array(
					'fas fa-dice-d6' => 'Dice D6 (Dungeons & Dragons,chance,d&d,dnd,fantasy,gambling,game,roll)',
				),
				array(
					'fas fa-dice-five' => 'Dice Five (Die Face-5,chance,gambling,game,roll)',
				),
				array(
					'fas fa-dice-four' => 'Dice Four (Die Face-4,chance,gambling,game,roll)',
				),
				array(
					'fas fa-dice-one' => 'Dice One (Die Face-1,chance,gambling,game,roll)',
				),
				array(
					'fas fa-dice-six' => 'Dice Six (Die Face-6,chance,gambling,game,roll)',
				),
				array(
					'fas fa-dice-three' => 'Dice Three (Die Face-3,chance,gambling,game,roll)',
				),
				array(
					'fas fa-dice-two' => 'Dice Two (Die Face-2,chance,gambling,game,roll)',
				),
				array(
					'fas fa-dragon' => 'Dragon (Dungeons & Dragons,d&d,dnd,dragon,fairy tale,fantasy,fire,lizard,serpent)',
				),
				array(
					'fas fa-dungeon' => 'Dungeon (Dungeons & Dragons,building,d&d,dnd,door,entrance,fantasy,gate)',
				),
				array(
					'fab fa-fantasy-flight-games' => 'Fantasy Flight-games (Dungeons & Dragons,d&d,dnd,fantasy,game,gaming,tabletop)',
				),
				array(
					'fas fa-gamepad' => 'Gamepad (arcade,controller,d-pad,joystick,video,video game)',
				),
				array(
					'fas fa-ghost' => 'Ghost (apparition,blinky,clyde,creature,face,fairy tale,fantasy,floating,ghost,halloween,holiday,inky,monster,pacman,pinky,spirit)',
				),
				array(
					'fas fa-hand-fist' => 'Hand Fist (fist-raised,Dungeons & Dragons,clenched,d&d,dnd,fantasy,fist,hand,ki,monk,punch,raised fist,resist,strength,unarmed combat)',
				),
				array(
					'fas fa-hat-wizard' => 'Hat Wizard (Dungeons & Dragons,accessory,buckle,clothing,d&d,dnd,fantasy,halloween,head,holiday,mage,magic,pointy,witch)',
				),
				array(
					'fas fa-headset' => 'Headset (audio,gamer,gaming,listen,live chat,microphone,shot caller,sound,support,telemarketer)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fab fa-playstation' => 'PlayStation',
				),
				array(
					'fas fa-puzzle-piece' => 'Puzzle Piece (add-on,addon,clue,game,interlocking,jigsaw,piece,puzzle,puzzle piece,section)',
				),
				array(
					'fas fa-ring' => 'Ring (Dungeons & Dragons,Gollum,band,binding,d&d,dnd,engagement,fantasy,gold,jewelry,marriage,precious)',
				),
				array(
					'fas fa-scroll' => 'Scroll (Dungeons & Dragons,announcement,d&d,dnd,fantasy,paper,script,scroll)',
				),
				array(
					'fas fa-shield-halved' => 'Shield Halved (shield-alt,achievement,armor,award,block,cleric,defend,defense,holy,paladin,security,shield,weapon,winner)',
				),
				array(
					'fas fa-skull-crossbones' => 'Skull Crossbones (Black Skull and Crossbones,Dungeons & Dragons,alert,bones,crossbones,d&d,danger,dangerous area,dead,deadly,death,dnd,face,fantasy,halloween,holiday,jolly-roger,monster,pirate,poison,skeleton,skull,skull and crossbones,warning)',
				),
				array(
					'fas fa-square-full' => 'Square Full (black large square,block,blue,blue square,box,brown,brown square,geometric,green,green square,orange,orange square,purple,purple square,red,red square,shape,square,white large square,yellow,yellow square)',
				),
				array(
					'far fa-square-full' => 'Square Full (black large square,block,blue,blue square,box,brown,brown square,geometric,green,green square,orange,orange square,purple,purple square,red,red square,shape,square,white large square,yellow,yellow square)',
				),
				array(
					'fab fa-square-steam' => 'Steam Square (steam-square)',
				),
				array(
					'fab fa-steam' => 'Steam',
				),
				array(
					'fab fa-steam-symbol' => 'Steam Symbol',
				),
				array(
					'fab fa-twitch' => 'Twitch',
				),
				array(
					'fas fa-vr-cardboard' => 'Vr Cardboard (3d,augment,google,reality,virtual)',
				),
				array(
					'fas fa-wand-sparkles' => 'Wand Sparkles (autocomplete,automatic,fantasy,halloween,holiday,magic,weapon,witch,wizard)',
				),
				array(
					'fab fa-wizards-of-the-coast' => 'Wizards of the Coast (Dungeons & Dragons,d&d,dnd,fantasy,game,gaming,tabletop)',
				),
				array(
					'fab fa-xbox' => 'Xbox',
				),
			),
			'Genders' => array(
				array(
					'fas fa-genderless' => 'Genderless (androgynous,asexual,gender,sexless)',
				),
				array(
					'fas fa-mars' => 'Mars (gender,male,male sign,man)',
				),
				array(
					'fas fa-mars-and-venus' => 'Mars And Venus (Male and Female Sign,female,gender,intersex,male,transgender)',
				),
				array(
					'fas fa-mars-double' => 'Mars Double (Doubled Male Sign,gay,gender,male,men)',
				),
				array(
					'fas fa-mars-stroke' => 'Mars Stroke (Male with Stroke Sign,gender,transgender)',
				),
				array(
					'fas fa-mars-stroke-right' => 'Mars Stroke Right (mars-stroke-h,Horizontal Male with Stroke Sign,gender)',
				),
				array(
					'fas fa-mars-stroke-up' => 'Mars Stroke Up (mars-stroke-v,Vertical Male with Stroke Sign,gender)',
				),
				array(
					'fas fa-mercury' => 'Mercury (Mercury,gender,hybrid,transgender)',
				),
				array(
					'fas fa-neuter' => 'Neuter (Neuter,gender)',
				),
				array(
					'fas fa-person-half-dress' => 'Person Half Dress (gender,man,restroom,transgender,woman)',
				),
				array(
					'fas fa-transgender' => 'Transgender (transgender-alt,female,gender,intersex,male,transgender,transgender symbol)',
				),
				array(
					'fas fa-venus' => 'Venus (female,female sign,gender,woman)',
				),
				array(
					'fas fa-venus-double' => 'Venus Double (Doubled Female Sign,female,gender,lesbian)',
				),
				array(
					'fas fa-venus-mars' => 'Venus Mars (Interlocked Female and Male Sign,female,gender,heterosexual,male)',
				),
			),
			'Halloween' => array(
				array(
					'fas fa-book-skull' => 'Book Skull (book-dead,Dungeons & Dragons,crossbones,d&d,dark arts,death,dnd,documentation,evil,fantasy,halloween,holiday,library,necronomicon,read,research,skull,spell)',
				),
				array(
					'fas fa-broom' => 'Broom (broom,clean,cleaning,firebolt,fly,halloween,nimbus 2000,quidditch,sweep,sweeping,witch)',
				),
				array(
					'fas fa-cat' => 'Cat (cat,feline,halloween,holiday,kitten,kitty,meow,pet)',
				),
				array(
					'fas fa-cloud-moon' => 'Cloud Moon (crescent,evening,lunar,night,partly cloudy,sky)',
				),
				array(
					'fas fa-crow' => 'Crow (bird,bullfrog,fauna,halloween,holiday,toad)',
				),
				array(
					'fas fa-ghost' => 'Ghost (apparition,blinky,clyde,creature,face,fairy tale,fantasy,floating,ghost,halloween,holiday,inky,monster,pacman,pinky,spirit)',
				),
				array(
					'fas fa-hat-wizard' => 'Hat Wizard (Dungeons & Dragons,accessory,buckle,clothing,d&d,dnd,fantasy,halloween,head,holiday,mage,magic,pointy,witch)',
				),
				array(
					'fas fa-mask' => 'Mask (carnivale,costume,disguise,halloween,secret,super hero)',
				),
				array(
					'fas fa-skull' => 'Skull (bones,death,face,fairy tale,monster,skeleton,skull,x-ray,yorick)',
				),
				array(
					'fas fa-skull-crossbones' => 'Skull Crossbones (Black Skull and Crossbones,Dungeons & Dragons,alert,bones,crossbones,d&d,danger,dangerous area,dead,deadly,death,dnd,face,fantasy,halloween,holiday,jolly-roger,monster,pirate,poison,skeleton,skull,skull and crossbones,warning)',
				),
				array(
					'fas fa-spider' => 'Spider (arachnid,bug,charlotte,crawl,eight,halloween,insect,spider)',
				),
				array(
					'fas fa-toilet-paper' => 'Toilet Paper (bathroom,covid-19,halloween,holiday,lavatory,paper towels,prank,privy,restroom,roll,roll of paper,toilet,toilet paper,wipe)',
				),
				array(
					'fas fa-wand-sparkles' => 'Wand Sparkles (autocomplete,automatic,fantasy,halloween,holiday,magic,weapon,witch,wizard)',
				),
			),
			'Hands' => array(
				array(
					'fas fa-hand' => 'Hand (hand-paper,Raised Hand,backhand,game,halt,palm,raised,raised back of hand,roshambo,stop)',
				),
				array(
					'far fa-hand' => 'Hand (hand-paper,Raised Hand,backhand,game,halt,palm,raised,raised back of hand,roshambo,stop)',
				),
				array(
					'fas fa-hand-back-fist' => 'Hand Back Fist (hand-rock,fist,game,roshambo)',
				),
				array(
					'far fa-hand-back-fist' => 'Hand Back Fist (hand-rock,fist,game,roshambo)',
				),
				array(
					'fas fa-hand-dots' => 'Hand Dots (allergies,allergy,freckles,hand,hives,palm,pox,skin,spots)',
				),
				array(
					'fas fa-hand-fist' => 'Hand Fist (fist-raised,Dungeons & Dragons,clenched,d&d,dnd,fantasy,fist,hand,ki,monk,punch,raised fist,resist,strength,unarmed combat)',
				),
				array(
					'fas fa-hand-holding' => 'Hand Holding (carry,lift)',
				),
				array(
					'fas fa-hand-holding-dollar' => 'Hand Holding Dollar (hand-holding-usd,$,carry,dollar sign,donation,giving,lift,money,price)',
				),
				array(
					'fas fa-hand-holding-droplet' => 'Hand Holding Droplet (hand-holding-water,carry,covid-19,drought,grow,lift,sanitation)',
				),
				array(
					'fas fa-hand-holding-hand' => 'Hand Holding Hand (care,give,help,hold,protect)',
				),
				array(
					'fas fa-hand-holding-heart' => 'Hand Holding Heart (carry,charity,gift,lift,package)',
				),
				array(
					'fas fa-hand-holding-medical' => 'Hand Holding Medical (care,covid-19,donate,help)',
				),
				array(
					'fas fa-hand-lizard' => 'Hand Lizard (game,roshambo)',
				),
				array(
					'far fa-hand-lizard' => 'Hand Lizard (game,roshambo)',
				),
				array(
					'fas fa-hand-middle-finger' => 'Hand Middle Finger (finger,flip the bird,gesture,hand,hate,middle finger,rude)',
				),
				array(
					'fas fa-hand-peace' => 'Hand Peace (hand,rest,truce,v,victory,victory hand)',
				),
				array(
					'far fa-hand-peace' => 'Hand Peace (hand,rest,truce,v,victory,victory hand)',
				),
				array(
					'fas fa-hand-point-down' => 'Hand Point Down (finger,hand-o-down,point)',
				),
				array(
					'far fa-hand-point-down' => 'Hand Point Down (finger,hand-o-down,point)',
				),
				array(
					'fas fa-hand-point-left' => 'Hand Point Left (back,finger,hand-o-left,left,point,previous)',
				),
				array(
					'far fa-hand-point-left' => 'Hand Point Left (back,finger,hand-o-left,left,point,previous)',
				),
				array(
					'fas fa-hand-point-right' => 'Hand Point Right (finger,forward,hand-o-right,next,point,right)',
				),
				array(
					'far fa-hand-point-right' => 'Hand Point Right (finger,forward,hand-o-right,next,point,right)',
				),
				array(
					'fas fa-hand-point-up' => 'Hand Point Up (finger,hand,hand-o-up,index,index pointing up,point,up)',
				),
				array(
					'far fa-hand-point-up' => 'Hand Point Up (finger,hand,hand-o-up,index,index pointing up,point,up)',
				),
				array(
					'fas fa-hand-pointer' => 'Hand Pointer (arrow,cursor,select)',
				),
				array(
					'far fa-hand-pointer' => 'Hand Pointer (arrow,cursor,select)',
				),
				array(
					'fas fa-hand-scissors' => 'Hand Scissors (cut,game,roshambo)',
				),
				array(
					'far fa-hand-scissors' => 'Hand Scissors (cut,game,roshambo)',
				),
				array(
					'fas fa-hand-sparkles' => 'Hand Sparkles (clean,covid-19,hygiene,magic,palm,soap,wash)',
				),
				array(
					'fas fa-hand-spock' => 'Hand Spock (finger,hand,live long,palm,prosper,salute,spock,star trek,vulcan,vulcan salute)',
				),
				array(
					'far fa-hand-spock' => 'Hand Spock (finger,hand,live long,palm,prosper,salute,spock,star trek,vulcan,vulcan salute)',
				),
				array(
					'fas fa-hands-bound' => 'Hands Bound (abduction,bound,handcuff,wrist)',
				),
				array(
					'fas fa-hands-bubbles' => 'Hands Bubbles (hands-wash,covid-19,hygiene,soap,wash)',
				),
				array(
					'fas fa-hands-clapping' => 'Hands Clapping (applause,clap,clapping hands,hand)',
				),
				array(
					'fas fa-hands-holding' => 'Hands Holding (carry,hold,lift)',
				),
				array(
					'fas fa-hands-holding-child' => 'Hands Holding Child (care,give,help,hold,protect)',
				),
				array(
					'fas fa-hands-holding-circle' => 'Hands Holding Circle (circle,gift,protection)',
				),
				array(
					'fas fa-hands-praying' => 'Hands Praying (praying-hands,kneel,preach,religion,worship)',
				),
				array(
					'fas fa-handshake' => 'Handshake (agreement,greeting,meeting,partnership)',
				),
				array(
					'far fa-handshake' => 'Handshake (agreement,greeting,meeting,partnership)',
				),
				array(
					'fas fa-handshake-angle' => 'Handshake Angle (hands-helping,aid,assistance,handshake,partnership,volunteering)',
				),
				array(
					'fas fa-handshake-simple' => 'Handshake Simple (handshake-alt,agreement,greeting,hand,handshake,meeting,partnership,shake)',
				),
				array(
					'fas fa-handshake-simple-slash' => 'Handshake Simple Slash (handshake-alt-slash,broken,covid-19,social distance)',
				),
				array(
					'fas fa-handshake-slash' => 'Handshake Slash (broken,covid-19,social distance)',
				),
				array(
					'fas fa-thumbs-down' => 'Thumbs Down (-1,disagree,disapprove,dislike,down,hand,social,thumb,thumbs down,thumbs-o-down)',
				),
				array(
					'far fa-thumbs-down' => 'Thumbs Down (-1,disagree,disapprove,dislike,down,hand,social,thumb,thumbs down,thumbs-o-down)',
				),
				array(
					'fas fa-thumbs-up' => 'Thumbs Up (+1,agree,approve,favorite,hand,like,ok,okay,social,success,thumb,thumbs up,thumbs-o-up,up,yes,you got it dude)',
				),
				array(
					'far fa-thumbs-up' => 'Thumbs Up (+1,agree,approve,favorite,hand,like,ok,okay,social,success,thumb,thumbs up,thumbs-o-up,up,yes,you got it dude)',
				),
			),
			'Holidays' => array(
				array(
					'fas fa-candy-cane' => 'Candy Cane (candy,christmas,holiday,mint,peppermint,striped,xmas)',
				),
				array(
					'fas fa-carrot' => 'Carrot (bugs bunny,carrot,food,orange,vegan,vegetable)',
				),
				array(
					'fas fa-champagne-glasses' => 'Champagne Glasses (glass-cheers,alcohol,bar,beverage,celebrate,celebration,champagne,clink,clinking glasses,drink,glass,holiday,new year\'s eve,party,toast)',
				),
				array(
					'fas fa-cookie-bite' => 'Cookie Bite (baked good,bitten,chips,chocolate,eat,snack,sweet,treat)',
				),
				array(
					'fas fa-face-grin-hearts' => 'Face Grin Hearts (grin-hearts,emoticon,eye,face,love,smile,smiling face with heart-eyes)',
				),
				array(
					'far fa-face-grin-hearts' => 'Face Grin Hearts (grin-hearts,emoticon,eye,face,love,smile,smiling face with heart-eyes)',
				),
				array(
					'fas fa-face-kiss-wink-heart' => 'Face Kiss Wink Heart (kiss-wink-heart,beso,emoticon,face,face blowing a kiss,kiss,love,smooch)',
				),
				array(
					'far fa-face-kiss-wink-heart' => 'Face Kiss Wink Heart (kiss-wink-heart,beso,emoticon,face,face blowing a kiss,kiss,love,smooch)',
				),
				array(
					'fas fa-gift' => 'Gift (box,celebration,christmas,generosity,gift,giving,holiday,party,present,wrapped,wrapped gift,xmas)',
				),
				array(
					'fas fa-gifts' => 'Gifts (christmas,generosity,giving,holiday,party,present,wrapped,xmas)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fas fa-holly-berry' => 'Holly Berry (catwoman,christmas,decoration,flora,halle,holiday,ororo munroe,plant,storm,xmas)',
				),
				array(
					'fas fa-menorah' => 'Menorah (candle,hanukkah,jewish,judaism,light)',
				),
				array(
					'fas fa-mug-hot' => 'Mug Hot (beverage,caliente,cocoa,coffee,cup,drink,holiday,hot,hot beverage,hot chocolate,steam,steaming,tea,warmth)',
				),
				array(
					'fas fa-sleigh' => 'Sleigh (christmas,claus,fly,holiday,santa,sled,snow,xmas)',
				),
				array(
					'fas fa-snowman' => 'Snowman (cold,decoration,frost,frosty,holiday,snow,snowman,snowman without snow)',
				),
			),
			'Household' => array(
				array(
					'fas fa-arrow-up-from-water-pump' => 'Arrow Up From Water Pump (flood,groundwater,pump,submersible,sump pump)',
				),
				array(
					'fas fa-bath' => 'Bath (bathtub,bath,bathtub,clean,shower,tub,wash)',
				),
				array(
					'fas fa-bed' => 'Bed (hospital,hotel,lodging,mattress,patient,person in bed,rest,sleep,travel)',
				),
				array(
					'fas fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'far fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'fas fa-blender' => 'Blender (cocktail,milkshake,mixer,puree,smoothie)',
				),
				array(
					'fas fa-box-tissue' => 'Box Tissue (cough,covid-19,kleenex,mucus,nose,sneeze,snot)',
				),
				array(
					'fas fa-chair' => 'Chair (chair,furniture,seat,sit)',
				),
				array(
					'fas fa-computer' => 'Computer (computer,desktop,display,monitor,tower)',
				),
				array(
					'fas fa-couch' => 'Couch (chair,cushion,furniture,relax,sofa)',
				),
				array(
					'fas fa-door-closed' => 'Door Closed (doo,door,enter,exit,locked)',
				),
				array(
					'fas fa-door-open' => 'Door Open (enter,exit,welcome)',
				),
				array(
					'fas fa-dungeon' => 'Dungeon (Dungeons & Dragons,building,d&d,dnd,door,entrance,fantasy,gate)',
				),
				array(
					'fas fa-fan' => 'Fan (ac,air conditioning,blade,blower,cool,hot)',
				),
				array(
					'fas fa-faucet' => 'Faucet (covid-19,drinking,drip,house,hygiene,kitchen,potable,potable water,sanitation,sink,water)',
				),
				array(
					'fas fa-faucet-drip' => 'Faucet Drip (drinking,drip,house,hygiene,kitchen,potable,potable water,sanitation,sink,water)',
				),
				array(
					'fas fa-fire-burner' => 'Fire Burner (cook,fire,flame,kitchen,stove)',
				),
				array(
					'fas fa-house-chimney-user' => 'House Chimney User (covid-19,home,isolation,quarantine)',
				),
				array(
					'fas fa-house-chimney-window' => 'House Chimney Window (abode,building,family,home,residence)',
				),
				array(
					'fas fa-house-fire' => 'House Fire (burn,emergency,home)',
				),
				array(
					'fas fa-house-laptop' => 'House Laptop (laptop-house,computer,covid-19,device,office,remote,work from home)',
				),
				array(
					'fas fa-house-lock' => 'House Lock (closed,home,house,lockdown,quarantine)',
				),
				array(
					'fas fa-house-signal' => 'House Signal (abode,building,connect,family,home,residence,smart home,wifi)',
				),
				array(
					'fas fa-house-user' => 'House User (home-user,house)',
				),
				array(
					'fas fa-jar' => 'Jar (jam,jelly,storage)',
				),
				array(
					'fas fa-jar-wheat' => 'Jar Wheat (flour,storage)',
				),
				array(
					'fas fa-jug-detergent' => 'Jug Detergent (detergent,laundry,soap,wash)',
				),
				array(
					'fas fa-kitchen-set' => 'Kitchen Set (chef,cook,cup,kitchen,pan,pot,skillet)',
				),
				array(
					'fas fa-lightbulb' => 'Lightbulb (	comic,	electric,	idea,	innovation,	inspiration,	light,	light bulb, bulb,bulb,comic,electric,energy,idea,inspiration,mechanical)',
				),
				array(
					'far fa-lightbulb' => 'Lightbulb (	comic,	electric,	idea,	innovation,	inspiration,	light,	light bulb, bulb,bulb,comic,electric,energy,idea,inspiration,mechanical)',
				),
				array(
					'fas fa-mattress-pillow' => 'Mattress Pillow (air mattress,mattress,pillow,rest,sleep)',
				),
				array(
					'fas fa-mug-saucer' => 'Mug Saucer (coffee,beverage,breakfast,cafe,drink,fall,morning,mug,seasonal,tea)',
				),
				array(
					'fas fa-people-roof' => 'People Roof (family,group,manage,people,safe,shelter)',
				),
				array(
					'fas fa-plug' => 'Plug (connect,electric,electric plug,electricity,online,plug,power)',
				),
				array(
					'fas fa-pump-soap' => 'Pump Soap (anti-bacterial,clean,covid-19,disinfect,hygiene,sanitizer,soap)',
				),
				array(
					'fas fa-rug' => 'Rug (blanket,carpet,rug,textile)',
				),
				array(
					'fas fa-sheet-plastic' => 'Sheet Plastic (plastic,plastic wrap,protect,tarp,tarpaulin,waterproof)',
				),
				array(
					'fas fa-shower' => 'Shower (bath,clean,faucet,shower,water)',
				),
				array(
					'fas fa-sink' => 'Sink (bathroom,covid-19,faucet,kitchen,wash)',
				),
				array(
					'fas fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'far fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'fas fa-soap' => 'Soap (bar,bathing,bubbles,clean,cleaning,covid-19,hygiene,lather,soap,soapdish,wash)',
				),
				array(
					'fas fa-spoon' => 'Spoon (utensil-spoon,cutlery,dining,scoop,silverware,spoon,tableware)',
				),
				array(
					'fas fa-stairs' => 'Stairs (exit,steps,up)',
				),
				array(
					'fas fa-temperature-arrow-down' => 'Temperature Arrow Down (temperature-down,air conditioner,cold,heater,mercury,thermometer,winter)',
				),
				array(
					'fas fa-temperature-arrow-up' => 'Temperature Arrow Up (temperature-up,air conditioner,cold,heater,mercury,thermometer,winter)',
				),
				array(
					'fas fa-toilet' => 'Toilet (bathroom,flush,john,loo,pee,plumbing,poop,porcelain,potty,restroom,throne,toile,toilet,washroom,waste,wc)',
				),
				array(
					'fas fa-toilet-paper' => 'Toilet Paper (bathroom,covid-19,halloween,holiday,lavatory,paper towels,prank,privy,restroom,roll,roll of paper,toilet,toilet paper,wipe)',
				),
				array(
					'fas fa-toilet-paper-slash' => 'Toilet Paper Slash (bathroom,covid-19,halloween,holiday,lavatory,leaves,prank,privy,restroom,roll,toilet,trouble,ut oh,wipe)',
				),
				array(
					'fas fa-tv' => 'Tv (television,tv-alt,computer,display,monitor,television)',
				),
				array(
					'fas fa-utensils' => 'Utensils (cutlery,cooking,cutlery,dining,dinner,eat,food,fork,fork and knife,knife,restaurant)',
				),
			),
			'Humanitarian' => array(
				array(
					'fas fa-anchor' => 'Anchor (anchor,berth,boat,dock,embed,link,maritime,moor,port,secure,ship,tool)',
				),
				array(
					'fas fa-anchor-circle-check' => 'Anchor Circle Check (marina,not affected,ok,okay,port)',
				),
				array(
					'fas fa-anchor-circle-exclamation' => 'Anchor Circle Exclamation (affected,marina,port)',
				),
				array(
					'fas fa-anchor-circle-xmark' => 'Anchor Circle Xmark (destroy,marina,port)',
				),
				array(
					'fas fa-anchor-lock' => 'Anchor Lock (closed,lockdown,marina,port,quarantine)',
				),
				array(
					'fas fa-arrow-down-up-across-line' => 'Arrow Down Up Across Line (border,crossing,transfer)',
				),
				array(
					'fas fa-arrow-down-up-lock' => 'Arrow Down Up Lock (border,closed,crossing,lockdown,quarantine,transfer)',
				),
				array(
					'fas fa-arrow-right-to-city' => 'Arrow Right To City (building,city,exodus,rural,urban)',
				),
				array(
					'fas fa-arrow-up-from-ground-water' => 'Arrow Up From Ground Water (groundwater,spring,water supply,water table)',
				),
				array(
					'fas fa-arrow-up-from-water-pump' => 'Arrow Up From Water Pump (flood,groundwater,pump,submersible,sump pump)',
				),
				array(
					'fas fa-arrow-up-right-dots' => 'Arrow Up Right Dots (growth,increase,population)',
				),
				array(
					'fas fa-arrow-up-right-from-square' => 'Arrow Up Right From Square (external-link,new,open,send,share)',
				),
				array(
					'fas fa-arrows-down-to-line' => 'Arrows Down To Line (scale down,sink)',
				),
				array(
					'fas fa-arrows-down-to-people' => 'Arrows Down To People (affected,focus,targeted)',
				),
				array(
					'fas fa-arrows-left-right-to-line' => 'Arrows Left Right To Line (analysis,expand,gap)',
				),
				array(
					'fas fa-arrows-spin' => 'Arrows Spin (cycle,rotate,spin,whirl)',
				),
				array(
					'fas fa-arrows-split-up-and-left' => 'Arrows Split Up And Left (agile,split)',
				),
				array(
					'fas fa-arrows-to-circle' => 'Arrows To Circle (center,concentrate,coordinate,coordination,focal point,focus)',
				),
				array(
					'fas fa-arrows-to-dot' => 'Arrows To Dot (assembly point,center,condense,focus,minimize)',
				),
				array(
					'fas fa-arrows-to-eye' => 'Arrows To Eye (center,coordinated assessment,focus)',
				),
				array(
					'fas fa-arrows-turn-right' => 'Arrows Turn Right (arrows)',
				),
				array(
					'fas fa-arrows-turn-to-dots' => 'Arrows Turn To Dots (destination,nexus)',
				),
				array(
					'fas fa-arrows-up-to-line' => 'Arrows Up To Line (rise,scale up)',
				),
				array(
					'fas fa-baby' => 'Baby (users-people)',
				),
				array(
					'fas fa-bacterium' => 'Bacterium (antibiotic,antibody,covid-19,health,organism,sick)',
				),
				array(
					'fas fa-ban' => 'Ban (cancel,abort,ban,block,cancel,delete,entry,forbidden,hide,no,not,prohibit,prohibited,remove,stop,trash)',
				),
				array(
					'fas fa-bed' => 'Bed (hospital,hotel,lodging,mattress,patient,person in bed,rest,sleep,travel)',
				),
				array(
					'fas fa-biohazard' => 'Biohazard (biohazard,covid-19,danger,dangerous,epidemic,hazmat,medical,pandemic,radioactive,sign,toxic,waste,zombie)',
				),
				array(
					'fas fa-book-bookmark' => 'Book Bookmark (library,research)',
				),
				array(
					'fas fa-bore-hole' => 'Bore Hole (bore,bury,drill,hole)',
				),
				array(
					'fas fa-bottle-droplet' => 'Bottle Droplet (alcohol,drink,oil,olive oil,wine)',
				),
				array(
					'fas fa-bottle-water' => 'Bottle Water (h2o,plastic,water)',
				),
				array(
					'fas fa-bowl-food' => 'Bowl Food (catfood,dogfood,food,rice)',
				),
				array(
					'fas fa-bowl-rice' => 'Bowl Rice (boiled,cooked,cooked rice,rice,steamed)',
				),
				array(
					'fas fa-boxes-packing' => 'Boxes Packing (archive,box,package,storage,supplies)',
				),
				array(
					'fas fa-bridge' => 'Bridge (bridge,road)',
				),
				array(
					'fas fa-bridge-circle-check' => 'Bridge Circle Check (bridge,not affected,ok,okay,road)',
				),
				array(
					'fas fa-bridge-circle-exclamation' => 'Bridge Circle Exclamation (affected,bridge,road)',
				),
				array(
					'fas fa-bridge-circle-xmark' => 'Bridge Circle Xmark (bridge,destroy,road)',
				),
				array(
					'fas fa-bridge-lock' => 'Bridge Lock (bridge,closed,lockdown,quarantine,road)',
				),
				array(
					'fas fa-bridge-water' => 'Bridge Water (bridge,road)',
				),
				array(
					'fas fa-bucket' => 'Bucket (bucket,pail,sandcastle)',
				),
				array(
					'fas fa-bugs' => 'Bugs (bedbug,infestation,lice,plague,ticks)',
				),
				array(
					'fas fa-building' => 'Building (apartment,building,business,city,company,office,office building,urban,work)',
				),
				array(
					'far fa-building' => 'Building (apartment,building,business,city,company,office,office building,urban,work)',
				),
				array(
					'fas fa-building-circle-arrow-right' => 'Building Circle Arrow Right (building,city,distribution center,office)',
				),
				array(
					'fas fa-building-circle-check' => 'Building Circle Check (building,city,not affected,office,ok,okay)',
				),
				array(
					'fas fa-building-circle-exclamation' => 'Building Circle Exclamation (affected,building,city,office)',
				),
				array(
					'fas fa-building-circle-xmark' => 'Building Circle Xmark (building,city,destroy,office)',
				),
				array(
					'fas fa-building-columns' => 'Building Columns (bank,institution,museum,university,bank,building,college,education,institution,museum,students)',
				),
				array(
					'fas fa-building-flag' => 'Building Flag ( city,building,diplomat,embassy,flag,headquarters,united nations)',
				),
				array(
					'fas fa-building-lock' => 'Building Lock (building,city,closed,lock,lockdown,quarantine,secure)',
				),
				array(
					'fas fa-building-ngo' => 'Building Ngo ( city,building,non governmental organization,office)',
				),
				array(
					'fas fa-building-shield' => 'Building Shield (building,city,police,protect,safety)',
				),
				array(
					'fas fa-building-un' => 'Building Un (building,city,office,united nations)',
				),
				array(
					'fas fa-building-user' => 'Building User (apartment,building,city)',
				),
				array(
					'fas fa-building-wheat' => 'Building Wheat (agriculture,building,city,usda)',
				),
				array(
					'fas fa-burst' => 'Burst (boom,crash,explosion)',
				),
				array(
					'fas fa-bus' => 'Bus (bus,oncoming,oncoming bus,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car' => 'Car (automobile,auto,automobile,car,oncoming,oncoming automobile,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car-on' => 'Car On (alarm,car,carjack,warning)',
				),
				array(
					'fas fa-car-tunnel' => 'Car Tunnel (road,tunnel)',
				),
				array(
					'fas fa-child-combatant' => 'Child Combatant (child-rifle,combatant)',
				),
				array(
					'fas fa-children' => 'Children (boy,child,girl,kid,kids,young,youth)',
				),
				array(
					'fas fa-church' => 'Church (Christian,building,cathedral,chapel,church,community,cross,religion)',
				),
				array(
					'fas fa-circle-h' => 'Circle H (hospital-symbol,Circled Latin Capital Letter H,clinic,covid-19,emergency,letter,map)',
				),
				array(
					'fas fa-circle-nodes' => 'Circle Nodes (cluster,connect,network)',
				),
				array(
					'fas fa-clipboard-question' => 'Clipboard Question (assistance,interview,query,question)',
				),
				array(
					'fas fa-clipboard-user' => 'Clipboard User (attendance,record,roster,staff)',
				),
				array(
					'fas fa-cloud-bolt' => 'Cloud Bolt (thunderstorm,bolt,cloud,cloud with lightning,lightning,precipitation,rain,storm,weather)',
				),
				array(
					'fas fa-cloud-showers-heavy' => 'Cloud Showers Heavy (precipitation,rain,sky,storm)',
				),
				array(
					'fas fa-cloud-showers-water' => 'Cloud Showers Water (cloud,deluge,flood,rain,storm,surge)',
				),
				array(
					'fas fa-computer' => 'Computer (computer,desktop,display,monitor,tower)',
				),
				array(
					'fas fa-cow' => 'Cow (agriculture,animal,beef,bovine,co,cow,farm,fauna,livestock,mammal,milk,moo)',
				),
				array(
					'fas fa-cubes-stacked' => 'Cubes Stacked (blocks,cubes,sugar)',
				),
				array(
					'fas fa-display' => 'Display (Screen,computer,desktop,imac)',
				),
				array(
					'fas fa-droplet' => 'Droplet (tint,cold,color,comic,drop,droplet,raindrop,sweat,waterdrop)',
				),
				array(
					'fas fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'far fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-envelope-circle-check' => 'Envelope Circle Check (check,email,envelope,mail,not affected,ok,okay,read,sent)',
				),
				array(
					'fas fa-explosion' => 'Explosion (blast,blowup,boom,crash,detonation,explosion)',
				),
				array(
					'fas fa-faucet-drip' => 'Faucet Drip (drinking,drip,house,hygiene,kitchen,potable,potable water,sanitation,sink,water)',
				),
				array(
					'fas fa-fax' => 'Fax (Fax Icon,business,communicate,copy,facsimile,fax,fax machine,send)',
				),
				array(
					'fas fa-ferry' => 'Ferry (barge,boat,carry,ferryboat,ship)',
				),
				array(
					'fas fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'far fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'fas fa-file-circle-check' => 'File Circle Check (document,file,not affected,ok,okay,paper)',
				),
				array(
					'fas fa-file-circle-exclamation' => 'File Circle Exclamation (document,file,paper)',
				),
				array(
					'fas fa-file-circle-minus' => 'File Circle Minus (document,file,paper)',
				),
				array(
					'fas fa-file-circle-plus' => 'File Circle Plus (add,document,file,new,page,paper,pdf)',
				),
				array(
					'fas fa-file-circle-question' => 'File Circle Question (document,file,paper)',
				),
				array(
					'fas fa-file-circle-xmark' => 'File Circle Xmark (document,file,paper)',
				),
				array(
					'fas fa-file-csv' => 'File Csv (document,excel,numbers,spreadsheets,table)',
				),
				array(
					'fas fa-file-pdf' => 'File Pdf (acrobat,document,preview,save)',
				),
				array(
					'far fa-file-pdf' => 'File Pdf (acrobat,document,preview,save)',
				),
				array(
					'fas fa-file-pen' => 'File Pen (file-edit,edit,memo,pen,pencil,update,write)',
				),
				array(
					'fas fa-file-shield' => 'File Shield (antivirus,data,document,protect,safe,safety,secure)',
				),
				array(
					'fas fa-fire-burner' => 'Fire Burner (cook,fire,flame,kitchen,stove)',
				),
				array(
					'fas fa-fire-flame-simple' => 'Fire Flame Simple (burn,caliente,energy,fire,flame,gas,heat,hot)',
				),
				array(
					'fas fa-fish-fins' => 'Fish Fins (fish,fishery,pisces,seafood)',
				),
				array(
					'fas fa-flag' => 'Flag (black flag,country,notice,notification,notify,pole,report,symbol,waving)',
				),
				array(
					'far fa-flag' => 'Flag (black flag,country,notice,notification,notify,pole,report,symbol,waving)',
				),
				array(
					'fas fa-flask-vial' => 'Flask Vial ( beaker, chemicals, experiment, experimental, labs, liquid, science, vial,ampule,chemistry,lab,laboratory,potion,test,test tube)',
				),
				array(
					'fas fa-gas-pump' => 'Gas Pump (car,diesel,fuel,fuel pump,fuelpump,gas,gasoline,petrol,pump,station)',
				),
				array(
					'fas fa-glass-water' => 'Glass Water (potable,water)',
				),
				array(
					'fas fa-glass-water-droplet' => 'Glass Water Droplet (potable,water)',
				),
				array(
					'fas fa-gopuram' => 'Gopuram (building,entrance,hinduism,temple,tower)',
				),
				array(
					'fas fa-group-arrows-rotate' => 'Group Arrows Rotate (community,engagement,spin,sync)',
				),
				array(
					'fas fa-hammer' => 'Hammer (admin,fix,hammer,recovery,repair,settings,tool)',
				),
				array(
					'fas fa-hand-holding-hand' => 'Hand Holding Hand (care,give,help,hold,protect)',
				),
				array(
					'fas fa-handcuffs' => 'Handcuffs (arrest,criminal,handcuffs,jail,lock,police,wrist)',
				),
				array(
					'fas fa-hands-bound' => 'Hands Bound (abduction,bound,handcuff,wrist)',
				),
				array(
					'fas fa-hands-bubbles' => 'Hands Bubbles (hands-wash,covid-19,hygiene,soap,wash)',
				),
				array(
					'fas fa-hands-holding-child' => 'Hands Holding Child (care,give,help,hold,protect)',
				),
				array(
					'fas fa-hands-holding-circle' => 'Hands Holding Circle (circle,gift,protection)',
				),
				array(
					'fas fa-handshake-simple' => 'Handshake Simple (handshake-alt,agreement,greeting,hand,handshake,meeting,partnership,shake)',
				),
				array(
					'fas fa-headset' => 'Headset (audio,gamer,gaming,listen,live chat,microphone,shot caller,sound,support,telemarketer)',
				),
				array(
					'fas fa-heart-circle-bolt' => 'Heart Circle Bolt (cardiogram,ekg,electric,heart,love,pacemaker)',
				),
				array(
					'fas fa-heart-circle-check' => 'Heart Circle Check (favorite,heart,love,not affected,ok,okay)',
				),
				array(
					'fas fa-heart-circle-exclamation' => 'Heart Circle Exclamation (favorite,heart,love)',
				),
				array(
					'fas fa-heart-circle-minus' => 'Heart Circle Minus (favorite,heart,love)',
				),
				array(
					'fas fa-heart-circle-plus' => 'Heart Circle Plus (favorite,heart,love)',
				),
				array(
					'fas fa-heart-circle-xmark' => 'Heart Circle Xmark (favorite,heart,love)',
				),
				array(
					'fas fa-helicopter' => 'Helicopter (airwolf,apache,chopper,flight,fly,helicopter,travel,vehicle)',
				),
				array(
					'fas fa-helicopter-symbol' => 'Helicopter Symbol (chopper,helicopter,landing pad,whirlybird)',
				),
				array(
					'fas fa-helmet-un' => 'Helmet Un (helmet,united nations)',
				),
				array(
					'fas fa-hill-avalanche' => 'Hill Avalanche (mudslide,snow,winter)',
				),
				array(
					'fas fa-hill-rockslide' => 'Hill Rockslide (mudslide)',
				),
				array(
					'fas fa-hospital' => 'Hospital (hospital-alt,hospital-wide,building,covid-19,doctor,emergency room,hospital,medical center,medicine)',
				),
				array(
					'far fa-hospital' => 'Hospital (hospital-alt,hospital-wide,building,covid-19,doctor,emergency room,hospital,medical center,medicine)',
				),
				array(
					'fas fa-hotel' => 'Hotel (building,hotel,inn,lodging,motel,resort,travel)',
				),
				array(
					'fas fa-house-chimney' => 'House Chimney (home-lg,abode,building,chimney,house,main,residence,smokestack)',
				),
				array(
					'fas fa-house-chimney-crack' => 'House Chimney Crack (house-damage,building,devastation,disaster,earthquake,home,insurance)',
				),
				array(
					'fas fa-house-circle-check' => 'House Circle Check (abode,home,house,not affected,ok,okay)',
				),
				array(
					'fas fa-house-circle-exclamation' => 'House Circle Exclamation (abode,affected,home,house)',
				),
				array(
					'fas fa-house-circle-xmark' => 'House Circle Xmark (abode,destroy,home,house)',
				),
				array(
					'fas fa-house-fire' => 'House Fire (burn,emergency,home)',
				),
				array(
					'fas fa-house-flag' => 'House Flag (camp,home)',
				),
				array(
					'fas fa-house-flood-water' => 'House Flood Water (damage,flood,water)',
				),
				array(
					'fas fa-house-flood-water-circle-arrow-right' => 'House Flood Water Circle Arrow Right (damage,flood,water)',
				),
				array(
					'fas fa-house-lock' => 'House Lock (closed,home,house,lockdown,quarantine)',
				),
				array(
					'fas fa-house-medical' => 'House Medical (covid-19,doctor,facility,general practitioner,health,hospital,infirmary,medicine,office,outpatient)',
				),
				array(
					'fas fa-house-medical-circle-check' => 'House Medical Circle Check (clinic,hospital,not affected,ok,okay)',
				),
				array(
					'fas fa-house-medical-circle-exclamation' => 'House Medical Circle Exclamation (affected,clinic,hospital)',
				),
				array(
					'fas fa-house-medical-circle-xmark' => 'House Medical Circle Xmark (clinic,destroy,hospital)',
				),
				array(
					'fas fa-house-medical-flag' => 'House Medical Flag (clinic,hospital,mash)',
				),
				array(
					'fas fa-house-signal' => 'House Signal (abode,building,connect,family,home,residence,smart home,wifi)',
				),
				array(
					'fas fa-house-tsunami' => 'House Tsunami (damage,flood,tidal wave,wave)',
				),
				array(
					'fas fa-hurricane' => 'Hurricane (coriolis effect,eye,storm,tropical cyclone,typhoon)',
				),
				array(
					'fas fa-id-card' => 'Id Card (drivers-license,contact,demographics,document,identification,issued,profile,registration)',
				),
				array(
					'far fa-id-card' => 'Id Card (drivers-license,contact,demographics,document,identification,issued,profile,registration)',
				),
				array(
					'fas fa-jar' => 'Jar (jam,jelly,storage)',
				),
				array(
					'fas fa-jar-wheat' => 'Jar Wheat (flour,storage)',
				),
				array(
					'fas fa-jet-fighter-up' => 'Jet Fighter Up (airforce,airplane,airport,fast,fly,goose,marines,maverick,military,plane,quick,top gun,transportation,travel)',
				),
				array(
					'fas fa-jug-detergent' => 'Jug Detergent (detergent,laundry,soap,wash)',
				),
				array(
					'fas fa-kitchen-set' => 'Kitchen Set (chef,cook,cup,kitchen,pan,pot,skillet)',
				),
				array(
					'fas fa-land-mine-on' => 'Land Mine On (bomb,danger,explosion,war)',
				),
				array(
					'fas fa-landmark' => 'Landmark (building,classical,historic,memorable,monument,museum,politics)',
				),
				array(
					'fas fa-landmark-dome' => 'Landmark Dome (landmark-alt,building,historic,memorable,monument,politics)',
				),
				array(
					'fas fa-landmark-flag' => 'Landmark Flag (capitol,flag,landmark,memorial)',
				),
				array(
					'fas fa-laptop' => 'Laptop (computer,cpu,dell,demo,device,laptop,mac,macbook,machine,pc,personal)',
				),
				array(
					'fas fa-laptop-file' => 'Laptop File (computer,education,laptop,learning,remote work)',
				),
				array(
					'fas fa-life-ring' => 'Life Ring (coast guard,help,overboard,save,support)',
				),
				array(
					'far fa-life-ring' => 'Life Ring (coast guard,help,overboard,save,support)',
				),
				array(
					'fas fa-lines-leaning' => 'Lines Leaning (canted,domino,falling,resilience,resilient,tipped)',
				),
				array(
					'fas fa-location-pin-lock' => 'Location Pin Lock (closed,lockdown,map,quarantine)',
				),
				array(
					'fas fa-locust' => 'Locust (horde,infestation,locust,plague,swarm)',
				),
				array(
					'fas fa-lungs' => 'Lungs (air,breath,covid-19,exhalation,inhalation,lungs,organ,respiration,respiratory)',
				),
				array(
					'fas fa-magnifying-glass-arrow-right' => 'Magnifying Glass Arrow Right (find,next,search)',
				),
				array(
					'fas fa-magnifying-glass-chart' => 'Magnifying Glass Chart ( data, graph, intelligence,analysis,chart,market)',
				),
				array(
					'fas fa-mars-and-venus' => 'Mars And Venus (Male and Female Sign,female,gender,intersex,male,transgender)',
				),
				array(
					'fas fa-mars-and-venus-burst' => 'Mars And Venus Burst (gender,violence)',
				),
				array(
					'fas fa-mask-face' => 'Mask Face (breath,coronavirus,covid-19,filter,flu,infection,pandemic,respirator,virus)',
				),
				array(
					'fas fa-mask-ventilator' => 'Mask Ventilator (breath,gas,mask,oxygen,respirator,ventilator)',
				),
				array(
					'fas fa-mattress-pillow' => 'Mattress Pillow (air mattress,mattress,pillow,rest,sleep)',
				),
				array(
					'fas fa-microscope' => 'Microscope (covid-19,electron,lens,microscope,optics,science,shrink,testing,tool)',
				),
				array(
					'fas fa-mobile-retro' => 'Mobile Retro (cellphone,cellular,phone)',
				),
				array(
					'fas fa-mobile-screen' => 'Mobile Screen (mobile-android-alt,android,call,cell phone,device,number,screen,telephone,text)',
				),
				array(
					'fas fa-money-bill-transfer' => 'Money Bill Transfer (bank,conversion,deposit,money,transfer,withdrawal)',
				),
				array(
					'fas fa-money-bill-trend-up' => 'Money Bill Trend Up (bank,bonds,inflation,market,stocks,trade)',
				),
				array(
					'fas fa-money-bill-wheat' => 'Money Bill Wheat (agribusiness,agriculture,farming,food,livelihood,subsidy)',
				),
				array(
					'fas fa-money-bills' => 'Money Bills (atm,cash,money,moolah)',
				),
				array(
					'fas fa-mosque' => 'Mosque (Muslim,building,islam,landmark,mosque,muslim,religion)',
				),
				array(
					'fas fa-mosquito' => 'Mosquito (bite,bug,mosquito,west nile)',
				),
				array(
					'fas fa-mosquito-net' => 'Mosquito Net (bite,malaria,mosquito,net)',
				),
				array(
					'fas fa-mound' => 'Mound (barrier,hill,pitcher,speedbump)',
				),
				array(
					'fas fa-mountain-city' => 'Mountain City (location,rural,urban)',
				),
				array(
					'fas fa-mountain-sun' => 'Mountain Sun (country,hiking,landscape,rural,travel,view)',
				),
				array(
					'fas fa-oil-well' => 'Oil Well (drill,oil,rig)',
				),
				array(
					'fas fa-parachute-box' => 'Parachute Box (aid,assistance,goods,relief,rescue,supplies)',
				),
				array(
					'fas fa-people-arrows' => 'People Arrows (people-arrows-left-right,distance,isolation,separate,social distancing,users-people)',
				),
				array(
					'fas fa-people-group' => 'People Group (family,group,team)',
				),
				array(
					'fas fa-people-line' => 'People Line (group,need)',
				),
				array(
					'fas fa-people-pulling' => 'People Pulling (forced return,yanking)',
				),
				array(
					'fas fa-people-robbery' => 'People Robbery (criminal,hands up,looting,robbery,steal)',
				),
				array(
					'fas fa-people-roof' => 'People Roof (family,group,manage,people,safe,shelter)',
				),
				array(
					'fas fa-person' => 'Person (male,man,person standing,stand,standing,woman)',
				),
				array(
					'fas fa-person-arrow-down-to-line' => 'Person Arrow Down To Line (ground,indigenous,native)',
				),
				array(
					'fas fa-person-arrow-up-from-line' => 'Person Arrow Up From Line (population,rise)',
				),
				array(
					'fas fa-person-breastfeeding' => 'Person Breastfeeding (baby,child,infant,mother,nutrition,sustenance)',
				),
				array(
					'fas fa-person-burst' => 'Person Burst (abuse,accident,crash,explode,violence)',
				),
				array(
					'fas fa-person-cane' => 'Person Cane (aging,cane,elderly,old,staff)',
				),
				array(
					'fas fa-person-chalkboard' => 'Person Chalkboard (blackboard,instructor,keynote,lesson,presentation,teacher)',
				),
				array(
					'fas fa-person-circle-check' => 'Person Circle Check (approved,not affected,ok,okay)',
				),
				array(
					'fas fa-person-circle-exclamation' => 'Person Circle Exclamation (affected,alert,lost,missing)',
				),
				array(
					'fas fa-person-circle-minus' => 'Person Circle Minus (delete,remove)',
				),
				array(
					'fas fa-person-circle-plus' => 'Person Circle Plus (add,found)',
				),
				array(
					'fas fa-person-circle-question' => 'Person Circle Question (lost,missing)',
				),
				array(
					'fas fa-person-circle-xmark' => 'Person Circle Xmark (dead,removed)',
				),
				array(
					'fas fa-person-digging' => 'Person Digging (digging,bury,construction,debris,dig,men at work)',
				),
				array(
					'fas fa-person-dress' => 'Person Dress (female,man,skirt,woman)',
				),
				array(
					'fas fa-person-dress-burst' => 'Person Dress Burst (abuse,accident,crash,explode,violence)',
				),
				array(
					'fas fa-person-drowning' => 'Person Drowning (drown,emergency,swim)',
				),
				array(
					'fas fa-person-falling' => 'Person Falling (accident,fall,trip)',
				),
				array(
					'fas fa-person-falling-burst' => 'Person Falling Burst (accident,crash,death,fall,homicide,murder)',
				),
				array(
					'fas fa-person-half-dress' => 'Person Half Dress (gender,man,restroom,transgender,woman)',
				),
				array(
					'fas fa-person-harassing' => 'Person Harassing (abuse,scream,shame,shout,yell)',
				),
				array(
					'fas fa-person-military-pointing' => 'Person Military Pointing (army,customs,guard)',
				),
				array(
					'fas fa-person-military-rifle' => 'Person Military Rifle (armed forces,army,military,rifle,war)',
				),
				array(
					'fas fa-person-military-to-person' => 'Person Military To Person (civilian,coordination,military)',
				),
				array(
					'fas fa-person-pregnant' => 'Person Pregnant (baby,birth,child,pregnant,pregnant woman,woman)',
				),
				array(
					'fas fa-person-rays' => 'Person Rays (affected,focus,shine)',
				),
				array(
					'fas fa-person-rifle' => 'Person Rifle (army,combatant,gun,military,rifle,war)',
				),
				array(
					'fas fa-person-shelter' => 'Person Shelter (house,inside,roof,safe,safety,shelter)',
				),
				array(
					'fas fa-person-through-window' => 'Person Through Window (door,exit,forced entry,leave,robbery,steal,window)',
				),
				array(
					'fas fa-person-walking' => 'Person Walking (walking,crosswalk,exercise,hike,move,person walking,walk,walking)',
				),
				array(
					'fas fa-person-walking-arrow-loop-left' => 'Person Walking Arrow Loop Left (population return,return)',
				),
				array(
					'fas fa-person-walking-arrow-right' => 'Person Walking Arrow Right (exit,internally displaced,leave,refugee)',
				),
				array(
					'fas fa-person-walking-dashed-line-arrow-right' => 'Person Walking Dashed Line Arrow Right (exit,refugee)',
				),
				array(
					'fas fa-person-walking-luggage' => 'Person Walking Luggage (bag,baggage,briefcase,carry-on,deployment,rolling)',
				),
				array(
					'fas fa-pills' => 'Pills (drugs,medicine,prescription,tablets)',
				),
				array(
					'fas fa-plane-circle-check' => 'Plane Circle Check (airplane,airport,flight,fly,not affected,ok,okay,travel)',
				),
				array(
					'fas fa-plane-circle-exclamation' => 'Plane Circle Exclamation (affected,airplane,airport,flight,fly,travel)',
				),
				array(
					'fas fa-plane-circle-xmark' => 'Plane Circle Xmark (airplane,airport,destroy,flight,fly,travel)',
				),
				array(
					'fas fa-plane-lock' => 'Plane Lock (airplane,airport,closed,flight,fly,lockdown,quarantine,travel)',
				),
				array(
					'fas fa-plane-up' => 'Plane Up (airplane,airport,internet,signal,sky,wifi,wireless)',
				),
				array(
					'fas fa-plant-wilt' => 'Plant Wilt (drought,planting,vegetation,wilt)',
				),
				array(
					'fas fa-plate-wheat' => 'Plate Wheat (bowl,hunger,rations,wheat)',
				),
				array(
					'fas fa-plug' => 'Plug (connect,electric,electric plug,electricity,online,plug,power)',
				),
				array(
					'fas fa-plug-circle-bolt' => 'Plug Circle Bolt (electric,electricity,plug,power)',
				),
				array(
					'fas fa-plug-circle-check' => 'Plug Circle Check (electric,electricity,not affected,ok,okay,plug,power)',
				),
				array(
					'fas fa-plug-circle-exclamation' => 'Plug Circle Exclamation (affected,electric,electricity,plug,power)',
				),
				array(
					'fas fa-plug-circle-minus' => 'Plug Circle Minus (electric,electricity,plug,power)',
				),
				array(
					'fas fa-plug-circle-plus' => 'Plug Circle Plus (electric,electricity,plug,power)',
				),
				array(
					'fas fa-plug-circle-xmark' => 'Plug Circle Xmark (destroy,electric,electricity,outage,plug,power)',
				),
				array(
					'fas fa-pump-soap' => 'Pump Soap (anti-bacterial,clean,covid-19,disinfect,hygiene,sanitizer,soap)',
				),
				array(
					'fas fa-radiation' => 'Radiation (danger,dangerous,deadly,hazard,nuclear,radioactive,warning)',
				),
				array(
					'fas fa-radio' => 'Radio (am,broadcast,fm,frequency,music,news,radio,receiver,transmitter,tuner,video)',
				),
				array(
					'fas fa-ranking-star' => 'Ranking Star (chart,first place,podium,rank,win)',
				),
				array(
					'fas fa-road' => 'Road (highway,map,motorway,pavement,road,route,street,travel)',
				),
				array(
					'fas fa-road-barrier' => 'Road Barrier (block,border,no entry,roadblock)',
				),
				array(
					'fas fa-road-bridge' => 'Road Bridge (bridge,infrastructure,road,travel)',
				),
				array(
					'fas fa-road-circle-check' => 'Road Circle Check (freeway,highway,not affected,ok,okay,pavement,road)',
				),
				array(
					'fas fa-road-circle-exclamation' => 'Road Circle Exclamation (affected,freeway,highway,pavement,road)',
				),
				array(
					'fas fa-road-circle-xmark' => 'Road Circle Xmark (destroy,freeway,highway,pavement,road)',
				),
				array(
					'fas fa-road-lock' => 'Road Lock (closed,freeway,highway,lockdown,pavement,quarantine,road)',
				),
				array(
					'fas fa-road-spikes' => 'Road Spikes (barrier,roadblock,spikes)',
				),
				array(
					'fas fa-rug' => 'Rug (blanket,carpet,rug,textile)',
				),
				array(
					'fas fa-sack-dollar' => 'Sack Dollar (bag,burlap,cash,dollar,money,money bag,moneybag,robber,santa,usd)',
				),
				array(
					'fas fa-sack-xmark' => 'Sack Xmark (bag,burlap,rations)',
				),
				array(
					'fas fa-sailboat' => 'Sailboat (dinghy,mast,sailboat,sailing,yacht)',
				),
				array(
					'fas fa-satellite-dish' => 'Satellite Dish (SETI,antenna,communications,dish,hardware,radar,receiver,satellite,satellite antenna,saucer,signal,space)',
				),
				array(
					'fas fa-scale-balanced' => 'Scale Balanced (balance-scale,Libra,balance,balance scale,balanced,justice,law,legal,measure,rule,scale,weight,zodiac)',
				),
				array(
					'fas fa-school' => 'School (building,education,learn,school,student,teacher)',
				),
				array(
					'fas fa-school-circle-check' => 'School Circle Check (not affected,ok,okay,schoolhouse)',
				),
				array(
					'fas fa-school-circle-exclamation' => 'School Circle Exclamation (affected,schoolhouse)',
				),
				array(
					'fas fa-school-circle-xmark' => 'School Circle Xmark (destroy,schoolhouse)',
				),
				array(
					'fas fa-school-flag' => 'School Flag (educate,flag,school,schoolhouse)',
				),
				array(
					'fas fa-school-lock' => 'School Lock (closed,lockdown,quarantine,schoolhouse)',
				),
				array(
					'fas fa-seedling' => 'Seedling (sprout,environment,flora,grow,plant,sapling,seedling,vegan,young)',
				),
				array(
					'fas fa-sheet-plastic' => 'Sheet Plastic (plastic,plastic wrap,protect,tarp,tarpaulin,waterproof)',
				),
				array(
					'fas fa-shield-cat' => 'Shield Cat (animal,feline,pet,protect,safety,veterinary)',
				),
				array(
					'fas fa-shield-dog' => 'Shield Dog (animal,canine,pet,protect,safety,veterinary)',
				),
				array(
					'fas fa-shield-heart' => 'Shield Heart (love,protect,safe,safety,shield)',
				),
				array(
					'fas fa-ship' => 'Ship (boat,passenger,sea,ship,water)',
				),
				array(
					'fas fa-shirt' => 'Shirt (t-shirt,tshirt,clothing,fashion,garment,shirt,short sleeve,t-shirt,tshirt)',
				),
				array(
					'fas fa-shop' => 'Shop (store-alt,bodega,building,buy,market,purchase,shopping,store)',
				),
				array(
					'fas fa-shop-lock' => 'Shop Lock (bodega,building,buy,closed,lock,lockdown,market,purchase,quarantine,shop,shopping,store)',
				),
				array(
					'fas fa-shower' => 'Shower (bath,clean,faucet,shower,water)',
				),
				array(
					'fas fa-skull-crossbones' => 'Skull Crossbones (Black Skull and Crossbones,Dungeons & Dragons,alert,bones,crossbones,d&d,danger,dangerous area,dead,deadly,death,dnd,face,fantasy,halloween,holiday,jolly-roger,monster,pirate,poison,skeleton,skull,skull and crossbones,warning)',
				),
				array(
					'fas fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'far fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'fas fa-soap' => 'Soap (bar,bathing,bubbles,clean,cleaning,covid-19,hygiene,lather,soap,soapdish,wash)',
				),
				array(
					'fas fa-square-nfi' => 'Square Nfi (non-food item,supplies)',
				),
				array(
					'fas fa-square-person-confined' => 'Square Person Confined (captivity,confined)',
				),
				array(
					'fas fa-square-virus' => 'Square Virus (coronavirus,covid-19,disease,flu,infection,pandemic)',
				),
				array(
					'fas fa-staff-snake' => 'Staff Snake (rod-asclepius,rod-snake,staff-aesculapius,asclepius,asklepian,health,serpent,wellness)',
				),
				array(
					'fas fa-stethoscope' => 'Stethoscope (covid-19,diagnosis,doctor,general practitioner,heart,hospital,infirmary,medicine,office,outpatient,stethoscope)',
				),
				array(
					'fas fa-suitcase-medical' => 'Suitcase Medical (medkit,first aid,firstaid,health,help,medical,supply,support)',
				),
				array(
					'fas fa-sun-plant-wilt' => 'Sun Plant Wilt (arid,droop,drought)',
				),
				array(
					'fas fa-syringe' => 'Syringe (covid-19,doctor,immunizations,medical,medicine,needle,shot,sick,syringe,vaccinate,vaccine)',
				),
				array(
					'fas fa-tarp' => 'Tarp (protection,tarp,tent,waterproof)',
				),
				array(
					'fas fa-tarp-droplet' => 'Tarp Droplet (protection,tarp,tent,waterproof)',
				),
				array(
					'fas fa-temperature-arrow-down' => 'Temperature Arrow Down (temperature-down,air conditioner,cold,heater,mercury,thermometer,winter)',
				),
				array(
					'fas fa-temperature-arrow-up' => 'Temperature Arrow Up (temperature-up,air conditioner,cold,heater,mercury,thermometer,winter)',
				),
				array(
					'fas fa-tent' => 'Tent (bivouac,campground,refugee,shelter,tent)',
				),
				array(
					'fas fa-tent-arrow-down-to-line' => 'Tent Arrow Down To Line (permanent,refugee,shelter)',
				),
				array(
					'fas fa-tent-arrow-left-right' => 'Tent Arrow Left Right (refugee,shelter,transition)',
				),
				array(
					'fas fa-tent-arrow-turn-left' => 'Tent Arrow Turn Left (refugee,shelter,temporary)',
				),
				array(
					'fas fa-tent-arrows-down' => 'Tent Arrows Down (refugee,shelter,spontaneous)',
				),
				array(
					'fas fa-tents' => 'Tents (bivouac,campground,refugee,shelter,tent)',
				),
				array(
					'fas fa-toilet' => 'Toilet (bathroom,flush,john,loo,pee,plumbing,poop,porcelain,potty,restroom,throne,toile,toilet,washroom,waste,wc)',
				),
				array(
					'fas fa-toilet-portable' => 'Toilet Portable (outhouse,toilet)',
				),
				array(
					'fas fa-toilets-portable' => 'Toilets Portable (outhouse,toilet)',
				),
				array(
					'fas fa-tornado' => 'Tornado (cloud,cyclone,dorothy,landspout,tornado,toto,twister,vortext,waterspout,weather,whirlwind)',
				),
				array(
					'fas fa-tower-broadcast' => 'Tower Broadcast (broadcast-tower,airwaves,antenna,communication,emergency,radio,reception,waves)',
				),
				array(
					'fas fa-tower-cell' => 'Tower Cell (airwaves,antenna,communication,radio,reception,waves)',
				),
				array(
					'fas fa-tower-observation' => 'Tower Observation (fire tower,view)',
				),
				array(
					'fas fa-train-subway' => 'Train Subway (subway,machine,railway,train,transportation,vehicle)',
				),
				array(
					'fas fa-trash-can' => 'Trash Can (trash-alt,delete,garbage,hide,remove,trash-o)',
				),
				array(
					'far fa-trash-can' => 'Trash Can (trash-alt,delete,garbage,hide,remove,trash-o)',
				),
				array(
					'fas fa-tree-city' => 'Tree City (building,city,urban)',
				),
				array(
					'fas fa-trowel' => 'Trowel (build,construction,tool)',
				),
				array(
					'fas fa-trowel-bricks' => 'Trowel Bricks (build,construction,reconstruction,tool)',
				),
				array(
					'fas fa-truck' => 'Truck (Black Truck,cargo,delivery,delivery truck,shipping,truck,vehicle)',
				),
				array(
					'fas fa-truck-arrow-right' => 'Truck Arrow Right (access,fast,shipping,transport)',
				),
				array(
					'fas fa-truck-droplet' => 'Truck Droplet (thirst,truck,water,water supply)',
				),
				array(
					'fas fa-truck-field' => 'Truck Field (supplies,truck)',
				),
				array(
					'fas fa-truck-field-un' => 'Truck Field Un (supplies,truck,united nations)',
				),
				array(
					'fas fa-truck-front' => 'Truck Front (shuttle,truck,van)',
				),
				array(
					'fas fa-truck-medical' => 'Truck Medical (ambulance,ambulance,clinic,covid-19,emergency,emt,er,help,hospital,mobile,support,vehicle)',
				),
				array(
					'fas fa-truck-plane' => 'Truck Plane (airplane,plane,transportation,truck,vehicle)',
				),
				array(
					'fas fa-user-doctor' => 'User Doctor (user-md,covid-19,health,job,medical,nurse,occupation,physician,profile,surgeon,worker)',
				),
				array(
					'fas fa-user-injured' => 'User Injured (users-people)',
				),
				array(
					'fas fa-users-between-lines' => 'Users Between Lines (covered,group,people)',
				),
				array(
					'fas fa-users-line' => 'Users Line (group,need,people)',
				),
				array(
					'fas fa-users-rays' => 'Users Rays (affected,focused,group,people)',
				),
				array(
					'fas fa-users-rectangle' => 'Users Rectangle (focus,group,people,reached)',
				),
				array(
					'fas fa-users-viewfinder' => 'Users Viewfinder (focus,group,people,targeted)',
				),
				array(
					'fas fa-vial-circle-check' => 'Vial Circle Check (ampule,chemist,chemistry,not affected,ok,okay,success,test tube,tube,vaccine)',
				),
				array(
					'fas fa-vial-virus' => 'Vial Virus (ampule,coronavirus,covid-19,flue,infection,lab,laboratory,pandemic,test,test tube,vaccine)',
				),
				array(
					'fas fa-vihara' => 'Vihara (buddhism,buddhist,building,monastery)',
				),
				array(
					'fas fa-virus' => 'Virus (bug,coronavirus,covid-19,flu,health,infection,pandemic,sick,vaccine,viral)',
				),
				array(
					'fas fa-virus-covid' => 'Virus Covid (bug,covid-19,flu,health,infection,pandemic,vaccine,viral,virus)',
				),
				array(
					'fas fa-volcano' => 'Volcano (caldera,eruption,lava,magma,mountain,smoke,volcano)',
				),
				array(
					'fas fa-walkie-talkie' => 'Walkie Talkie (communication,copy,intercom,over,portable,radio,two way radio)',
				),
				array(
					'fas fa-wheat-awn' => 'Wheat Awn (wheat-alt,agriculture,autumn,fall,farming,grain)',
				),
				array(
					'fas fa-wheat-awn-circle-exclamation' => 'Wheat Awn Circle Exclamation (affected,famine,food,gluten,hunger,starve,straw)',
				),
				array(
					'fas fa-wheelchair-move' => 'Wheelchair Move (wheelchair-alt,access,handicap,impairment,physical,wheelchair symbol)',
				),
				array(
					'fas fa-wifi' => 'Wifi (wifi-3,wifi-strong,connection,hotspot,internet,network,wireless)',
				),
				array(
					'fas fa-wind' => 'Wind (air,blow,breeze,fall,seasonal,weather)',
				),
				array(
					'fas fa-worm' => 'Worm (dirt,garden,worm,wriggle)',
				),
				array(
					'fas fa-xmarks-lines' => 'Xmarks Lines (barricade,barrier,fence,poison,roadblock)',
				),
			),
			'Logistics' => array(
				array(
					'fas fa-anchor' => 'Anchor (anchor,berth,boat,dock,embed,link,maritime,moor,port,secure,ship,tool)',
				),
				array(
					'fas fa-anchor-circle-check' => 'Anchor Circle Check (marina,not affected,ok,okay,port)',
				),
				array(
					'fas fa-anchor-circle-exclamation' => 'Anchor Circle Exclamation (affected,marina,port)',
				),
				array(
					'fas fa-anchor-circle-xmark' => 'Anchor Circle Xmark (destroy,marina,port)',
				),
				array(
					'fas fa-anchor-lock' => 'Anchor Lock (closed,lockdown,marina,port,quarantine)',
				),
				array(
					'fas fa-box' => 'Box (archive,box,container,package,parcel,storage)',
				),
				array(
					'fas fa-boxes-packing' => 'Boxes Packing (archive,box,package,storage,supplies)',
				),
				array(
					'fas fa-boxes-stacked' => 'Boxes Stacked (boxes,boxes-alt,archives,inventory,storage,warehouse)',
				),
				array(
					'fas fa-bridge' => 'Bridge (bridge,road)',
				),
				array(
					'fas fa-bridge-circle-check' => 'Bridge Circle Check (bridge,not affected,ok,okay,road)',
				),
				array(
					'fas fa-bridge-circle-exclamation' => 'Bridge Circle Exclamation (affected,bridge,road)',
				),
				array(
					'fas fa-bridge-circle-xmark' => 'Bridge Circle Xmark (bridge,destroy,road)',
				),
				array(
					'fas fa-bridge-lock' => 'Bridge Lock (bridge,closed,lockdown,quarantine,road)',
				),
				array(
					'fas fa-bridge-water' => 'Bridge Water (bridge,road)',
				),
				array(
					'fas fa-bus' => 'Bus (bus,oncoming,oncoming bus,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-bus-simple' => 'Bus Simple (bus-alt,mta,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car' => 'Car (automobile,auto,automobile,car,oncoming,oncoming automobile,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car-tunnel' => 'Car Tunnel (road,tunnel)',
				),
				array(
					'fas fa-cart-flatbed' => 'Cart Flatbed (dolly-flatbed,carry,inventory,shipping,transport)',
				),
				array(
					'fas fa-chart-simple' => 'Chart Simple (analytics,bar,chart,column,graph,row,trend)',
				),
				array(
					'fas fa-clipboard-check' => 'Clipboard Check (accept,agree,confirm,done,ok,select,success,tick,todo,yes)',
				),
				array(
					'fas fa-clipboard-list' => 'Clipboard List (checklist,completed,done,finished,intinerary,ol,schedule,tick,todo,ul)',
				),
				array(
					'fas fa-clipboard-question' => 'Clipboard Question (assistance,interview,query,question)',
				),
				array(
					'fas fa-dolly' => 'Dolly (dolly-box,carry,shipping,transport)',
				),
				array(
					'fas fa-ferry' => 'Ferry (barge,boat,carry,ferryboat,ship)',
				),
				array(
					'fas fa-gas-pump' => 'Gas Pump (car,diesel,fuel,fuel pump,fuelpump,gas,gasoline,petrol,pump,station)',
				),
				array(
					'fas fa-gears' => 'Gears (cogs,gears,mechanical,settings,sprocket,wheel)',
				),
				array(
					'fas fa-helicopter' => 'Helicopter (airwolf,apache,chopper,flight,fly,helicopter,travel,vehicle)',
				),
				array(
					'fas fa-helicopter-symbol' => 'Helicopter Symbol (chopper,helicopter,landing pad,whirlybird)',
				),
				array(
					'fas fa-helmet-safety' => 'Helmet Safety (hard-hat,hat-hard,construction,hardhat,helmet,safety)',
				),
				array(
					'fas fa-jet-fighter-up' => 'Jet Fighter Up (airforce,airplane,airport,fast,fly,goose,marines,maverick,military,plane,quick,top gun,transportation,travel)',
				),
				array(
					'fas fa-pallet' => 'Pallet (archive,box,inventory,shipping,warehouse)',
				),
				array(
					'fas fa-plane-circle-check' => 'Plane Circle Check (airplane,airport,flight,fly,not affected,ok,okay,travel)',
				),
				array(
					'fas fa-plane-circle-exclamation' => 'Plane Circle Exclamation (affected,airplane,airport,flight,fly,travel)',
				),
				array(
					'fas fa-plane-circle-xmark' => 'Plane Circle Xmark (airplane,airport,destroy,flight,fly,travel)',
				),
				array(
					'fas fa-plane-lock' => 'Plane Lock (airplane,airport,closed,flight,fly,lockdown,quarantine,travel)',
				),
				array(
					'fas fa-road' => 'Road (highway,map,motorway,pavement,road,route,street,travel)',
				),
				array(
					'fas fa-road-barrier' => 'Road Barrier (block,border,no entry,roadblock)',
				),
				array(
					'fas fa-road-bridge' => 'Road Bridge (bridge,infrastructure,road,travel)',
				),
				array(
					'fas fa-road-circle-check' => 'Road Circle Check (freeway,highway,not affected,ok,okay,pavement,road)',
				),
				array(
					'fas fa-road-circle-exclamation' => 'Road Circle Exclamation (affected,freeway,highway,pavement,road)',
				),
				array(
					'fas fa-road-circle-xmark' => 'Road Circle Xmark (destroy,freeway,highway,pavement,road)',
				),
				array(
					'fas fa-road-lock' => 'Road Lock (closed,freeway,highway,lockdown,pavement,quarantine,road)',
				),
				array(
					'fas fa-sailboat' => 'Sailboat (dinghy,mast,sailboat,sailing,yacht)',
				),
				array(
					'fas fa-square-nfi' => 'Square Nfi (non-food item,supplies)',
				),
				array(
					'fas fa-train' => 'Train (bullet,commute,locomotive,railway,subway,train)',
				),
				array(
					'fas fa-train-subway' => 'Train Subway (subway,machine,railway,train,transportation,vehicle)',
				),
				array(
					'fas fa-truck' => 'Truck (Black Truck,cargo,delivery,delivery truck,shipping,truck,vehicle)',
				),
				array(
					'fas fa-truck-arrow-right' => 'Truck Arrow Right (access,fast,shipping,transport)',
				),
				array(
					'fas fa-truck-fast' => 'Truck Fast (shipping-fast,express,fedex,mail,overnight,package,ups)',
				),
				array(
					'fas fa-truck-field' => 'Truck Field (supplies,truck)',
				),
				array(
					'fas fa-truck-field-un' => 'Truck Field Un (supplies,truck,united nations)',
				),
				array(
					'fas fa-truck-front' => 'Truck Front (shuttle,truck,van)',
				),
				array(
					'fas fa-truck-plane' => 'Truck Plane (airplane,plane,transportation,truck,vehicle)',
				),
				array(
					'fas fa-warehouse' => 'Warehouse (building,capacity,garage,inventory,storage)',
				),
				array(
					'fas fa-xmarks-lines' => 'Xmarks Lines (barricade,barrier,fence,poison,roadblock)',
				),
			),
			'Maps' => array(
				array(
					'fas fa-anchor' => 'Anchor (anchor,berth,boat,dock,embed,link,maritime,moor,port,secure,ship,tool)',
				),
				array(
					'fas fa-bag-shopping' => 'Bag Shopping (shopping-bag,buy,checkout,grocery,payment,purchase)',
				),
				array(
					'fas fa-basket-shopping' => 'Basket Shopping (shopping-basket,buy,checkout,grocery,payment,purchase)',
				),
				array(
					'fas fa-bath' => 'Bath (bathtub,bath,bathtub,clean,shower,tub,wash)',
				),
				array(
					'fas fa-bed' => 'Bed (hospital,hotel,lodging,mattress,patient,person in bed,rest,sleep,travel)',
				),
				array(
					'fas fa-beer-mug-empty' => 'Beer Mug Empty (beer,alcohol,ale,bar,beverage,brew,brewery,drink,foam,lager,liquor,mug,stein)',
				),
				array(
					'fas fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'far fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'fas fa-bell-slash' => 'Bell Slash (alert,bell,bell with slash,cancel,disabled,forbidden,mute,notification,off,quiet,reminder,silent)',
				),
				array(
					'far fa-bell-slash' => 'Bell Slash (alert,bell,bell with slash,cancel,disabled,forbidden,mute,notification,off,quiet,reminder,silent)',
				),
				array(
					'fas fa-bicycle' => 'Bicycle (bicycle,bike,gears,pedal,transportation,vehicle)',
				),
				array(
					'fas fa-binoculars' => 'Binoculars (glasses,magnify,scenic,spyglass,view)',
				),
				array(
					'fas fa-bomb' => 'Bomb (bomb,comic,error,explode,fuse,grenade,warning)',
				),
				array(
					'fas fa-book' => 'Book (book,cover,decorated,diary,documentation,journal,library,notebook,notebook with decorative cover,read,research)',
				),
				array(
					'fas fa-book-atlas' => 'Book Atlas (atlas,book,directions,geography,globe,library,map,research,travel,wayfinding)',
				),
				array(
					'fas fa-bookmark' => 'Bookmark (bookmark,favorite,library,mark,marker,read,remember,research,save)',
				),
				array(
					'far fa-bookmark' => 'Bookmark (bookmark,favorite,library,mark,marker,read,remember,research,save)',
				),
				array(
					'fas fa-bridge' => 'Bridge (bridge,road)',
				),
				array(
					'fas fa-bridge-water' => 'Bridge Water (bridge,road)',
				),
				array(
					'fas fa-briefcase' => 'Briefcase (bag,briefcas,briefcase,business,luggage,office,work)',
				),
				array(
					'fas fa-building' => 'Building (apartment,building,business,city,company,office,office building,urban,work)',
				),
				array(
					'far fa-building' => 'Building (apartment,building,business,city,company,office,office building,urban,work)',
				),
				array(
					'fas fa-building-columns' => 'Building Columns (bank,institution,museum,university,bank,building,college,education,institution,museum,students)',
				),
				array(
					'fas fa-cake-candles' => 'Cake Candles (birthday-cake,cake,anniversary,bakery,birthday,birthday cake,cake,candles,celebration,dessert,frosting,holiday,party,pastry,sweet)',
				),
				array(
					'fas fa-car' => 'Car (automobile,auto,automobile,car,oncoming,oncoming automobile,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-cart-shopping' => 'Cart Shopping (shopping-cart,buy,cart,checkout,grocery,payment,purchase,shopping,shopping cart,trolley)',
				),
				array(
					'fas fa-circle-info' => 'Circle Info (info-circle,details,help,information,more,support)',
				),
				array(
					'fas fa-crosshairs' => 'Crosshairs (aim,bullseye,gpd,picker,position)',
				),
				array(
					'fas fa-diamond-turn-right' => 'Diamond Turn Right (directions,map,navigation,sign,turn)',
				),
				array(
					'fas fa-dollar-sign' => 'Dollar Sign (dollar,usd,Dollar Sign,currency,dollar,heavy dollar sign,money)',
				),
				array(
					'fas fa-draw-polygon' => 'Draw Polygon (anchors,lines,object,render,shape)',
				),
				array(
					'fas fa-droplet' => 'Droplet (tint,cold,color,comic,drop,droplet,raindrop,sweat,waterdrop)',
				),
				array(
					'fas fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'far fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'fas fa-eye-low-vision' => 'Eye Low Vision (low-vision,blind,eye,sight)',
				),
				array(
					'fas fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'far fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'fas fa-fire' => 'Fire (burn,caliente,fire,flame,heat,hot,popular,tool)',
				),
				array(
					'fas fa-fire-extinguisher' => 'Fire Extinguisher (burn,caliente,extinguish,fire,fire extinguisher,fire fighter,flame,heat,hot,quench,rescue)',
				),
				array(
					'fas fa-fire-flame-curved' => 'Fire Flame Curved (fire-alt,burn,caliente,flame,heat,hot,popular)',
				),
				array(
					'fas fa-flag' => 'Flag (black flag,country,notice,notification,notify,pole,report,symbol,waving)',
				),
				array(
					'far fa-flag' => 'Flag (black flag,country,notice,notification,notify,pole,report,symbol,waving)',
				),
				array(
					'fas fa-flag-checkered' => 'Flag Checkered (checkered,chequered,chequered flag,finish,notice,notification,notify,pole,racing,report,start,symbol,win)',
				),
				array(
					'fas fa-flask' => 'Flask (beaker,chemicals,experiment,experimental,labs,liquid,potion,science,vial)',
				),
				array(
					'fas fa-gamepad' => 'Gamepad (arcade,controller,d-pad,joystick,video,video game)',
				),
				array(
					'fas fa-gavel' => 'Gavel (legal,hammer,judge,law,lawyer,opinion)',
				),
				array(
					'fas fa-gift' => 'Gift (box,celebration,christmas,generosity,gift,giving,holiday,party,present,wrapped,wrapped gift,xmas)',
				),
				array(
					'fas fa-globe' => 'Globe (all,coordinates,country,earth,global,globe,globe with meridians,gps,internet,language,localize,location,map,meridians,network,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-graduation-cap' => 'Graduation Cap (mortar-board,cap,celebration,ceremony,clothing,college,graduate,graduation,graduation cap,hat,learning,school,student)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fas fa-heart-pulse' => 'Heart Pulse (heartbeat,ekg,electrocardiogram,health,lifeline,vital signs)',
				),
				array(
					'fas fa-helicopter' => 'Helicopter (airwolf,apache,chopper,flight,fly,helicopter,travel,vehicle)',
				),
				array(
					'fas fa-helicopter-symbol' => 'Helicopter Symbol (chopper,helicopter,landing pad,whirlybird)',
				),
				array(
					'fas fa-hospital' => 'Hospital (hospital-alt,hospital-wide,building,covid-19,doctor,emergency room,hospital,medical center,medicine)',
				),
				array(
					'far fa-hospital' => 'Hospital (hospital-alt,hospital-wide,building,covid-19,doctor,emergency room,hospital,medical center,medicine)',
				),
				array(
					'fas fa-house' => 'House (home,home-alt,home-lg-alt,abode,building,home,house,main,residence)',
				),
				array(
					'fas fa-image' => 'Image (album,landscape,photo,picture)',
				),
				array(
					'far fa-image' => 'Image (album,landscape,photo,picture)',
				),
				array(
					'fas fa-images' => 'Images (album,landscape,photo,picture)',
				),
				array(
					'far fa-images' => 'Images (album,landscape,photo,picture)',
				),
				array(
					'fas fa-industry' => 'Industry (building,factory,industrial,manufacturing,mill,warehouse)',
				),
				array(
					'fas fa-info' => 'Info (details,help,information,more,support)',
				),
				array(
					'fas fa-jet-fighter' => 'Jet Fighter (fighter-jet,airforce,airplane,airport,fast,fly,goose,marines,maverick,military,plane,quick,top gun,transportation,travel)',
				),
				array(
					'fas fa-key' => 'Key (key,lock,password,private,secret,unlock)',
				),
				array(
					'fas fa-landmark' => 'Landmark (building,classical,historic,memorable,monument,museum,politics)',
				),
				array(
					'fas fa-landmark-flag' => 'Landmark Flag (capitol,flag,landmark,memorial)',
				),
				array(
					'fas fa-layer-group' => 'Layer Group (arrange,develop,layers,map,stack)',
				),
				array(
					'fas fa-leaf' => 'Leaf (eco,flora,nature,plant,vegan)',
				),
				array(
					'fas fa-lemon' => 'Lemon (citrus,fruit,lemon,lemonade,lime,tart)',
				),
				array(
					'far fa-lemon' => 'Lemon (citrus,fruit,lemon,lemonade,lime,tart)',
				),
				array(
					'fas fa-life-ring' => 'Life Ring (coast guard,help,overboard,save,support)',
				),
				array(
					'far fa-life-ring' => 'Life Ring (coast guard,help,overboard,save,support)',
				),
				array(
					'fas fa-lightbulb' => 'Lightbulb (	comic,	electric,	idea,	innovation,	inspiration,	light,	light bulb, bulb,bulb,comic,electric,energy,idea,inspiration,mechanical)',
				),
				array(
					'far fa-lightbulb' => 'Lightbulb (	comic,	electric,	idea,	innovation,	inspiration,	light,	light bulb, bulb,bulb,comic,electric,energy,idea,inspiration,mechanical)',
				),
				array(
					'fas fa-location-arrow' => 'Location Arrow (address,compass,coordinate,direction,gps,map,navigation,place)',
				),
				array(
					'fas fa-location-crosshairs' => 'Location Crosshairs (location,address,coordinate,direction,gps,location,map,navigation,place,where)',
				),
				array(
					'fas fa-location-dot' => 'Location Dot (map-marker-alt,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-location-pin' => 'Location Pin (map-marker,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-location-pin-lock' => 'Location Pin Lock (closed,lockdown,map,quarantine)',
				),
				array(
					'fas fa-magnet' => 'Magnet (Attract,attraction,horseshoe,lodestone,magnet,magnetic,tool)',
				),
				array(
					'fas fa-magnifying-glass' => 'Magnifying Glass (search,bigger,enlarge,find,glass,magnify,magnifying,magnifying glass tilted left,preview,search,tool,zoom)',
				),
				array(
					'fas fa-magnifying-glass-minus' => 'Magnifying Glass Minus (search-minus,minify,negative,smaller,zoom,zoom out)',
				),
				array(
					'fas fa-magnifying-glass-plus' => 'Magnifying Glass Plus (search-plus,bigger,enlarge,magnify,positive,zoom,zoom in)',
				),
				array(
					'fas fa-map' => 'Map (address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel,world,world map)',
				),
				array(
					'far fa-map' => 'Map (address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel,world,world map)',
				),
				array(
					'fas fa-map-pin' => 'Map Pin (address,agree,coordinates,destination,gps,localize,location,map,marker,navigation,pin,place,position,pushpin,round pushpin,travel)',
				),
				array(
					'fas fa-martini-glass-empty' => 'Martini Glass Empty (glass-martini,alcohol,bar,beverage,drink,liquor)',
				),
				array(
					'fas fa-money-bill' => 'Money Bill (buy,cash,checkout,money,payment,price,purchase)',
				),
				array(
					'fas fa-money-bill-1' => 'Money Bill 1 (money-bill-alt,buy,cash,checkout,money,payment,price,purchase)',
				),
				array(
					'far fa-money-bill-1' => 'Money Bill 1 (money-bill-alt,buy,cash,checkout,money,payment,price,purchase)',
				),
				array(
					'fas fa-monument' => 'Monument (building,historic,landmark,memorable)',
				),
				array(
					'fas fa-motorcycle' => 'Motorcycle (bike,machine,motorcycle,racing,transportation,vehicle)',
				),
				array(
					'fas fa-mountain-sun' => 'Mountain Sun (country,hiking,landscape,rural,travel,view)',
				),
				array(
					'fas fa-mug-saucer' => 'Mug Saucer (coffee,beverage,breakfast,cafe,drink,fall,morning,mug,seasonal,tea)',
				),
				array(
					'fas fa-music' => 'Music (lyrics,melody,music,musical note,note,sing,sound)',
				),
				array(
					'fas fa-newspaper' => 'Newspaper (article,editorial,headline,journal,journalism,news,newspaper,paper,press)',
				),
				array(
					'far fa-newspaper' => 'Newspaper (article,editorial,headline,journal,journalism,news,newspaper,paper,press)',
				),
				array(
					'fas fa-paw' => 'Paw (animal,cat,dog,pet,print)',
				),
				array(
					'fas fa-person' => 'Person (male,man,person standing,stand,standing,woman)',
				),
				array(
					'fas fa-person-walking-with-cane' => 'Person Walking With Cane (blind,blind,cane)',
				),
				array(
					'fas fa-phone' => 'Phone (Left Hand Telephone Receiver,call,earphone,number,phone,receiver,support,telephone,telephone receiver,voice)',
				),
				array(
					'fas fa-phone-flip' => 'Phone Flip (phone-alt,Right Hand Telephone Receiver,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-phone-volume' => 'Phone Volume (volume-control-phone,call,earphone,number,sound,support,telephone,voice,volume-control-phone)',
				),
				array(
					'fas fa-plane' => 'Plane (airplane,airport,destination,fly,location,mode,travel,trip)',
				),
				array(
					'fas fa-plug' => 'Plug (connect,electric,electric plug,electricity,online,plug,power)',
				),
				array(
					'fas fa-plus' => 'Plus (add,+,Plus Sign,add,create,expand,math,new,plus,positive,shape,sign)',
				),
				array(
					'fas fa-print' => 'Print (Print Screen Symbol,Printer Icon,business,computer,copy,document,office,paper,printer)',
				),
				array(
					'fas fa-recycle' => 'Recycle (Recycling Symbol For Generic Materials,Universal Recycling Symbol,Waste,compost,garbage,recycle,recycling symbol,reuse,trash)',
				),
				array(
					'fas fa-restroom' => 'Restroom (bathroom,toilet,water closet,wc)',
				),
				array(
					'fas fa-road' => 'Road (highway,map,motorway,pavement,road,route,street,travel)',
				),
				array(
					'fas fa-rocket' => 'Rocket (aircraft,app,jet,launch,nasa,space)',
				),
				array(
					'fas fa-route' => 'Route (directions,navigation,travel)',
				),
				array(
					'fas fa-scale-balanced' => 'Scale Balanced (balance-scale,Libra,balance,balance scale,balanced,justice,law,legal,measure,rule,scale,weight,zodiac)',
				),
				array(
					'fas fa-scale-unbalanced' => 'Scale Unbalanced (balance-scale-left,justice,legal,measure,unbalanced,weight)',
				),
				array(
					'fas fa-scale-unbalanced-flip' => 'Scale Unbalanced Flip (balance-scale-right,justice,legal,measure,unbalanced,weight)',
				),
				array(
					'fas fa-ship' => 'Ship (boat,passenger,sea,ship,water)',
				),
				array(
					'fas fa-shoe-prints' => 'Shoe Prints (feet,footprints,steps,walk)',
				),
				array(
					'fas fa-shower' => 'Shower (bath,clean,faucet,shower,water)',
				),
				array(
					'fas fa-signs-post' => 'Signs Post (map-signs,directions,directory,map,signage,wayfinding)',
				),
				array(
					'fas fa-snowplow' => 'Snowplow (clean up,cold,road,storm,winter)',
				),
				array(
					'fas fa-spoon' => 'Spoon (utensil-spoon,cutlery,dining,scoop,silverware,spoon,tableware)',
				),
				array(
					'fas fa-square-h' => 'Square H (h-square,directions,emergency,hospital,hotel,letter,map)',
				),
				array(
					'fas fa-square-parking' => 'Square Parking (parking,auto,car,garage,meter,parking)',
				),
				array(
					'fas fa-square-phone' => 'Square Phone (phone-square,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-square-phone-flip' => 'Square Phone Flip (phone-square-alt,call,earphone,number,support,telephone,voice)',
				),
				array(
					'fas fa-square-plus' => 'Square Plus (plus-square,add,create,expand,new,positive,shape)',
				),
				array(
					'far fa-square-plus' => 'Square Plus (plus-square,add,create,expand,new,positive,shape)',
				),
				array(
					'fas fa-street-view' => 'Street View (directions,location,map,navigation)',
				),
				array(
					'fas fa-suitcase' => 'Suitcase (baggage,luggage,move,packing,suitcase,travel,trip)',
				),
				array(
					'fas fa-suitcase-medical' => 'Suitcase Medical (medkit,first aid,firstaid,health,help,medical,supply,support)',
				),
				array(
					'fas fa-tag' => 'Tag (discount,labe,label,price,shopping)',
				),
				array(
					'fas fa-tags' => 'Tags (discount,label,price,shopping)',
				),
				array(
					'fas fa-taxi' => 'Taxi (cab,cab,cabbie,car,car service,lyft,machine,oncoming,oncoming taxi,taxi,transportation,travel,uber,vehicle)',
				),
				array(
					'fas fa-thumbtack' => 'Thumbtack (thumb-tack,Black Pushpin,coordinates,location,marker,pin,pushpin,thumb-tack)',
				),
				array(
					'fas fa-ticket' => 'Ticket (admission,admission tickets,movie,pass,support,ticket)',
				),
				array(
					'fas fa-ticket-simple' => 'Ticket Simple (ticket-alt,movie,pass,support,ticket)',
				),
				array(
					'fas fa-traffic-light' => 'Traffic Light (direction,light,road,signal,traffic,travel,vertical traffic light)',
				),
				array(
					'fas fa-train' => 'Train (bullet,commute,locomotive,railway,subway,train)',
				),
				array(
					'fas fa-train-subway' => 'Train Subway (subway,machine,railway,train,transportation,vehicle)',
				),
				array(
					'fas fa-train-tram' => 'Train Tram (crossing,machine,mountains,seasonal,tram,transportation,trolleybus)',
				),
				array(
					'fas fa-tree' => 'Tree (bark,evergreen tree,fall,flora,forest,nature,plant,seasonal,tree)',
				),
				array(
					'fas fa-trophy' => 'Trophy (achievement,award,cup,game,prize,trophy,winner)',
				),
				array(
					'fas fa-truck' => 'Truck (Black Truck,cargo,delivery,delivery truck,shipping,truck,vehicle)',
				),
				array(
					'fas fa-truck-medical' => 'Truck Medical (ambulance,ambulance,clinic,covid-19,emergency,emt,er,help,hospital,mobile,support,vehicle)',
				),
				array(
					'fas fa-tty' => 'Tty (teletype,communication,deaf,telephone,teletypewriter,text)',
				),
				array(
					'fas fa-umbrella' => 'Umbrella (protection,rain,storm,wet)',
				),
				array(
					'fas fa-utensils' => 'Utensils (cutlery,cooking,cutlery,dining,dinner,eat,food,fork,fork and knife,knife,restaurant)',
				),
				array(
					'fas fa-vest' => 'Vest (biker,fashion,style)',
				),
				array(
					'fas fa-vest-patches' => 'Vest Patches (biker,fashion,style)',
				),
				array(
					'fas fa-wheelchair' => 'Wheelchair (users-people)',
				),
				array(
					'fas fa-wheelchair-move' => 'Wheelchair Move (wheelchair-alt,access,handicap,impairment,physical,wheelchair symbol)',
				),
				array(
					'fas fa-wifi' => 'Wifi (wifi-3,wifi-strong,connection,hotspot,internet,network,wireless)',
				),
				array(
					'fas fa-wine-glass' => 'Wine Glass (alcohol,bar,beverage,cabernet,drink,glass,grapes,merlot,sauvignon,wine,wine glass)',
				),
				array(
					'fas fa-wrench' => 'Wrench (construction,fix,mechanic,plumbing,settings,spanner,tool,update,wrench)',
				),
			),
			'Maritime' => array(
				array(
					'fas fa-anchor' => 'Anchor (anchor,berth,boat,dock,embed,link,maritime,moor,port,secure,ship,tool)',
				),
				array(
					'fas fa-anchor-circle-check' => 'Anchor Circle Check (marina,not affected,ok,okay,port)',
				),
				array(
					'fas fa-anchor-circle-exclamation' => 'Anchor Circle Exclamation (affected,marina,port)',
				),
				array(
					'fas fa-anchor-circle-xmark' => 'Anchor Circle Xmark (destroy,marina,port)',
				),
				array(
					'fas fa-anchor-lock' => 'Anchor Lock (closed,lockdown,marina,port,quarantine)',
				),
				array(
					'fas fa-ferry' => 'Ferry (barge,boat,carry,ferryboat,ship)',
				),
				array(
					'fas fa-fish' => 'Fish (Pisces,fauna,fish,gold,seafood,swimming,zodiac)',
				),
				array(
					'fas fa-fish-fins' => 'Fish Fins (fish,fishery,pisces,seafood)',
				),
				array(
					'fas fa-otter' => 'Otter (animal,badger,fauna,fishing,fur,mammal,marten,otter,playful)',
				),
				array(
					'fas fa-person-swimming' => 'Person Swimming (swimmer,ocean,person swimming,pool,sea,swim,water)',
				),
				array(
					'fas fa-sailboat' => 'Sailboat (dinghy,mast,sailboat,sailing,yacht)',
				),
				array(
					'fas fa-ship' => 'Ship (boat,passenger,sea,ship,water)',
				),
				array(
					'fas fa-shrimp' => 'Shrimp (allergy,crustacean,prawn,seafood,shellfish,shrimp,tail)',
				),
				array(
					'fas fa-water' => 'Water (lake,liquid,ocean,sea,swim,wet)',
				),
			),
			'Marketing' => array(
				array(
					'fas fa-arrows-spin' => 'Arrows Spin (cycle,rotate,spin,whirl)',
				),
				array(
					'fas fa-arrows-to-dot' => 'Arrows To Dot (assembly point,center,condense,focus,minimize)',
				),
				array(
					'fas fa-arrows-to-eye' => 'Arrows To Eye (center,coordinated assessment,focus)',
				),
				array(
					'fas fa-bullhorn' => 'Bullhorn (Bullhorn,announcement,broadcast,loud,louder,loudspeaker,megaphone,public address,share)',
				),
				array(
					'fas fa-bullseye' => 'Bullseye (archery,goal,objective,strategy,target)',
				),
				array(
					'fas fa-chart-simple' => 'Chart Simple (analytics,bar,chart,column,graph,row,trend)',
				),
				array(
					'fas fa-comment-dollar' => 'Comment Dollar (bubble,chat,commenting,conversation,feedback,message,money,note,notification,pay,sms,speech,spend,texting,transfer)',
				),
				array(
					'fas fa-comments-dollar' => 'Comments Dollar (bubble,chat,commenting,conversation,feedback,message,money,note,notification,pay,sms,speech,spend,texting,transfer)',
				),
				array(
					'fas fa-envelope-open-text' => 'Envelope Open Text (e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-envelopes-bulk' => 'Envelopes Bulk (mail-bulk,archive,envelope,letter,post office,postal,postcard,send,stamp,usps)',
				),
				array(
					'fas fa-filter-circle-dollar' => 'Filter Circle Dollar (funnel-dollar,filter,money,options,separate,sort)',
				),
				array(
					'fas fa-group-arrows-rotate' => 'Group Arrows Rotate (community,engagement,spin,sync)',
				),
				array(
					'fas fa-lightbulb' => 'Lightbulb (	comic,	electric,	idea,	innovation,	inspiration,	light,	light bulb, bulb,bulb,comic,electric,energy,idea,inspiration,mechanical)',
				),
				array(
					'far fa-lightbulb' => 'Lightbulb (	comic,	electric,	idea,	innovation,	inspiration,	light,	light bulb, bulb,bulb,comic,electric,energy,idea,inspiration,mechanical)',
				),
				array(
					'fas fa-magnifying-glass-arrow-right' => 'Magnifying Glass Arrow Right (find,next,search)',
				),
				array(
					'fas fa-magnifying-glass-chart' => 'Magnifying Glass Chart ( data, graph, intelligence,analysis,chart,market)',
				),
				array(
					'fas fa-magnifying-glass-dollar' => 'Magnifying Glass Dollar (search-dollar,bigger,enlarge,find,magnify,money,preview,zoom)',
				),
				array(
					'fas fa-magnifying-glass-location' => 'Magnifying Glass Location (search-location,bigger,enlarge,find,magnify,preview,zoom)',
				),
				array(
					'fas fa-people-group' => 'People Group (family,group,team)',
				),
				array(
					'fas fa-person-rays' => 'Person Rays (affected,focus,shine)',
				),
				array(
					'fas fa-ranking-star' => 'Ranking Star (chart,first place,podium,rank,win)',
				),
				array(
					'fas fa-rectangle-ad' => 'Rectangle Ad (ad,advertisement,media,newspaper,promotion,publicity)',
				),
				array(
					'fas fa-square-poll-horizontal' => 'Square Poll Horizontal (poll-h,chart,graph,results,survey,trend,vote,voting)',
				),
				array(
					'fas fa-square-poll-vertical' => 'Square Poll Vertical (poll,chart,graph,results,survey,trend,vote,voting)',
				),
				array(
					'fas fa-timeline' => 'Timeline (chronological,deadline,history,linear)',
				),
			),
			'Mathematics' => array(
				array(
					'fas fa-calculator' => 'Calculator (Pocket Calculator,abacus,addition,arithmetic,counting,math,multiplication,subtraction)',
				),
				array(
					'fas fa-circle-minus' => 'Circle Minus (minus-circle,delete,hide,negative,remove,shape,trash)',
				),
				array(
					'fas fa-circle-plus' => 'Circle Plus (plus-circle,add,create,expand,new,positive,shape)',
				),
				array(
					'fas fa-circle-xmark' => 'Circle Xmark (times-circle,xmark-circle,close,cross,destroy,exit,incorrect,notice,notification,notify,problem,wrong,x)',
				),
				array(
					'far fa-circle-xmark' => 'Circle Xmark (times-circle,xmark-circle,close,cross,destroy,exit,incorrect,notice,notification,notify,problem,wrong,x)',
				),
				array(
					'fas fa-divide' => 'Divide (Division Sign,arithmetic,calculus,divide,division,math,sign,÷)',
				),
				array(
					'fas fa-equals' => 'Equals (Equals Sign,arithmetic,even,match,math)',
				),
				array(
					'fas fa-greater-than' => 'Greater Than (Greater-Than Sign,arithmetic,compare,math)',
				),
				array(
					'fas fa-greater-than-equal' => 'Greater Than Equal (arithmetic,compare,math)',
				),
				array(
					'fas fa-infinity' => 'Infinity (Infinity,eternity,forever,infinity,math,unbounded,universal)',
				),
				array(
					'fas fa-less-than' => 'Less Than (Less-Than Sign,arithmetic,compare,math)',
				),
				array(
					'fas fa-less-than-equal' => 'Less Than Equal (arithmetic,compare,math)',
				),
				array(
					'fas fa-minus' => 'Minus (subtract,En Dash,Minus Sign,collapse,delete,hide,math,minify,minus,negative,remove,sign,trash,−)',
				),
				array(
					'fas fa-not-equal' => 'Not Equal (arithmetic,compare,math)',
				),
				array(
					'fas fa-percent' => 'Percent (percentage,Percent Sign,discount,fraction,proportion,rate,ratio)',
				),
				array(
					'fas fa-plus' => 'Plus (add,+,Plus Sign,add,create,expand,math,new,plus,positive,shape,sign)',
				),
				array(
					'fas fa-plus-minus' => 'Plus Minus (Plus-Minus Sign,add,math,subtract)',
				),
				array(
					'fas fa-square-minus' => 'Square Minus (minus-square,collapse,delete,hide,minify,negative,remove,shape,trash)',
				),
				array(
					'far fa-square-minus' => 'Square Minus (minus-square,collapse,delete,hide,minify,negative,remove,shape,trash)',
				),
				array(
					'fas fa-square-root-variable' => 'Square Root Variable (square-root-alt,arithmetic,calculus,division,math)',
				),
				array(
					'fas fa-square-xmark' => 'Square Xmark (times-square,xmark-square,close,cross,cross mark button,incorrect,mark,notice,notification,notify,problem,square,window,wrong,x,×)',
				),
				array(
					'fas fa-subscript' => 'Subscript (edit,font,format,text,type)',
				),
				array(
					'fas fa-superscript' => 'Superscript (edit,exponential,font,format,text,type)',
				),
				array(
					'fas fa-wave-square' => 'Wave Square (frequency,pulse,signal)',
				),
				array(
					'fas fa-xmark' => 'Xmark (close,multiply,remove,times,Cancellation X,Multiplication Sign,Multiplication X,cancel,close,cross,cross mark,error,exit,incorrect,mark,multiplication,multiply,notice,notification,notify,problem,sign,wrong,x,×)',
				),
			),
			'Media Playback' => array(
				array(
					'fas fa-arrow-rotate-left' => 'Arrow Rotate Left (arrow-left-rotate,arrow-rotate-back,arrow-rotate-backward,undo,Anticlockwise Open Circle Arrow,back,control z,exchange,oops,return,rotate,swap)',
				),
				array(
					'fas fa-arrow-rotate-right' => 'Arrow Rotate Right (arrow-right-rotate,arrow-rotate-forward,redo,Clockwise Open Circle Arrow,forward,refresh,reload,repeat)',
				),
				array(
					'fas fa-arrows-rotate' => 'Arrows Rotate (refresh,sync,Clockwise Right and Left Semicircle Arrows,exchange,refresh,reload,rotate,swap)',
				),
				array(
					'fas fa-backward' => 'Backward (arrow,double,fast reverse button,previous,rewind)',
				),
				array(
					'fas fa-backward-fast' => 'Backward Fast (fast-backward,arrow,beginning,first,last track button,previous,previous scene,previous track,rewind,start,triangle)',
				),
				array(
					'fas fa-backward-step' => 'Backward Step (step-backward,beginning,first,previous,rewind,start)',
				),
				array(
					'fas fa-circle-pause' => 'Circle Pause (pause-circle,hold,wait)',
				),
				array(
					'far fa-circle-pause' => 'Circle Pause (pause-circle,hold,wait)',
				),
				array(
					'fas fa-circle-play' => 'Circle Play (play-circle,audio,music,playing,sound,start,video)',
				),
				array(
					'far fa-circle-play' => 'Circle Play (play-circle,audio,music,playing,sound,start,video)',
				),
				array(
					'fas fa-circle-stop' => 'Circle Stop (stop-circle,block,box,circle,square)',
				),
				array(
					'far fa-circle-stop' => 'Circle Stop (stop-circle,block,box,circle,square)',
				),
				array(
					'fas fa-compress' => 'Compress (collapse,fullscreen,minimize,move,resize,shrink,smaller)',
				),
				array(
					'fas fa-down-left-and-up-right-to-center' => 'Down Left And Up Right To Center (compress-alt,collapse,fullscreen,minimize,move,resize,shrink,smaller)',
				),
				array(
					'fas fa-eject' => 'Eject (abort,cancel,cd,discharge,eject,eject button)',
				),
				array(
					'fas fa-expand' => 'Expand (bigger,crop,enlarge,focus,fullscreen,resize,viewfinder)',
				),
				array(
					'fas fa-forward' => 'Forward (arrow,double,fast,fast-forward button,forward,next,skip)',
				),
				array(
					'fas fa-forward-fast' => 'Forward Fast (fast-forward,arrow,end,last,next,next scene,next track,next track button,triangle)',
				),
				array(
					'fas fa-forward-step' => 'Forward Step (step-forward,end,last,next)',
				),
				array(
					'fas fa-hand' => 'Hand (hand-paper,Raised Hand,backhand,game,halt,palm,raised,raised back of hand,roshambo,stop)',
				),
				array(
					'far fa-hand' => 'Hand (hand-paper,Raised Hand,backhand,game,halt,palm,raised,raised back of hand,roshambo,stop)',
				),
				array(
					'fas fa-maximize' => 'Maximize (expand-arrows-alt,bigger,enlarge,fullscreen,move,resize)',
				),
				array(
					'fas fa-minimize' => 'Minimize (compress-arrows-alt,collapse,fullscreen,minimize,move,resize,shrink,smaller)',
				),
				array(
					'fas fa-music' => 'Music (lyrics,melody,music,musical note,note,sing,sound)',
				),
				array(
					'fas fa-pause' => 'Pause (bar,double,hold,pause,pause button,vertical,wait)',
				),
				array(
					'fas fa-phone-volume' => 'Phone Volume (volume-control-phone,call,earphone,number,sound,support,telephone,voice,volume-control-phone)',
				),
				array(
					'fas fa-play' => 'Play (arrow,audio,music,play,play button,playing,right,sound,start,triangle,video)',
				),
				array(
					'fas fa-plus-minus' => 'Plus Minus (Plus-Minus Sign,add,math,subtract)',
				),
				array(
					'fas fa-repeat' => 'Repeat (arrow,clockwise,flip,reload,repeat,repeat button,rewind,switch)',
				),
				array(
					'fas fa-rotate' => 'Rotate (sync-alt,anticlockwise,arrow,counterclockwise,counterclockwise arrows button,exchange,refresh,reload,rotate,swap,withershins)',
				),
				array(
					'fas fa-rotate-left' => 'Rotate Left (rotate-back,rotate-backward,undo-alt,back,control z,exchange,oops,return,swap)',
				),
				array(
					'fas fa-rotate-right' => 'Rotate Right (redo-alt,rotate-forward,forward,refresh,reload,repeat)',
				),
				array(
					'fas fa-rss' => 'Rss (feed,blog,feed,journal,news,writing)',
				),
				array(
					'fas fa-shuffle' => 'Shuffle (random,arrow,arrows,crossed,shuffle,shuffle tracks button,sort,swap,switch,transfer)',
				),
				array(
					'fas fa-sliders' => 'Sliders (sliders-h,adjust,settings,sliders,toggle)',
				),
				array(
					'fas fa-stop' => 'Stop (block,box,square,stop,stop button)',
				),
				array(
					'fas fa-up-right-and-down-left-from-center' => 'Up Right And Down Left From Center (expand-alt,arrows,bigger,enlarge,fullscreen,resize)',
				),
				array(
					'fas fa-volume-high' => 'Volume High (volume-up,audio,higher,loud,louder,music,sound,speaker,speaker high volume)',
				),
				array(
					'fas fa-volume-low' => 'Volume Low (volume-down,audio,lower,music,quieter,soft,sound,speaker,speaker low volume)',
				),
				array(
					'fas fa-volume-off' => 'Volume Off (audio,ban,music,mute,quiet,silent,sound)',
				),
				array(
					'fas fa-volume-xmark' => 'Volume Xmark (volume-mute,volume-times,audio,music,quiet,sound,speaker)',
				),
			),
			'Medical + Health' => array(
				array(
					'fab fa-accessible-icon' => 'Accessible Icon (accessibility,handicap,person,wheelchair,wheelchair-alt)',
				),
				array(
					'fas fa-bacteria' => 'Bacteria (antibiotic,antibody,covid-19,health,organism,sick)',
				),
				array(
					'fas fa-bacterium' => 'Bacterium (antibiotic,antibody,covid-19,health,organism,sick)',
				),
				array(
					'fas fa-ban-smoking' => 'Ban Smoking (smoking-ban,ban,cancel,forbidden,no,no smoking,non-smoking,not,prohibited,smoking)',
				),
				array(
					'fas fa-bandage' => 'Bandage (band-aid,adhesive bandage,bandage,boo boo,first aid,ouch)',
				),
				array(
					'fas fa-bed-pulse' => 'Bed Pulse (procedures,EKG,bed,electrocardiogram,health,hospital,life,patient,vital)',
				),
				array(
					'fas fa-biohazard' => 'Biohazard (biohazard,covid-19,danger,dangerous,epidemic,hazmat,medical,pandemic,radioactive,sign,toxic,waste,zombie)',
				),
				array(
					'fas fa-bone' => 'Bone (bone,calcium,dog,skeletal,skeleton,tibia)',
				),
				array(
					'fas fa-bong' => 'Bong (aparatus,cannabis,marijuana,pipe,smoke,smoking)',
				),
				array(
					'fas fa-book-medical' => 'Book Medical (diary,documentation,health,history,journal,library,read,record,research)',
				),
				array(
					'fas fa-brain' => 'Brain (brain,cerebellum,gray matter,intellect,intelligent,medulla oblongata,mind,noodle,wit)',
				),
				array(
					'fas fa-briefcase-medical' => 'Briefcase Medical (doctor,emt,first aid,health)',
				),
				array(
					'fas fa-cannabis' => 'Cannabis (bud,chronic,drugs,endica,endo,ganja,marijuana,mary jane,pot,reefer,sativa,spliff,weed,whacky-tabacky)',
				),
				array(
					'fas fa-capsules' => 'Capsules (drugs,medicine,pills,prescription)',
				),
				array(
					'fas fa-circle-h' => 'Circle H (hospital-symbol,Circled Latin Capital Letter H,clinic,covid-19,emergency,letter,map)',
				),
				array(
					'fas fa-circle-radiation' => 'Circle Radiation (radiation-alt,danger,dangerous,deadly,hazard,nuclear,radioactive,sign,warning)',
				),
				array(
					'fas fa-clipboard-user' => 'Clipboard User (attendance,record,roster,staff)',
				),
				array(
					'fas fa-clock-rotate-left' => 'Clock Rotate Left (history,Rewind,clock,reverse,time,time machine,time travel)',
				),
				array(
					'fas fa-comment-medical' => 'Comment Medical (advice,bubble,chat,commenting,conversation,diagnose,feedback,message,note,notification,prescription,sms,speech,texting)',
				),
				array(
					'fas fa-crutch' => 'Crutch (cane,injury,mobility,wheelchair)',
				),
				array(
					'fas fa-disease' => 'Disease (bacteria,cancer,coronavirus,covid-19,flu,illness,infection,pandemic,sickness,virus)',
				),
				array(
					'fas fa-dna' => 'Dna (biologist,dna,double helix,evolution,gene,genetic,genetics,helix,life,molecule,protein)',
				),
				array(
					'fas fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'far fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'fas fa-eye-dropper' => 'Eye Dropper (eye-dropper-empty,eyedropper,beaker,clone,color,copy,eyedropper,pipette)',
				),
				array(
					'fas fa-file-medical' => 'File Medical (document,health,history,prescription,record)',
				),
				array(
					'fas fa-file-prescription' => 'File Prescription (document,drugs,medical,medicine,rx)',
				),
				array(
					'fas fa-file-waveform' => 'File Waveform (file-medical-alt,document,health,history,prescription,record)',
				),
				array(
					'fas fa-fire-flame-simple' => 'Fire Flame Simple (burn,caliente,energy,fire,flame,gas,heat,hot)',
				),
				array(
					'fas fa-flask' => 'Flask (beaker,chemicals,experiment,experimental,labs,liquid,potion,science,vial)',
				),
				array(
					'fas fa-flask-vial' => 'Flask Vial ( beaker, chemicals, experiment, experimental, labs, liquid, science, vial,ampule,chemistry,lab,laboratory,potion,test,test tube)',
				),
				array(
					'fas fa-hand-dots' => 'Hand Dots (allergies,allergy,freckles,hand,hives,palm,pox,skin,spots)',
				),
				array(
					'fas fa-hand-holding-medical' => 'Hand Holding Medical (care,covid-19,donate,help)',
				),
				array(
					'fas fa-head-side-cough' => 'Head Side Cough (cough,covid-19,germs,lungs,respiratory,sick)',
				),
				array(
					'fas fa-head-side-cough-slash' => 'Head Side Cough Slash (cough,covid-19,germs,lungs,respiratory,sick)',
				),
				array(
					'fas fa-head-side-mask' => 'Head Side Mask (breath,coronavirus,covid-19,filter,flu,infection,pandemic,respirator,virus)',
				),
				array(
					'fas fa-head-side-virus' => 'Head Side Virus (cold,coronavirus,covid-19,flu,infection,pandemic,sick)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fas fa-heart-circle-bolt' => 'Heart Circle Bolt (cardiogram,ekg,electric,heart,love,pacemaker)',
				),
				array(
					'fas fa-heart-circle-check' => 'Heart Circle Check (favorite,heart,love,not affected,ok,okay)',
				),
				array(
					'fas fa-heart-circle-exclamation' => 'Heart Circle Exclamation (favorite,heart,love)',
				),
				array(
					'fas fa-heart-circle-minus' => 'Heart Circle Minus (favorite,heart,love)',
				),
				array(
					'fas fa-heart-circle-plus' => 'Heart Circle Plus (favorite,heart,love)',
				),
				array(
					'fas fa-heart-circle-xmark' => 'Heart Circle Xmark (favorite,heart,love)',
				),
				array(
					'fas fa-heart-pulse' => 'Heart Pulse (heartbeat,ekg,electrocardiogram,health,lifeline,vital signs)',
				),
				array(
					'fas fa-hospital' => 'Hospital (hospital-alt,hospital-wide,building,covid-19,doctor,emergency room,hospital,medical center,medicine)',
				),
				array(
					'far fa-hospital' => 'Hospital (hospital-alt,hospital-wide,building,covid-19,doctor,emergency room,hospital,medical center,medicine)',
				),
				array(
					'fas fa-hospital-user' => 'Hospital User (covid-19,doctor,network,patient,primary care)',
				),
				array(
					'fas fa-house-chimney-medical' => 'House Chimney Medical (clinic-medical,covid-19,doctor,general practitioner,hospital,infirmary,medicine,office,outpatient)',
				),
				array(
					'fas fa-house-medical' => 'House Medical (covid-19,doctor,facility,general practitioner,health,hospital,infirmary,medicine,office,outpatient)',
				),
				array(
					'fas fa-house-medical-circle-check' => 'House Medical Circle Check (clinic,hospital,not affected,ok,okay)',
				),
				array(
					'fas fa-house-medical-circle-exclamation' => 'House Medical Circle Exclamation (affected,clinic,hospital)',
				),
				array(
					'fas fa-house-medical-circle-xmark' => 'House Medical Circle Xmark (clinic,destroy,hospital)',
				),
				array(
					'fas fa-house-medical-flag' => 'House Medical Flag (clinic,hospital,mash)',
				),
				array(
					'fas fa-id-card-clip' => 'Id Card Clip (id-card-alt,contact,demographics,document,identification,issued,profile)',
				),
				array(
					'fas fa-joint' => 'Joint (blunt,cannabis,doobie,drugs,marijuana,roach,smoke,smoking,spliff)',
				),
				array(
					'fas fa-kit-medical' => 'Kit Medical (first-aid,emergency,emt,health,medical,rescue)',
				),
				array(
					'fas fa-laptop-medical' => 'Laptop Medical (computer,device,ehr,electronic health records,history)',
				),
				array(
					'fas fa-lungs' => 'Lungs (air,breath,covid-19,exhalation,inhalation,lungs,organ,respiration,respiratory)',
				),
				array(
					'fas fa-lungs-virus' => 'Lungs Virus (breath,coronavirus,covid-19,flu,infection,pandemic,respiratory,sick)',
				),
				array(
					'fas fa-mask-face' => 'Mask Face (breath,coronavirus,covid-19,filter,flu,infection,pandemic,respirator,virus)',
				),
				array(
					'fas fa-mask-ventilator' => 'Mask Ventilator (breath,gas,mask,oxygen,respirator,ventilator)',
				),
				array(
					'fas fa-microscope' => 'Microscope (covid-19,electron,lens,microscope,optics,science,shrink,testing,tool)',
				),
				array(
					'fas fa-mortar-pestle' => 'Mortar Pestle (crush,culinary,grind,medical,mix,pharmacy,prescription,spices)',
				),
				array(
					'fas fa-notes-medical' => 'Notes Medical (clipboard,doctor,ehr,health,history,records)',
				),
				array(
					'fas fa-pager' => 'Pager (beeper,cell phone,communication,page,pager)',
				),
				array(
					'fas fa-person-breastfeeding' => 'Person Breastfeeding (baby,child,infant,mother,nutrition,sustenance)',
				),
				array(
					'fas fa-person-cane' => 'Person Cane (aging,cane,elderly,old,staff)',
				),
				array(
					'fas fa-person-dots-from-line' => 'Person Dots From Line (diagnoses,allergy,diagnosis)',
				),
				array(
					'fas fa-person-half-dress' => 'Person Half Dress (gender,man,restroom,transgender,woman)',
				),
				array(
					'fas fa-pills' => 'Pills (drugs,medicine,prescription,tablets)',
				),
				array(
					'fas fa-plus' => 'Plus (add,+,Plus Sign,add,create,expand,math,new,plus,positive,shape,sign)',
				),
				array(
					'fas fa-poop' => 'Poop (crap,poop,shit,smile,turd)',
				),
				array(
					'fas fa-prescription' => 'Prescription (drugs,medical,medicine,pharmacy,rx)',
				),
				array(
					'fas fa-prescription-bottle' => 'Prescription Bottle (drugs,medical,medicine,pharmacy,rx)',
				),
				array(
					'fas fa-prescription-bottle-medical' => 'Prescription Bottle Medical (prescription-bottle-alt,drugs,medical,medicine,pharmacy,rx)',
				),
				array(
					'fas fa-pump-medical' => 'Pump Medical (anti-bacterial,clean,covid-19,disinfect,hygiene,medical grade,sanitizer,soap)',
				),
				array(
					'fas fa-radiation' => 'Radiation (danger,dangerous,deadly,hazard,nuclear,radioactive,warning)',
				),
				array(
					'fas fa-receipt' => 'Receipt (accounting,bookkeeping,check,evidence,invoice,money,pay,proof,receipt,table)',
				),
				array(
					'fas fa-shield-virus' => 'Shield Virus (antibodies,barrier,coronavirus,covid-19,flu,health,infection,pandemic,protect,safety,vaccine)',
				),
				array(
					'fas fa-skull' => 'Skull (bones,death,face,fairy tale,monster,skeleton,skull,x-ray,yorick)',
				),
				array(
					'fas fa-skull-crossbones' => 'Skull Crossbones (Black Skull and Crossbones,Dungeons & Dragons,alert,bones,crossbones,d&d,danger,dangerous area,dead,deadly,death,dnd,face,fantasy,halloween,holiday,jolly-roger,monster,pirate,poison,skeleton,skull,skull and crossbones,warning)',
				),
				array(
					'fas fa-smoking' => 'Smoking (cancer,cigarette,nicotine,smoking,smoking status,tobacco)',
				),
				array(
					'fas fa-square-h' => 'Square H (h-square,directions,emergency,hospital,hotel,letter,map)',
				),
				array(
					'fas fa-square-plus' => 'Square Plus (plus-square,add,create,expand,new,positive,shape)',
				),
				array(
					'far fa-square-plus' => 'Square Plus (plus-square,add,create,expand,new,positive,shape)',
				),
				array(
					'fas fa-square-virus' => 'Square Virus (coronavirus,covid-19,disease,flu,infection,pandemic)',
				),
				array(
					'fas fa-staff-snake' => 'Staff Snake (rod-asclepius,rod-snake,staff-aesculapius,asclepius,asklepian,health,serpent,wellness)',
				),
				array(
					'fas fa-star-of-life' => 'Star Of Life (doctor,emt,first aid,health,medical)',
				),
				array(
					'fas fa-stethoscope' => 'Stethoscope (covid-19,diagnosis,doctor,general practitioner,heart,hospital,infirmary,medicine,office,outpatient,stethoscope)',
				),
				array(
					'fas fa-suitcase-medical' => 'Suitcase Medical (medkit,first aid,firstaid,health,help,medical,supply,support)',
				),
				array(
					'fas fa-syringe' => 'Syringe (covid-19,doctor,immunizations,medical,medicine,needle,shot,sick,syringe,vaccinate,vaccine)',
				),
				array(
					'fas fa-tablets' => 'Tablets (drugs,medicine,pills,prescription)',
				),
				array(
					'fas fa-teeth' => 'Teeth (bite,dental,dentist,gums,mouth,smile,tooth)',
				),
				array(
					'fas fa-teeth-open' => 'Teeth Open (dental,dentist,gums bite,mouth,smile,tooth)',
				),
				array(
					'fas fa-thermometer' => 'Thermometer (covid-19,mercury,status,temperature)',
				),
				array(
					'fas fa-tooth' => 'Tooth (bicuspid,dental,dentist,molar,mouth,teeth,tooth)',
				),
				array(
					'fas fa-truck-medical' => 'Truck Medical (ambulance,ambulance,clinic,covid-19,emergency,emt,er,help,hospital,mobile,support,vehicle)',
				),
				array(
					'fas fa-user-doctor' => 'User Doctor (user-md,covid-19,health,job,medical,nurse,occupation,physician,profile,surgeon,worker)',
				),
				array(
					'fas fa-user-nurse' => 'User Nurse (covid-19,doctor,health,md,medical,midwife,physician,practitioner,surgeon,worker)',
				),
				array(
					'fas fa-vial' => 'Vial (ampule,chemist,chemistry,experiment,lab,sample,science,test,test tube)',
				),
				array(
					'fas fa-vial-circle-check' => 'Vial Circle Check (ampule,chemist,chemistry,not affected,ok,okay,success,test tube,tube,vaccine)',
				),
				array(
					'fas fa-vial-virus' => 'Vial Virus (ampule,coronavirus,covid-19,flue,infection,lab,laboratory,pandemic,test,test tube,vaccine)',
				),
				array(
					'fas fa-vials' => 'Vials (ampule,experiment,lab,sample,science,test,test tube)',
				),
				array(
					'fas fa-virus' => 'Virus (bug,coronavirus,covid-19,flu,health,infection,pandemic,sick,vaccine,viral)',
				),
				array(
					'fas fa-virus-covid' => 'Virus Covid (bug,covid-19,flu,health,infection,pandemic,vaccine,viral,virus)',
				),
				array(
					'fas fa-virus-covid-slash' => 'Virus Covid Slash (bug,covid-19,flu,health,infection,pandemic,vaccine,viral,virus)',
				),
				array(
					'fas fa-virus-slash' => 'Virus Slash (bug,coronavirus,covid-19,cure,eliminate,flu,health,infection,pandemic,sick,vaccine,viral)',
				),
				array(
					'fas fa-viruses' => 'Viruses (bugs,coronavirus,covid-19,flu,health,infection,multiply,pandemic,sick,spread,vaccine,viral)',
				),
				array(
					'fas fa-weight-scale' => 'Weight Scale (weight,health,measurement,scale,weight)',
				),
				array(
					'fas fa-wheelchair' => 'Wheelchair (users-people)',
				),
				array(
					'fas fa-wheelchair-move' => 'Wheelchair Move (wheelchair-alt,access,handicap,impairment,physical,wheelchair symbol)',
				),
				array(
					'fas fa-x-ray' => 'X Ray (health,medical,radiological images,radiology,skeleton)',
				),
			),
			'Money' => array(
				array(
					'fas fa-austral-sign' => 'Austral Sign (Austral Sign,currency)',
				),
				array(
					'fas fa-baht-sign' => 'Baht Sign (currency)',
				),
				array(
					'fas fa-bangladeshi-taka-sign' => 'Bangladeshi Taka Sign (bdt,currency,tk)',
				),
				array(
					'fab fa-bitcoin' => 'Bitcoin',
				),
				array(
					'fas fa-bitcoin-sign' => 'Bitcoin Sign (Bitcoin Sign,currency)',
				),
				array(
					'fas fa-brazilian-real-sign' => 'Brazilian Real Sign (brazilian real sign,currency)',
				),
				array(
					'fab fa-btc' => 'BTC',
				),
				array(
					'fas fa-cash-register' => 'Cash Register (buy,cha-ching,change,checkout,commerce,leaerboard,machine,pay,payment,purchase,store)',
				),
				array(
					'fas fa-cedi-sign' => 'Cedi Sign (Cedi Sign,currency)',
				),
				array(
					'fas fa-cent-sign' => 'Cent Sign (Cent Sign,currency)',
				),
				array(
					'fas fa-chart-line' => 'Chart Line (line-chart,activity,analytics,chart,dashboard,gain,graph,increase,line)',
				),
				array(
					'fas fa-chart-pie' => 'Chart Pie (pie-chart,analytics,chart,diagram,graph,pie)',
				),
				array(
					'fas fa-circle-dollar-to-slot' => 'Circle Dollar To Slot (donate,contribute,generosity,gift,give)',
				),
				array(
					'fas fa-coins' => 'Coins (currency,dime,financial,gold,money,penny)',
				),
				array(
					'fas fa-colon-sign' => 'Colon Sign (Colon Sign,currency)',
				),
				array(
					'fas fa-comment-dollar' => 'Comment Dollar (bubble,chat,commenting,conversation,feedback,message,money,note,notification,pay,sms,speech,spend,texting,transfer)',
				),
				array(
					'fas fa-comments-dollar' => 'Comments Dollar (bubble,chat,commenting,conversation,feedback,message,money,note,notification,pay,sms,speech,spend,texting,transfer)',
				),
				array(
					'fas fa-credit-card' => 'Credit Card (credit-card-alt,buy,card,checkout,credit,credit card,credit-card-alt,debit,money,payment,purchase)',
				),
				array(
					'far fa-credit-card' => 'Credit Card (credit-card-alt,buy,card,checkout,credit,credit card,credit-card-alt,debit,money,payment,purchase)',
				),
				array(
					'fas fa-cruzeiro-sign' => 'Cruzeiro Sign (Cruzeiro Sign,currency)',
				),
				array(
					'fas fa-dollar-sign' => 'Dollar Sign (dollar,usd,Dollar Sign,currency,dollar,heavy dollar sign,money)',
				),
				array(
					'fas fa-dong-sign' => 'Dong Sign (Dong Sign,currency)',
				),
				array(
					'fab fa-ethereum' => 'Ethereum',
				),
				array(
					'fas fa-euro-sign' => 'Euro Sign (eur,euro,Euro Sign,currency)',
				),
				array(
					'fas fa-file-invoice' => 'File Invoice (account,bill,charge,document,payment,receipt)',
				),
				array(
					'fas fa-file-invoice-dollar' => 'File Invoice Dollar ($,account,bill,charge,document,dollar-sign,money,payment,receipt,usd)',
				),
				array(
					'fas fa-florin-sign' => 'Florin Sign (currency)',
				),
				array(
					'fas fa-franc-sign' => 'Franc Sign (French Franc Sign,currency)',
				),
				array(
					'fab fa-gg' => 'GG Currency',
				),
				array(
					'fab fa-gg-circle' => 'GG Currency Circle',
				),
				array(
					'fas fa-guarani-sign' => 'Guarani Sign (Guarani Sign,currency)',
				),
				array(
					'fas fa-hand-holding-dollar' => 'Hand Holding Dollar (hand-holding-usd,$,carry,dollar sign,donation,giving,lift,money,price)',
				),
				array(
					'fas fa-hryvnia-sign' => 'Hryvnia Sign (hryvnia,Hryvnia Sign,currency)',
				),
				array(
					'fas fa-indian-rupee-sign' => 'Indian Rupee Sign (indian-rupee,inr,Indian Rupee Sign,currency)',
				),
				array(
					'fas fa-kip-sign' => 'Kip Sign (Kip Sign,currency)',
				),
				array(
					'fas fa-landmark' => 'Landmark (building,classical,historic,memorable,monument,museum,politics)',
				),
				array(
					'fas fa-lari-sign' => 'Lari Sign (Lari Sign,currency)',
				),
				array(
					'fas fa-lira-sign' => 'Lira Sign (Lira Sign,currency)',
				),
				array(
					'fas fa-litecoin-sign' => 'Litecoin Sign (currency)',
				),
				array(
					'fas fa-manat-sign' => 'Manat Sign (Manat Sign,currency)',
				),
				array(
					'fas fa-mill-sign' => 'Mill Sign (Mill Sign,currency)',
				),
				array(
					'fas fa-money-bill' => 'Money Bill (buy,cash,checkout,money,payment,price,purchase)',
				),
				array(
					'fas fa-money-bill-1' => 'Money Bill 1 (money-bill-alt,buy,cash,checkout,money,payment,price,purchase)',
				),
				array(
					'far fa-money-bill-1' => 'Money Bill 1 (money-bill-alt,buy,cash,checkout,money,payment,price,purchase)',
				),
				array(
					'fas fa-money-bill-1-wave' => 'Money Bill 1 Wave (money-bill-wave-alt,buy,cash,checkout,money,payment,price,purchase)',
				),
				array(
					'fas fa-money-bill-transfer' => 'Money Bill Transfer (bank,conversion,deposit,money,transfer,withdrawal)',
				),
				array(
					'fas fa-money-bill-trend-up' => 'Money Bill Trend Up (bank,bonds,inflation,market,stocks,trade)',
				),
				array(
					'fas fa-money-bill-wave' => 'Money Bill Wave (buy,cash,checkout,money,payment,price,purchase)',
				),
				array(
					'fas fa-money-bill-wheat' => 'Money Bill Wheat (agribusiness,agriculture,farming,food,livelihood,subsidy)',
				),
				array(
					'fas fa-money-bills' => 'Money Bills (atm,cash,money,moolah)',
				),
				array(
					'fas fa-money-check' => 'Money Check (bank check,buy,checkout,cheque,money,payment,price,purchase)',
				),
				array(
					'fas fa-money-check-dollar' => 'Money Check Dollar (money-check-alt,bank check,buy,checkout,cheque,money,payment,price,purchase)',
				),
				array(
					'fas fa-naira-sign' => 'Naira Sign (Naira Sign,currency)',
				),
				array(
					'fas fa-percent' => 'Percent (percentage,Percent Sign,discount,fraction,proportion,rate,ratio)',
				),
				array(
					'fas fa-peseta-sign' => 'Peseta Sign (Peseta Sign,currency)',
				),
				array(
					'fas fa-peso-sign' => 'Peso Sign (Peso Sign,currency)',
				),
				array(
					'fas fa-piggy-bank' => 'Piggy Bank (bank,save,savings)',
				),
				array(
					'fas fa-receipt' => 'Receipt (accounting,bookkeeping,check,evidence,invoice,money,pay,proof,receipt,table)',
				),
				array(
					'fas fa-ruble-sign' => 'Ruble Sign (rouble,rub,ruble,Ruble Sign,currency)',
				),
				array(
					'fas fa-rupee-sign' => 'Rupee Sign (rupee,Rupee Sign,currency)',
				),
				array(
					'fas fa-rupiah-sign' => 'Rupiah Sign (currency)',
				),
				array(
					'fas fa-sack-dollar' => 'Sack Dollar (bag,burlap,cash,dollar,money,money bag,moneybag,robber,santa,usd)',
				),
				array(
					'fas fa-sack-xmark' => 'Sack Xmark (bag,burlap,rations)',
				),
				array(
					'fas fa-scale-balanced' => 'Scale Balanced (balance-scale,Libra,balance,balance scale,balanced,justice,law,legal,measure,rule,scale,weight,zodiac)',
				),
				array(
					'fas fa-scale-unbalanced' => 'Scale Unbalanced (balance-scale-left,justice,legal,measure,unbalanced,weight)',
				),
				array(
					'fas fa-scale-unbalanced-flip' => 'Scale Unbalanced Flip (balance-scale-right,justice,legal,measure,unbalanced,weight)',
				),
				array(
					'fas fa-shekel-sign' => 'Shekel Sign (ils,shekel,sheqel,sheqel-sign,New Sheqel Sign,currency,ils,money)',
				),
				array(
					'fas fa-stamp' => 'Stamp (art,certificate,imprint,rubber,seal)',
				),
				array(
					'fas fa-sterling-sign' => 'Sterling Sign (gbp,pound-sign,Pound Sign,currency)',
				),
				array(
					'fas fa-tenge-sign' => 'Tenge Sign (tenge,Tenge Sign,currency)',
				),
				array(
					'fas fa-turkish-lira-sign' => 'Turkish Lira Sign (try,turkish-lira,Turkish Lira Sign,currency)',
				),
				array(
					'fas fa-vault' => 'Vault (bank,important,lock,money,safe)',
				),
				array(
					'fas fa-wallet' => 'Wallet (billfold,cash,currency,money)',
				),
				array(
					'fas fa-won-sign' => 'Won Sign (krw,won,Won Sign,currency)',
				),
				array(
					'fas fa-yen-sign' => 'Yen Sign (cny,jpy,rmb,yen,Yen Sign,currency)',
				),
			),
			'Moving' => array(
				array(
					'fas fa-box-archive' => 'Box Archive (archive,box,package,save,storage)',
				),
				array(
					'fas fa-box-open' => 'Box Open (archive,container,package,storage,unpack)',
				),
				array(
					'fas fa-boxes-packing' => 'Boxes Packing (archive,box,package,storage,supplies)',
				),
				array(
					'fas fa-caravan' => 'Caravan (camper,motor home,rv,trailer,travel)',
				),
				array(
					'fas fa-couch' => 'Couch (chair,cushion,furniture,relax,sofa)',
				),
				array(
					'fas fa-dolly' => 'Dolly (dolly-box,carry,shipping,transport)',
				),
				array(
					'fas fa-house-chimney' => 'House Chimney (home-lg,abode,building,chimney,house,main,residence,smokestack)',
				),
				array(
					'fas fa-people-carry-box' => 'People Carry Box (people-carry,users-people)',
				),
				array(
					'fas fa-route' => 'Route (directions,navigation,travel)',
				),
				array(
					'fas fa-sign-hanging' => 'Sign Hanging (sign,directions,real estate,signage,wayfinding)',
				),
				array(
					'fas fa-suitcase' => 'Suitcase (baggage,luggage,move,packing,suitcase,travel,trip)',
				),
				array(
					'fas fa-tape' => 'Tape (design,package,sticky)',
				),
				array(
					'fas fa-trailer' => 'Trailer (carry,haul,moving,travel)',
				),
				array(
					'fas fa-truck-moving' => 'Truck Moving (cargo,inventory,rental,vehicle)',
				),
				array(
					'fas fa-truck-ramp-box' => 'Truck Ramp Box (truck-loading,box,cargo,delivery,inventory,moving,rental,vehicle)',
				),
				array(
					'fas fa-wine-glass' => 'Wine Glass (alcohol,bar,beverage,cabernet,drink,glass,grapes,merlot,sauvignon,wine,wine glass)',
				),
			),
			'Music + Audio' => array(
				array(
					'fas fa-compact-disc' => 'Compact Disc (Optical Disc Icon,album,blu-ray,bluray,cd,computer,disc,disk,dvd,media,movie,music,optical,optical disk,record,video,vinyl)',
				),
				array(
					'fas fa-drum' => 'Drum (drum,drumsticks,instrument,music,percussion,snare,sound)',
				),
				array(
					'fas fa-drum-steelpan' => 'Drum Steelpan (calypso,instrument,music,percussion,reggae,snare,sound,steel,tropical)',
				),
				array(
					'fas fa-file-audio' => 'File Audio (document,mp3,music,page,play,sound)',
				),
				array(
					'far fa-file-audio' => 'File Audio (document,mp3,music,page,play,sound)',
				),
				array(
					'fas fa-guitar' => 'Guitar (acoustic,instrument,music,rock,rock and roll,song,strings)',
				),
				array(
					'fas fa-headphones' => 'Headphones (audio,earbud,headphone,listen,music,sound,speaker)',
				),
				array(
					'fas fa-headphones-simple' => 'Headphones Simple (headphones-alt,audio,listen,music,sound,speaker)',
				),
				array(
					'fas fa-microphone' => 'Microphone (address,audio,information,podcast,public,record,sing,sound,voice)',
				),
				array(
					'fas fa-microphone-lines' => 'Microphone Lines (microphone-alt,audio,mic,microphone,music,podcast,record,sing,sound,studio,studio microphone,voice)',
				),
				array(
					'fas fa-microphone-lines-slash' => 'Microphone Lines Slash (microphone-alt-slash,audio,disable,mute,podcast,record,sing,sound,voice)',
				),
				array(
					'fas fa-microphone-slash' => 'Microphone Slash (audio,disable,mute,podcast,record,sing,sound,voice)',
				),
				array(
					'fas fa-music' => 'Music (lyrics,melody,music,musical note,note,sing,sound)',
				),
				array(
					'fab fa-napster' => 'Napster',
				),
				array(
					'fas fa-radio' => 'Radio (am,broadcast,fm,frequency,music,news,radio,receiver,transmitter,tuner,video)',
				),
				array(
					'fas fa-record-vinyl' => 'Record Vinyl (LP,album,analog,music,phonograph,sound)',
				),
				array(
					'fas fa-sliders' => 'Sliders (sliders-h,adjust,settings,sliders,toggle)',
				),
				array(
					'fab fa-soundcloud' => 'SoundCloud',
				),
				array(
					'fab fa-spotify' => 'Spotify',
				),
				array(
					'fas fa-volume-high' => 'Volume High (volume-up,audio,higher,loud,louder,music,sound,speaker,speaker high volume)',
				),
				array(
					'fas fa-volume-low' => 'Volume Low (volume-down,audio,lower,music,quieter,soft,sound,speaker,speaker low volume)',
				),
				array(
					'fas fa-volume-off' => 'Volume Off (audio,ban,music,mute,quiet,silent,sound)',
				),
				array(
					'fas fa-volume-xmark' => 'Volume Xmark (volume-mute,volume-times,audio,music,quiet,sound,speaker)',
				),
			),
			'Nature' => array(
				array(
					'fas fa-binoculars' => 'Binoculars (glasses,magnify,scenic,spyglass,view)',
				),
				array(
					'fas fa-bug' => 'Bug (beetle,error,glitch,insect,repair,report)',
				),
				array(
					'fas fa-bugs' => 'Bugs (bedbug,infestation,lice,plague,ticks)',
				),
				array(
					'fas fa-cannabis' => 'Cannabis (bud,chronic,drugs,endica,endo,ganja,marijuana,mary jane,pot,reefer,sativa,spliff,weed,whacky-tabacky)',
				),
				array(
					'fas fa-cloud-sun' => 'Cloud Sun (clear,cloud,day,daytime,fall,outdoors,overcast,partly cloudy,sun,sun behind cloud)',
				),
				array(
					'fas fa-clover' => 'Clover (4,charm,clover,four,four leaf clover,four-leaf clover,leaf,leprechaun,luck,lucky)',
				),
				array(
					'fas fa-feather' => 'Feather (bird,feather,flight,light,plucked,plumage,quill,write)',
				),
				array(
					'fas fa-feather-pointed' => 'Feather Pointed (feather-alt,bird,light,plucked,quill,write)',
				),
				array(
					'fas fa-fire' => 'Fire (burn,caliente,fire,flame,heat,hot,popular,tool)',
				),
				array(
					'fas fa-frog' => 'Frog (amphibian,bullfrog,fauna,hop,kermit,kiss,prince,ribbit,toad,wart)',
				),
				array(
					'fas fa-icicles' => 'Icicles (cold,frozen,hanging,ice,seasonal,sharp)',
				),
				array(
					'fas fa-leaf' => 'Leaf (eco,flora,nature,plant,vegan)',
				),
				array(
					'fas fa-locust' => 'Locust (horde,infestation,locust,plague,swarm)',
				),
				array(
					'fas fa-mosquito' => 'Mosquito (bite,bug,mosquito,west nile)',
				),
				array(
					'fas fa-mound' => 'Mound (barrier,hill,pitcher,speedbump)',
				),
				array(
					'fas fa-mountain' => 'Mountain (cold,glacier,hiking,hill,landscape,mountain,snow,snow-capped mountain,travel,view)',
				),
				array(
					'fas fa-mountain-city' => 'Mountain City (location,rural,urban)',
				),
				array(
					'fas fa-mountain-sun' => 'Mountain Sun (country,hiking,landscape,rural,travel,view)',
				),
				array(
					'fas fa-person-hiking' => 'Person Hiking (hiking,autumn,fall,hike,mountain,outdoors,summer,walk)',
				),
				array(
					'fas fa-plant-wilt' => 'Plant Wilt (drought,planting,vegetation,wilt)',
				),
				array(
					'fas fa-seedling' => 'Seedling (sprout,environment,flora,grow,plant,sapling,seedling,vegan,young)',
				),
				array(
					'fas fa-signs-post' => 'Signs Post (map-signs,directions,directory,map,signage,wayfinding)',
				),
				array(
					'fas fa-spider' => 'Spider (arachnid,bug,charlotte,crawl,eight,halloween,insect,spider)',
				),
				array(
					'fas fa-tree' => 'Tree (bark,evergreen tree,fall,flora,forest,nature,plant,seasonal,tree)',
				),
				array(
					'fas fa-volcano' => 'Volcano (caldera,eruption,lava,magma,mountain,smoke,volcano)',
				),
				array(
					'fas fa-water' => 'Water (lake,liquid,ocean,sea,swim,wet)',
				),
				array(
					'fas fa-wind' => 'Wind (air,blow,breeze,fall,seasonal,weather)',
				),
				array(
					'fas fa-worm' => 'Worm (dirt,garden,worm,wriggle)',
				),
			),
			'Numbers' => array(
				array(
					'fas fa-0' => '0 (Digit Zero,nada,none,zero,zilch)',
				),
				array(
					'fas fa-1' => '1 (Digit One,one)',
				),
				array(
					'fas fa-2' => '2 (Digit Two,two)',
				),
				array(
					'fas fa-3' => '3 (Digit Three,three)',
				),
				array(
					'fas fa-4' => '4 (Digit Four,four)',
				),
				array(
					'fas fa-5' => '5 (Digit Five,five)',
				),
				array(
					'fas fa-6' => '6 (Digit Six,six)',
				),
				array(
					'fas fa-7' => '7 (Digit Seven,seven)',
				),
				array(
					'fas fa-8' => '8 (Digit Eight,eight)',
				),
				array(
					'fas fa-9' => '9 (Digit Nine,nine)',
				),
			),
			'Photos + Images' => array(
				array(
					'fas fa-bolt' => 'Bolt (zap,charge,danger,electric,electricity,flash,high voltage,lightning,voltage,weather,zap)',
				),
				array(
					'fas fa-bolt-lightning' => 'Bolt Lightning (electricity,flash,lightning,weather,zap)',
				),
				array(
					'fas fa-camera' => 'Camera (camera-alt,image,lens,photo,picture,record,shutter,video)',
				),
				array(
					'fas fa-camera-retro' => 'Camera Retro (camera,image,lens,photo,picture,record,shutter,video)',
				),
				array(
					'fas fa-camera-rotate' => 'Camera Rotate (flip,front-facing,photo,selfie)',
				),
				array(
					'fas fa-chalkboard' => 'Chalkboard (blackboard,blackboard,learning,school,teaching,whiteboard,writing)',
				),
				array(
					'fas fa-circle-half-stroke' => 'Circle Half Stroke (adjust,Circle with Left Half Black,adjust,chart,contrast,dark,fill,light,pie,progress,saturation)',
				),
				array(
					'fas fa-clone' => 'Clone (arrange,copy,duplicate,paste)',
				),
				array(
					'far fa-clone' => 'Clone (arrange,copy,duplicate,paste)',
				),
				array(
					'fas fa-droplet' => 'Droplet (tint,cold,color,comic,drop,droplet,raindrop,sweat,waterdrop)',
				),
				array(
					'fas fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'far fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'fas fa-eye-dropper' => 'Eye Dropper (eye-dropper-empty,eyedropper,beaker,clone,color,copy,eyedropper,pipette)',
				),
				array(
					'fas fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'far fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'fas fa-file-image' => 'File Image (Document with Picture,document,image,jpg,photo,png)',
				),
				array(
					'far fa-file-image' => 'File Image (Document with Picture,document,image,jpg,photo,png)',
				),
				array(
					'fas fa-film' => 'Film (cinema,film,film frames,frames,movie,strip,video)',
				),
				array(
					'fas fa-id-badge' => 'Id Badge (address,contact,identification,license,profile)',
				),
				array(
					'far fa-id-badge' => 'Id Badge (address,contact,identification,license,profile)',
				),
				array(
					'fas fa-id-card' => 'Id Card (drivers-license,contact,demographics,document,identification,issued,profile,registration)',
				),
				array(
					'far fa-id-card' => 'Id Card (drivers-license,contact,demographics,document,identification,issued,profile,registration)',
				),
				array(
					'fas fa-image' => 'Image (album,landscape,photo,picture)',
				),
				array(
					'far fa-image' => 'Image (album,landscape,photo,picture)',
				),
				array(
					'fas fa-image-portrait' => 'Image Portrait (portrait,id,image,photo,picture,selfie)',
				),
				array(
					'fas fa-images' => 'Images (album,landscape,photo,picture)',
				),
				array(
					'far fa-images' => 'Images (album,landscape,photo,picture)',
				),
				array(
					'fas fa-minimize' => 'Minimize (compress-arrows-alt,collapse,fullscreen,minimize,move,resize,shrink,smaller)',
				),
				array(
					'fas fa-panorama' => 'Panorama (image,landscape,photo,wide)',
				),
				array(
					'fas fa-photo-film' => 'Photo Film (photo-video,av,film,image,library,media)',
				),
				array(
					'fas fa-sliders' => 'Sliders (sliders-h,adjust,settings,sliders,toggle)',
				),
				array(
					'fab fa-unsplash' => 'Unsplash',
				),
			),
			'Political' => array(
				array(
					'fas fa-award' => 'Award (honor,praise,prize,recognition,ribbon,trophy)',
				),
				array(
					'fas fa-building-flag' => 'Building Flag ( city,building,diplomat,embassy,flag,headquarters,united nations)',
				),
				array(
					'fas fa-bullhorn' => 'Bullhorn (Bullhorn,announcement,broadcast,loud,louder,loudspeaker,megaphone,public address,share)',
				),
				array(
					'fas fa-check-double' => 'Check Double (accept,agree,checkmark,confirm,correct,done,notice,notification,notify,ok,select,success,tick,todo)',
				),
				array(
					'fas fa-check-to-slot' => 'Check To Slot (vote-yea,accept,cast,election,politics,positive,voting,yes)',
				),
				array(
					'fas fa-circle-dollar-to-slot' => 'Circle Dollar To Slot (donate,contribute,generosity,gift,give)',
				),
				array(
					'fas fa-democrat' => 'Democrat (american,democratic party,donkey,election,left,left-wing,liberal,politics,usa)',
				),
				array(
					'fas fa-dove' => 'Dove (bird,dove,fauna,fly,flying,peace,war)',
				),
				array(
					'fas fa-dumpster-fire' => 'Dumpster Fire (alley,bin,commercial,danger,dangerous,euphemism,flame,heat,hot,trash,waste)',
				),
				array(
					'fas fa-flag-usa' => 'Flag Usa (betsy ross,country,fla,flag: United States,old glory,stars,stripes,symbol)',
				),
				array(
					'fas fa-hand-fist' => 'Hand Fist (fist-raised,Dungeons & Dragons,clenched,d&d,dnd,fantasy,fist,hand,ki,monk,punch,raised fist,resist,strength,unarmed combat)',
				),
				array(
					'fas fa-handshake' => 'Handshake (agreement,greeting,meeting,partnership)',
				),
				array(
					'far fa-handshake' => 'Handshake (agreement,greeting,meeting,partnership)',
				),
				array(
					'fas fa-landmark-dome' => 'Landmark Dome (landmark-alt,building,historic,memorable,monument,politics)',
				),
				array(
					'fas fa-landmark-flag' => 'Landmark Flag (capitol,flag,landmark,memorial)',
				),
				array(
					'fas fa-person-booth' => 'Person Booth (changing room,curtain,vote,voting)',
				),
				array(
					'fas fa-piggy-bank' => 'Piggy Bank (bank,save,savings)',
				),
				array(
					'fas fa-republican' => 'Republican (american,conservative,election,elephant,politics,republican party,right,right-wing,usa)',
				),
				array(
					'fas fa-scale-balanced' => 'Scale Balanced (balance-scale,Libra,balance,balance scale,balanced,justice,law,legal,measure,rule,scale,weight,zodiac)',
				),
				array(
					'fas fa-scale-unbalanced' => 'Scale Unbalanced (balance-scale-left,justice,legal,measure,unbalanced,weight)',
				),
				array(
					'fas fa-scale-unbalanced-flip' => 'Scale Unbalanced Flip (balance-scale-right,justice,legal,measure,unbalanced,weight)',
				),
			),
			'Punctuation + Symbols' => array(
				array(
					'fas fa-asterisk' => 'Asterisk (Asterisk,Heavy Asterisk,annotation,details,reference,star)',
				),
				array(
					'fas fa-at' => 'At (Commercial At,address,author,e-mail,email,fluctuate,handle)',
				),
				array(
					'fas fa-check' => 'Check (Check Mark,accept,agree,check,check mark,checkmark,confirm,correct,done,mark,notice,notification,notify,ok,select,success,tick,todo,yes,✓)',
				),
				array(
					'fas fa-check-double' => 'Check Double (accept,agree,checkmark,confirm,correct,done,notice,notification,notify,ok,select,success,tick,todo)',
				),
				array(
					'fas fa-circle-exclamation' => 'Circle Exclamation (exclamation-circle,affect,alert,damage,danger,error,important,notice,notification,notify,problem,warning)',
				),
				array(
					'fas fa-circle-question' => 'Circle Question (question-circle,help,information,support,unknown)',
				),
				array(
					'far fa-circle-question' => 'Circle Question (question-circle,help,information,support,unknown)',
				),
				array(
					'fas fa-equals' => 'Equals (Equals Sign,arithmetic,even,match,math)',
				),
				array(
					'fas fa-exclamation' => 'Exclamation (!,Exclamation Mark,alert,danger,error,exclamation,important,mark,notice,notification,notify,outlined,problem,punctuation,red exclamation mark,warning,white exclamation mark)',
				),
				array(
					'fas fa-greater-than' => 'Greater Than (Greater-Than Sign,arithmetic,compare,math)',
				),
				array(
					'fas fa-hashtag' => 'Hashtag (Number Sign,Twitter,instagram,pound,social media,tag)',
				),
				array(
					'fas fa-less-than' => 'Less Than (Less-Than Sign,arithmetic,compare,math)',
				),
				array(
					'fas fa-minus' => 'Minus (subtract,En Dash,Minus Sign,collapse,delete,hide,math,minify,minus,negative,remove,sign,trash,−)',
				),
				array(
					'fas fa-percent' => 'Percent (percentage,Percent Sign,discount,fraction,proportion,rate,ratio)',
				),
				array(
					'fas fa-plus' => 'Plus (add,+,Plus Sign,add,create,expand,math,new,plus,positive,shape,sign)',
				),
				array(
					'fas fa-question' => 'Question (?,Question Mark,help,information,mark,outlined,punctuation,question,red question mark,support,unknown,white question mark)',
				),
				array(
					'fas fa-quote-left' => 'Quote Left (quote-left-alt,Left Double Quotation Mark,mention,note,phrase,text,type)',
				),
				array(
					'fas fa-quote-right' => 'Quote Right (quote-right-alt,Right Double Quotation Mark,mention,note,phrase,text,type)',
				),
				array(
					'fas fa-section' => 'Section (Section Sign,law,legal,silcrow)',
				),
			),
			'Religion' => array(
				array(
					'fas fa-ankh' => 'Ankh (Ankh,amulet,copper,coptic christianity,copts,crux ansata,egypt,venus)',
				),
				array(
					'fas fa-atom' => 'Atom (atheism,atheist,atom,atom symbol,chemistry,electron,ion,isotope,neutron,nuclear,proton,science)',
				),
				array(
					'fas fa-bahai' => 'Bahai (haykal,bahai,bahá\'í,star)',
				),
				array(
					'fas fa-book-bible' => 'Book Bible (bible,book,catholicism,christianity,god,holy)',
				),
				array(
					'fas fa-book-journal-whills' => 'Book Journal Whills (journal-whills,book,force,jedi,sith,star wars,yoda)',
				),
				array(
					'fas fa-book-quran' => 'Book Quran (quran,book,islam,muslim,religion)',
				),
				array(
					'fas fa-book-tanakh' => 'Book Tanakh (tanakh,book,jewish,judaism,religion)',
				),
				array(
					'fas fa-church' => 'Church (Christian,building,cathedral,chapel,church,community,cross,religion)',
				),
				array(
					'fas fa-cross' => 'Cross (Christian,Heavy Latin Cross,catholicism,christianity,church,cross,jesus,latin cross,religion)',
				),
				array(
					'fas fa-dharmachakra' => 'Dharmachakra (Buddhist,buddhism,buddhist,dharma,religion,wheel,wheel of dharma)',
				),
				array(
					'fas fa-dove' => 'Dove (bird,dove,fauna,fly,flying,peace,war)',
				),
				array(
					'fas fa-gopuram' => 'Gopuram (building,entrance,hinduism,temple,tower)',
				),
				array(
					'fas fa-hamsa' => 'Hamsa (amulet,christianity,islam,jewish,judaism,muslim,protection)',
				),
				array(
					'fas fa-hands-praying' => 'Hands Praying (praying-hands,kneel,preach,religion,worship)',
				),
				array(
					'fas fa-hanukiah' => 'Hanukiah (candelabrum,candle,candlestick,hanukkah,jewish,judaism,light,menorah,religion)',
				),
				array(
					'fas fa-jedi' => 'Jedi (crest,force,sith,skywalker,star wars,yoda)',
				),
				array(
					'fas fa-kaaba' => 'Kaaba (Muslim,building,cube,islam,kaaba,muslim,religion)',
				),
				array(
					'fas fa-khanda' => 'Khanda (Adi Shakti,chakkar,sikh,sikhism,sword)',
				),
				array(
					'fas fa-menorah' => 'Menorah (candle,hanukkah,jewish,judaism,light)',
				),
				array(
					'fas fa-mosque' => 'Mosque (Muslim,building,islam,landmark,mosque,muslim,religion)',
				),
				array(
					'fas fa-om' => 'Om (Hindu,buddhism,hinduism,jainism,mantra,om,religion)',
				),
				array(
					'fas fa-peace' => 'Peace (peace,peace symbol,serenity,tranquility,truce,war)',
				),
				array(
					'fas fa-person-praying' => 'Person Praying (pray,kneel,place of worship,religion,thank,worship)',
				),
				array(
					'fas fa-place-of-worship' => 'Place Of Worship (building,church,holy,mosque,synagogue)',
				),
				array(
					'fas fa-scroll-torah' => 'Scroll Torah (torah,book,jewish,judaism,religion,scroll)',
				),
				array(
					'fas fa-spaghetti-monster-flying' => 'Spaghetti Monster Flying (pastafarianism,agnosticism,atheism,flying spaghetti monster,fsm)',
				),
				array(
					'fas fa-star-and-crescent' => 'Star And Crescent (Muslim,islam,muslim,religion,star and crescent)',
				),
				array(
					'fas fa-star-of-david' => 'Star Of David (David,Jew,Jewish,jewish,judaism,religion,star,star of David)',
				),
				array(
					'fas fa-synagogue' => 'Synagogue (Jew,Jewish,building,jewish,judaism,religion,star of david,synagogue,temple)',
				),
				array(
					'fas fa-torii-gate' => 'Torii Gate (building,religion,shinto,shinto shrine,shintoism,shrine)',
				),
				array(
					'fas fa-vihara' => 'Vihara (buddhism,buddhist,building,monastery)',
				),
				array(
					'fas fa-yin-yang' => 'Yin Yang (daoism,opposites,religion,tao,taoism,taoist,yang,yin,yin yang)',
				),
			),
			'Science' => array(
				array(
					'fas fa-atom' => 'Atom (atheism,atheist,atom,atom symbol,chemistry,electron,ion,isotope,neutron,nuclear,proton,science)',
				),
				array(
					'fas fa-biohazard' => 'Biohazard (biohazard,covid-19,danger,dangerous,epidemic,hazmat,medical,pandemic,radioactive,sign,toxic,waste,zombie)',
				),
				array(
					'fas fa-brain' => 'Brain (brain,cerebellum,gray matter,intellect,intelligent,medulla oblongata,mind,noodle,wit)',
				),
				array(
					'fas fa-capsules' => 'Capsules (drugs,medicine,pills,prescription)',
				),
				array(
					'fas fa-circle-radiation' => 'Circle Radiation (radiation-alt,danger,dangerous,deadly,hazard,nuclear,radioactive,sign,warning)',
				),
				array(
					'fas fa-clipboard-check' => 'Clipboard Check (accept,agree,confirm,done,ok,select,success,tick,todo,yes)',
				),
				array(
					'fas fa-disease' => 'Disease (bacteria,cancer,coronavirus,covid-19,flu,illness,infection,pandemic,sickness,virus)',
				),
				array(
					'fas fa-dna' => 'Dna (biologist,dna,double helix,evolution,gene,genetic,genetics,helix,life,molecule,protein)',
				),
				array(
					'fas fa-eye-dropper' => 'Eye Dropper (eye-dropper-empty,eyedropper,beaker,clone,color,copy,eyedropper,pipette)',
				),
				array(
					'fas fa-filter' => 'Filter (funnel,options,separate,sort)',
				),
				array(
					'fas fa-fire' => 'Fire (burn,caliente,fire,flame,heat,hot,popular,tool)',
				),
				array(
					'fas fa-fire-flame-curved' => 'Fire Flame Curved (fire-alt,burn,caliente,flame,heat,hot,popular)',
				),
				array(
					'fas fa-fire-flame-simple' => 'Fire Flame Simple (burn,caliente,energy,fire,flame,gas,heat,hot)',
				),
				array(
					'fas fa-flask' => 'Flask (beaker,chemicals,experiment,experimental,labs,liquid,potion,science,vial)',
				),
				array(
					'fas fa-flask-vial' => 'Flask Vial ( beaker, chemicals, experiment, experimental, labs, liquid, science, vial,ampule,chemistry,lab,laboratory,potion,test,test tube)',
				),
				array(
					'fas fa-frog' => 'Frog (amphibian,bullfrog,fauna,hop,kermit,kiss,prince,ribbit,toad,wart)',
				),
				array(
					'fas fa-magnet' => 'Magnet (Attract,attraction,horseshoe,lodestone,magnet,magnetic,tool)',
				),
				array(
					'fas fa-microscope' => 'Microscope (covid-19,electron,lens,microscope,optics,science,shrink,testing,tool)',
				),
				array(
					'fas fa-mortar-pestle' => 'Mortar Pestle (crush,culinary,grind,medical,mix,pharmacy,prescription,spices)',
				),
				array(
					'fas fa-pills' => 'Pills (drugs,medicine,prescription,tablets)',
				),
				array(
					'fas fa-prescription-bottle' => 'Prescription Bottle (drugs,medical,medicine,pharmacy,rx)',
				),
				array(
					'fas fa-radiation' => 'Radiation (danger,dangerous,deadly,hazard,nuclear,radioactive,warning)',
				),
				array(
					'fas fa-seedling' => 'Seedling (sprout,environment,flora,grow,plant,sapling,seedling,vegan,young)',
				),
				array(
					'fas fa-skull-crossbones' => 'Skull Crossbones (Black Skull and Crossbones,Dungeons & Dragons,alert,bones,crossbones,d&d,danger,dangerous area,dead,deadly,death,dnd,face,fantasy,halloween,holiday,jolly-roger,monster,pirate,poison,skeleton,skull,skull and crossbones,warning)',
				),
				array(
					'fas fa-square-virus' => 'Square Virus (coronavirus,covid-19,disease,flu,infection,pandemic)',
				),
				array(
					'fas fa-syringe' => 'Syringe (covid-19,doctor,immunizations,medical,medicine,needle,shot,sick,syringe,vaccinate,vaccine)',
				),
				array(
					'fas fa-tablets' => 'Tablets (drugs,medicine,pills,prescription)',
				),
				array(
					'fas fa-temperature-high' => 'Temperature High (cook,covid-19,mercury,summer,thermometer,warm)',
				),
				array(
					'fas fa-temperature-low' => 'Temperature Low (cold,cool,covid-19,mercury,thermometer,winter)',
				),
				array(
					'fas fa-vial' => 'Vial (ampule,chemist,chemistry,experiment,lab,sample,science,test,test tube)',
				),
				array(
					'fas fa-vial-circle-check' => 'Vial Circle Check (ampule,chemist,chemistry,not affected,ok,okay,success,test tube,tube,vaccine)',
				),
				array(
					'fas fa-vial-virus' => 'Vial Virus (ampule,coronavirus,covid-19,flue,infection,lab,laboratory,pandemic,test,test tube,vaccine)',
				),
				array(
					'fas fa-vials' => 'Vials (ampule,experiment,lab,sample,science,test,test tube)',
				),
			),
			'Science Fiction' => array(
				array(
					'fas fa-atom' => 'Atom (atheism,atheist,atom,atom symbol,chemistry,electron,ion,isotope,neutron,nuclear,proton,science)',
				),
				array(
					'fas fa-book-journal-whills' => 'Book Journal Whills (journal-whills,book,force,jedi,sith,star wars,yoda)',
				),
				array(
					'fas fa-explosion' => 'Explosion (blast,blowup,boom,crash,detonation,explosion)',
				),
				array(
					'fab fa-galactic-republic' => 'Galactic Republic (politics,star wars)',
				),
				array(
					'fab fa-galactic-senate' => 'Galactic Senate (star wars)',
				),
				array(
					'fas fa-hand-spock' => 'Hand Spock (finger,hand,live long,palm,prosper,salute,spock,star trek,vulcan,vulcan salute)',
				),
				array(
					'far fa-hand-spock' => 'Hand Spock (finger,hand,live long,palm,prosper,salute,spock,star trek,vulcan,vulcan salute)',
				),
				array(
					'fas fa-jedi' => 'Jedi (crest,force,sith,skywalker,star wars,yoda)',
				),
				array(
					'fab fa-jedi-order' => 'Jedi Order (star wars)',
				),
				array(
					'fab fa-old-republic' => 'Old Republic (politics,star wars)',
				),
				array(
					'fas fa-robot' => 'Robot (android,automate,computer,cyborg,face,monster,robot)',
				),
				array(
					'fas fa-rocket' => 'Rocket (aircraft,app,jet,launch,nasa,space)',
				),
				array(
					'fab fa-space-awesome' => 'Space Awesome (adventure,rocket,ship,shuttle)',
				),
				array(
					'fas fa-user-astronaut' => 'User Astronaut (avatar,clothing,cosmonaut,nasa,space,suit)',
				),
			),
			'Security' => array(
				array(
					'fas fa-ban' => 'Ban (cancel,abort,ban,block,cancel,delete,entry,forbidden,hide,no,not,prohibit,prohibited,remove,stop,trash)',
				),
				array(
					'fas fa-bug' => 'Bug (beetle,error,glitch,insect,repair,report)',
				),
				array(
					'fas fa-bug-slash' => 'Bug Slash (beetle,fix,glitch,insect,optimize,repair,report,warning)',
				),
				array(
					'fas fa-building-lock' => 'Building Lock (building,city,closed,lock,lockdown,quarantine,secure)',
				),
				array(
					'fas fa-building-shield' => 'Building Shield (building,city,police,protect,safety)',
				),
				array(
					'fas fa-burst' => 'Burst (boom,crash,explosion)',
				),
				array(
					'fas fa-car-on' => 'Car On (alarm,car,carjack,warning)',
				),
				array(
					'fas fa-door-closed' => 'Door Closed (doo,door,enter,exit,locked)',
				),
				array(
					'fas fa-door-open' => 'Door Open (enter,exit,welcome)',
				),
				array(
					'fas fa-dungeon' => 'Dungeon (Dungeons & Dragons,building,d&d,dnd,door,entrance,fantasy,gate)',
				),
				array(
					'fas fa-explosion' => 'Explosion (blast,blowup,boom,crash,detonation,explosion)',
				),
				array(
					'fas fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'far fa-eye' => 'Eye (body,eye,look,optic,see,seen,show,sight,views,visible)',
				),
				array(
					'fas fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'far fa-eye-slash' => 'Eye Slash (blind,hide,show,toggle,unseen,views,visible,visiblity)',
				),
				array(
					'fas fa-file-contract' => 'File Contract (agreement,binding,document,legal,signature)',
				),
				array(
					'fas fa-file-shield' => 'File Shield (antivirus,data,document,protect,safe,safety,secure)',
				),
				array(
					'fas fa-file-signature' => 'File Signature (John Hancock,contract,document,name)',
				),
				array(
					'fas fa-fingerprint' => 'Fingerprint (human,id,identification,lock,smudge,touch,unique,unlock)',
				),
				array(
					'fas fa-gun' => 'Gun (firearm,pistol,weapon)',
				),
				array(
					'fas fa-handcuffs' => 'Handcuffs (arrest,criminal,handcuffs,jail,lock,police,wrist)',
				),
				array(
					'fas fa-hands-bound' => 'Hands Bound (abduction,bound,handcuff,wrist)',
				),
				array(
					'fas fa-hands-holding-child' => 'Hands Holding Child (care,give,help,hold,protect)',
				),
				array(
					'fas fa-hands-holding-circle' => 'Hands Holding Circle (circle,gift,protection)',
				),
				array(
					'fas fa-house-fire' => 'House Fire (burn,emergency,home)',
				),
				array(
					'fas fa-house-lock' => 'House Lock (closed,home,house,lockdown,quarantine)',
				),
				array(
					'fas fa-id-badge' => 'Id Badge (address,contact,identification,license,profile)',
				),
				array(
					'far fa-id-badge' => 'Id Badge (address,contact,identification,license,profile)',
				),
				array(
					'fas fa-id-card' => 'Id Card (drivers-license,contact,demographics,document,identification,issued,profile,registration)',
				),
				array(
					'far fa-id-card' => 'Id Card (drivers-license,contact,demographics,document,identification,issued,profile,registration)',
				),
				array(
					'fas fa-id-card-clip' => 'Id Card Clip (id-card-alt,contact,demographics,document,identification,issued,profile)',
				),
				array(
					'fas fa-key' => 'Key (key,lock,password,private,secret,unlock)',
				),
				array(
					'fas fa-land-mine-on' => 'Land Mine On (bomb,danger,explosion,war)',
				),
				array(
					'fas fa-lock' => 'Lock (admin,closed,lock,locked,open,password,private,protect,security)',
				),
				array(
					'fas fa-lock-open' => 'Lock Open (admin,lock,open,password,private,protect,security,unlock)',
				),
				array(
					'fas fa-mars-and-venus-burst' => 'Mars And Venus Burst (gender,violence)',
				),
				array(
					'fas fa-mask' => 'Mask (carnivale,costume,disguise,halloween,secret,super hero)',
				),
				array(
					'fas fa-passport' => 'Passport (document,id,identification,issued,travel)',
				),
				array(
					'fas fa-people-pulling' => 'People Pulling (forced return,yanking)',
				),
				array(
					'fas fa-people-robbery' => 'People Robbery (criminal,hands up,looting,robbery,steal)',
				),
				array(
					'fas fa-person-burst' => 'Person Burst (abuse,accident,crash,explode,violence)',
				),
				array(
					'fas fa-person-dress-burst' => 'Person Dress Burst (abuse,accident,crash,explode,violence)',
				),
				array(
					'fas fa-person-falling-burst' => 'Person Falling Burst (accident,crash,death,fall,homicide,murder)',
				),
				array(
					'fas fa-person-harassing' => 'Person Harassing (abuse,scream,shame,shout,yell)',
				),
				array(
					'fas fa-person-military-pointing' => 'Person Military Pointing (army,customs,guard)',
				),
				array(
					'fas fa-person-military-rifle' => 'Person Military Rifle (armed forces,army,military,rifle,war)',
				),
				array(
					'fas fa-person-military-to-person' => 'Person Military To Person (civilian,coordination,military)',
				),
				array(
					'fas fa-person-rifle' => 'Person Rifle (army,combatant,gun,military,rifle,war)',
				),
				array(
					'fas fa-person-shelter' => 'Person Shelter (house,inside,roof,safe,safety,shelter)',
				),
				array(
					'fas fa-person-through-window' => 'Person Through Window (door,exit,forced entry,leave,robbery,steal,window)',
				),
				array(
					'fas fa-road-spikes' => 'Road Spikes (barrier,roadblock,spikes)',
				),
				array(
					'fas fa-shield' => 'Shield (shield-blank,achievement,armor,award,block,cleric,defend,defense,holy,paladin,protect,safety,security,shield,weapon,winner)',
				),
				array(
					'fas fa-shield-cat' => 'Shield Cat (animal,feline,pet,protect,safety,veterinary)',
				),
				array(
					'fas fa-shield-dog' => 'Shield Dog (animal,canine,pet,protect,safety,veterinary)',
				),
				array(
					'fas fa-shield-halved' => 'Shield Halved (shield-alt,achievement,armor,award,block,cleric,defend,defense,holy,paladin,security,shield,weapon,winner)',
				),
				array(
					'fas fa-shield-heart' => 'Shield Heart (love,protect,safe,safety,shield)',
				),
				array(
					'fas fa-skull-crossbones' => 'Skull Crossbones (Black Skull and Crossbones,Dungeons & Dragons,alert,bones,crossbones,d&d,danger,dangerous area,dead,deadly,death,dnd,face,fantasy,halloween,holiday,jolly-roger,monster,pirate,poison,skeleton,skull,skull and crossbones,warning)',
				),
				array(
					'fas fa-square-person-confined' => 'Square Person Confined (captivity,confined)',
				),
				array(
					'fas fa-tower-observation' => 'Tower Observation (fire tower,view)',
				),
				array(
					'fas fa-unlock' => 'Unlock (admin,lock,open,password,private,protect,unlock,unlocked)',
				),
				array(
					'fas fa-unlock-keyhole' => 'Unlock Keyhole (unlock-alt,admin,lock,password,private,protect)',
				),
				array(
					'fas fa-user-lock' => 'User Lock (users-people)',
				),
				array(
					'fas fa-user-secret' => 'User Secret (detective,sleuth,spy,users-people)',
				),
				array(
					'fas fa-user-shield' => 'User Shield (protect,safety)',
				),
				array(
					'fas fa-vault' => 'Vault (bank,important,lock,money,safe)',
				),
			),
			'Shapes' => array(
				array(
					'fas fa-bookmark' => 'Bookmark (bookmark,favorite,library,mark,marker,read,remember,research,save)',
				),
				array(
					'far fa-bookmark' => 'Bookmark (bookmark,favorite,library,mark,marker,read,remember,research,save)',
				),
				array(
					'fas fa-burst' => 'Burst (boom,crash,explosion)',
				),
				array(
					'fas fa-calendar' => 'Calendar (calendar,calendar-o,date,day,event,month,schedule,tear-off calendar,time,when,year)',
				),
				array(
					'far fa-calendar' => 'Calendar (calendar,calendar-o,date,day,event,month,schedule,tear-off calendar,time,when,year)',
				),
				array(
					'fas fa-certificate' => 'Certificate (badge,star,verified)',
				),
				array(
					'fas fa-circle' => 'Circle (Black Circle,Black Large Circle,black circle,blue,blue circle,brown,brown circle,chart,circle,circle-thin,diameter,dot,ellipse,fill,geometric,green,green circle,notification,orange,orange circle,progress,purple,purple circle,red,red circle,round,white circle,yellow,yellow circle)',
				),
				array(
					'far fa-circle' => 'Circle (Black Circle,Black Large Circle,black circle,blue,blue circle,brown,brown circle,chart,circle,circle-thin,diameter,dot,ellipse,fill,geometric,green,green circle,notification,orange,orange circle,progress,purple,purple circle,red,red circle,round,white circle,yellow,yellow circle)',
				),
				array(
					'fas fa-circle-half-stroke' => 'Circle Half Stroke (adjust,Circle with Left Half Black,adjust,chart,contrast,dark,fill,light,pie,progress,saturation)',
				),
				array(
					'fas fa-cloud' => 'Cloud (atmosphere,cloud,fog,overcast,save,upload,weather)',
				),
				array(
					'fas fa-clover' => 'Clover (4,charm,clover,four,four leaf clover,four-leaf clover,leaf,leprechaun,luck,lucky)',
				),
				array(
					'fas fa-comment' => 'Comment (Right Speech Bubble,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'far fa-comment' => 'Comment (Right Speech Bubble,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'fas fa-crown' => 'Crown (award,clothing,crown,favorite,king,queen,royal,tiara)',
				),
				array(
					'fas fa-cubes-stacked' => 'Cubes Stacked (blocks,cubes,sugar)',
				),
				array(
					'fas fa-diamond' => 'Diamond (card,cards,diamond suit,game,gem,gemstone,poker,suit)',
				),
				array(
					'fas fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'far fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'fas fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'far fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fas fa-heart-crack' => 'Heart Crack (heart-broken,break,breakup,broken,broken heart,crushed,dislike,dumped,grief,love,lovesick,relationship,sad)',
				),
				array(
					'fas fa-lines-leaning' => 'Lines Leaning (canted,domino,falling,resilience,resilient,tipped)',
				),
				array(
					'fas fa-location-pin' => 'Location Pin (map-marker,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-play' => 'Play (arrow,audio,music,play,play button,playing,right,sound,start,triangle,video)',
				),
				array(
					'fas fa-shapes' => 'Shapes (triangle-circle-square,blocks,build,circle,square,triangle)',
				),
				array(
					'fas fa-shield' => 'Shield (shield-blank,achievement,armor,award,block,cleric,defend,defense,holy,paladin,protect,safety,security,shield,weapon,winner)',
				),
				array(
					'fas fa-square' => 'Square (Black Square,black medium square,block,box,geometric,shape,square,white medium square)',
				),
				array(
					'far fa-square' => 'Square (Black Square,black medium square,block,box,geometric,shape,square,white medium square)',
				),
				array(
					'fas fa-star' => 'Star (achievement,award,favorite,important,night,rating,score,star)',
				),
				array(
					'far fa-star' => 'Star (achievement,award,favorite,important,night,rating,score,star)',
				),
				array(
					'fas fa-ticket-simple' => 'Ticket Simple (ticket-alt,movie,pass,support,ticket)',
				),
			),
			'Shopping' => array(
				array(
					'fab fa-alipay' => 'Alipay',
				),
				array(
					'fab fa-amazon-pay' => 'Amazon Pay',
				),
				array(
					'fab fa-apple-pay' => 'Apple Pay',
				),
				array(
					'fas fa-bag-shopping' => 'Bag Shopping (shopping-bag,buy,checkout,grocery,payment,purchase)',
				),
				array(
					'fas fa-barcode' => 'Barcode (info,laser,price,scan,upc)',
				),
				array(
					'fas fa-basket-shopping' => 'Basket Shopping (shopping-basket,buy,checkout,grocery,payment,purchase)',
				),
				array(
					'fas fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'far fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'fab fa-bitcoin' => 'Bitcoin',
				),
				array(
					'fas fa-bookmark' => 'Bookmark (bookmark,favorite,library,mark,marker,read,remember,research,save)',
				),
				array(
					'far fa-bookmark' => 'Bookmark (bookmark,favorite,library,mark,marker,read,remember,research,save)',
				),
				array(
					'fab fa-btc' => 'BTC',
				),
				array(
					'fas fa-bullhorn' => 'Bullhorn (Bullhorn,announcement,broadcast,loud,louder,loudspeaker,megaphone,public address,share)',
				),
				array(
					'fas fa-camera' => 'Camera (camera-alt,image,lens,photo,picture,record,shutter,video)',
				),
				array(
					'fas fa-camera-retro' => 'Camera Retro (camera,image,lens,photo,picture,record,shutter,video)',
				),
				array(
					'fas fa-cart-arrow-down' => 'Cart Arrow Down (download,save,shopping)',
				),
				array(
					'fas fa-cart-plus' => 'Cart Plus (add,create,new,positive,shopping)',
				),
				array(
					'fas fa-cart-shopping' => 'Cart Shopping (shopping-cart,buy,cart,checkout,grocery,payment,purchase,shopping,shopping cart,trolley)',
				),
				array(
					'fas fa-cash-register' => 'Cash Register (buy,cha-ching,change,checkout,commerce,leaerboard,machine,pay,payment,purchase,store)',
				),
				array(
					'fab fa-cc-amazon-pay' => 'Amazon Pay Credit Card',
				),
				array(
					'fab fa-cc-amex' => 'American Express Credit Card (amex)',
				),
				array(
					'fab fa-cc-apple-pay' => 'Apple Pay Credit Card',
				),
				array(
					'fab fa-cc-diners-club' => 'Diner\'s Club Credit Card',
				),
				array(
					'fab fa-cc-discover' => 'Discover Credit Card',
				),
				array(
					'fab fa-cc-jcb' => 'JCB Credit Card',
				),
				array(
					'fab fa-cc-mastercard' => 'MasterCard Credit Card',
				),
				array(
					'fab fa-cc-paypal' => 'Paypal Credit Card',
				),
				array(
					'fab fa-cc-stripe' => 'Stripe Credit Card',
				),
				array(
					'fab fa-cc-visa' => 'Visa Credit Card',
				),
				array(
					'fas fa-certificate' => 'Certificate (badge,star,verified)',
				),
				array(
					'fas fa-credit-card' => 'Credit Card (credit-card-alt,buy,card,checkout,credit,credit card,credit-card-alt,debit,money,payment,purchase)',
				),
				array(
					'far fa-credit-card' => 'Credit Card (credit-card-alt,buy,card,checkout,credit,credit card,credit-card-alt,debit,money,payment,purchase)',
				),
				array(
					'fab fa-ethereum' => 'Ethereum',
				),
				array(
					'fas fa-gem' => 'Gem (diamond,gem,gem stone,jewel,jewelry,sapphire,stone,treasure)',
				),
				array(
					'far fa-gem' => 'Gem (diamond,gem,gem stone,jewel,jewelry,sapphire,stone,treasure)',
				),
				array(
					'fas fa-gift' => 'Gift (box,celebration,christmas,generosity,gift,giving,holiday,party,present,wrapped,wrapped gift,xmas)',
				),
				array(
					'fas fa-gifts' => 'Gifts (christmas,generosity,giving,holiday,party,present,wrapped,xmas)',
				),
				array(
					'fab fa-google-pay' => 'Google Pay',
				),
				array(
					'fab fa-google-wallet' => 'Google Wallet',
				),
				array(
					'fas fa-handshake' => 'Handshake (agreement,greeting,meeting,partnership)',
				),
				array(
					'far fa-handshake' => 'Handshake (agreement,greeting,meeting,partnership)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fas fa-key' => 'Key (key,lock,password,private,secret,unlock)',
				),
				array(
					'fas fa-money-check' => 'Money Check (bank check,buy,checkout,cheque,money,payment,price,purchase)',
				),
				array(
					'fas fa-money-check-dollar' => 'Money Check Dollar (money-check-alt,bank check,buy,checkout,cheque,money,payment,price,purchase)',
				),
				array(
					'fab fa-nfc-directional' => 'NFC Directional (connect,data,near field communication,nfc,scan,signal,transfer,wireless)',
				),
				array(
					'fab fa-nfc-symbol' => 'Nfc Symbol (connect,data,near field communication,nfc,scan,signal,transfer,wireless)',
				),
				array(
					'fab fa-paypal' => 'Paypal',
				),
				array(
					'fas fa-person-booth' => 'Person Booth (changing room,curtain,vote,voting)',
				),
				array(
					'fas fa-receipt' => 'Receipt (accounting,bookkeeping,check,evidence,invoice,money,pay,proof,receipt,table)',
				),
				array(
					'fas fa-shirt' => 'Shirt (t-shirt,tshirt,clothing,fashion,garment,shirt,short sleeve,t-shirt,tshirt)',
				),
				array(
					'fas fa-shop' => 'Shop (store-alt,bodega,building,buy,market,purchase,shopping,store)',
				),
				array(
					'fas fa-shop-lock' => 'Shop Lock (bodega,building,buy,closed,lock,lockdown,market,purchase,quarantine,shop,shopping,store)',
				),
				array(
					'fas fa-shop-slash' => 'Shop Slash (store-alt-slash,building,buy,closed,covid-19,purchase,shopping)',
				),
				array(
					'fas fa-star' => 'Star (achievement,award,favorite,important,night,rating,score,star)',
				),
				array(
					'far fa-star' => 'Star (achievement,award,favorite,important,night,rating,score,star)',
				),
				array(
					'fas fa-store' => 'Store (bodega,building,buy,market,purchase,shopping,store)',
				),
				array(
					'fas fa-store-slash' => 'Store Slash (building,buy,closed,covid-19,purchase,shopping)',
				),
				array(
					'fab fa-stripe' => 'Stripe',
				),
				array(
					'fab fa-stripe-s' => 'Stripe S',
				),
				array(
					'fas fa-tag' => 'Tag (discount,labe,label,price,shopping)',
				),
				array(
					'fas fa-tags' => 'Tags (discount,label,price,shopping)',
				),
				array(
					'fas fa-thumbs-down' => 'Thumbs Down (-1,disagree,disapprove,dislike,down,hand,social,thumb,thumbs down,thumbs-o-down)',
				),
				array(
					'far fa-thumbs-down' => 'Thumbs Down (-1,disagree,disapprove,dislike,down,hand,social,thumb,thumbs down,thumbs-o-down)',
				),
				array(
					'fas fa-thumbs-up' => 'Thumbs Up (+1,agree,approve,favorite,hand,like,ok,okay,social,success,thumb,thumbs up,thumbs-o-up,up,yes,you got it dude)',
				),
				array(
					'far fa-thumbs-up' => 'Thumbs Up (+1,agree,approve,favorite,hand,like,ok,okay,social,success,thumb,thumbs up,thumbs-o-up,up,yes,you got it dude)',
				),
				array(
					'fas fa-trophy' => 'Trophy (achievement,award,cup,game,prize,trophy,winner)',
				),
				array(
					'fas fa-truck' => 'Truck (Black Truck,cargo,delivery,delivery truck,shipping,truck,vehicle)',
				),
				array(
					'fas fa-truck-fast' => 'Truck Fast (shipping-fast,express,fedex,mail,overnight,package,ups)',
				),
			),
			'Social' => array(
				array(
					'fas fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'far fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'fas fa-cake-candles' => 'Cake Candles (birthday-cake,cake,anniversary,bakery,birthday,birthday cake,cake,candles,celebration,dessert,frosting,holiday,party,pastry,sweet)',
				),
				array(
					'fas fa-camera' => 'Camera (camera-alt,image,lens,photo,picture,record,shutter,video)',
				),
				array(
					'fas fa-circle-user' => 'Circle User (user-circle,users-people)',
				),
				array(
					'far fa-circle-user' => 'Circle User (user-circle,users-people)',
				),
				array(
					'fas fa-comment' => 'Comment (Right Speech Bubble,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'far fa-comment' => 'Comment (Right Speech Bubble,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'fas fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'far fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-hashtag' => 'Hashtag (Number Sign,Twitter,instagram,pound,social media,tag)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fas fa-icons' => 'Icons (heart-music-camera-bolt,bolt,emoji,heart,image,music,photo,symbols)',
				),
				array(
					'fas fa-image' => 'Image (album,landscape,photo,picture)',
				),
				array(
					'far fa-image' => 'Image (album,landscape,photo,picture)',
				),
				array(
					'fas fa-images' => 'Images (album,landscape,photo,picture)',
				),
				array(
					'far fa-images' => 'Images (album,landscape,photo,picture)',
				),
				array(
					'fas fa-location-dot' => 'Location Dot (map-marker-alt,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-location-pin' => 'Location Pin (map-marker,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-message' => 'Message (comment-alt,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'far fa-message' => 'Message (comment-alt,bubble,chat,commenting,conversation,feedback,message,note,notification,sms,speech,texting)',
				),
				array(
					'fas fa-photo-film' => 'Photo Film (photo-video,av,film,image,library,media)',
				),
				array(
					'fas fa-retweet' => 'Retweet (refresh,reload,share,swap)',
				),
				array(
					'fas fa-share' => 'Share (arrow-turn-right,mail-forward,forward,save,send,social)',
				),
				array(
					'fas fa-share-from-square' => 'Share From Square (share-square,forward,save,send,social)',
				),
				array(
					'far fa-share-from-square' => 'Share From Square (share-square,forward,save,send,social)',
				),
				array(
					'fas fa-share-nodes' => 'Share Nodes (share-alt,forward,save,send,social)',
				),
				array(
					'fas fa-square-poll-horizontal' => 'Square Poll Horizontal (poll-h,chart,graph,results,survey,trend,vote,voting)',
				),
				array(
					'fas fa-square-poll-vertical' => 'Square Poll Vertical (poll,chart,graph,results,survey,trend,vote,voting)',
				),
				array(
					'fas fa-square-share-nodes' => 'Square Share Nodes (share-alt-square,forward,save,send,social)',
				),
				array(
					'fas fa-star' => 'Star (achievement,award,favorite,important,night,rating,score,star)',
				),
				array(
					'far fa-star' => 'Star (achievement,award,favorite,important,night,rating,score,star)',
				),
				array(
					'fas fa-thumbs-down' => 'Thumbs Down (-1,disagree,disapprove,dislike,down,hand,social,thumb,thumbs down,thumbs-o-down)',
				),
				array(
					'far fa-thumbs-down' => 'Thumbs Down (-1,disagree,disapprove,dislike,down,hand,social,thumb,thumbs down,thumbs-o-down)',
				),
				array(
					'fas fa-thumbs-up' => 'Thumbs Up (+1,agree,approve,favorite,hand,like,ok,okay,social,success,thumb,thumbs up,thumbs-o-up,up,yes,you got it dude)',
				),
				array(
					'far fa-thumbs-up' => 'Thumbs Up (+1,agree,approve,favorite,hand,like,ok,okay,social,success,thumb,thumbs up,thumbs-o-up,up,yes,you got it dude)',
				),
				array(
					'fas fa-thumbtack' => 'Thumbtack (thumb-tack,Black Pushpin,coordinates,location,marker,pin,pushpin,thumb-tack)',
				),
				array(
					'fas fa-user' => 'User (adult,bust,bust in silhouette,gender-neutral,person,profile,silhouette,unspecified gender,users-people)',
				),
				array(
					'far fa-user' => 'User (adult,bust,bust in silhouette,gender-neutral,person,profile,silhouette,unspecified gender,users-people)',
				),
				array(
					'fas fa-user-group' => 'User Group (user-friends,bust,busts in silhouette,silhouette,users-people)',
				),
				array(
					'fas fa-user-plus' => 'User Plus (add,avatar,positive,sign up,signup,team)',
				),
				array(
					'fas fa-users' => 'Users (users-people)',
				),
				array(
					'fas fa-video' => 'Video (video-camera,camera,film,movie,record,video-camera)',
				),
			),
			'Spinners' => array(
				array(
					'fas fa-arrows-spin' => 'Arrows Spin (cycle,rotate,spin,whirl)',
				),
				array(
					'fas fa-asterisk' => 'Asterisk (Asterisk,Heavy Asterisk,annotation,details,reference,star)',
				),
				array(
					'fas fa-atom' => 'Atom (atheism,atheist,atom,atom symbol,chemistry,electron,ion,isotope,neutron,nuclear,proton,science)',
				),
				array(
					'fas fa-bahai' => 'Bahai (haykal,bahai,bahá\'í,star)',
				),
				array(
					'fas fa-certificate' => 'Certificate (badge,star,verified)',
				),
				array(
					'fas fa-circle-notch' => 'Circle Notch (circle-o-notch,diameter,dot,ellipse,round,spinner)',
				),
				array(
					'fas fa-compact-disc' => 'Compact Disc (Optical Disc Icon,album,blu-ray,bluray,cd,computer,disc,disk,dvd,media,movie,music,optical,optical disk,record,video,vinyl)',
				),
				array(
					'fas fa-compass' => 'Compass (compass,directions,directory,location,magnetic,menu,navigation,orienteering,safari,travel)',
				),
				array(
					'far fa-compass' => 'Compass (compass,directions,directory,location,magnetic,menu,navigation,orienteering,safari,travel)',
				),
				array(
					'fas fa-crosshairs' => 'Crosshairs (aim,bullseye,gpd,picker,position)',
				),
				array(
					'fas fa-dharmachakra' => 'Dharmachakra (Buddhist,buddhism,buddhist,dharma,religion,wheel,wheel of dharma)',
				),
				array(
					'fas fa-fan' => 'Fan (ac,air conditioning,blade,blower,cool,hot)',
				),
				array(
					'fas fa-gear' => 'Gear (cog,cog,cogwheel,gear,mechanical,settings,sprocket,tool,wheel)',
				),
				array(
					'fas fa-hurricane' => 'Hurricane (coriolis effect,eye,storm,tropical cyclone,typhoon)',
				),
				array(
					'fas fa-life-ring' => 'Life Ring (coast guard,help,overboard,save,support)',
				),
				array(
					'far fa-life-ring' => 'Life Ring (coast guard,help,overboard,save,support)',
				),
				array(
					'fas fa-palette' => 'Palette (acrylic,art,artist palette,brush,color,fill,museum,paint,painting,palette,pigment,watercolor)',
				),
				array(
					'fas fa-ring' => 'Ring (Dungeons & Dragons,Gollum,band,binding,d&d,dnd,engagement,fantasy,gold,jewelry,marriage,precious)',
				),
				array(
					'fas fa-rotate' => 'Rotate (sync-alt,anticlockwise,arrow,counterclockwise,counterclockwise arrows button,exchange,refresh,reload,rotate,swap,withershins)',
				),
				array(
					'fas fa-slash' => 'Slash (cancel,close,mute,off,stop,x)',
				),
				array(
					'fas fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'far fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'fas fa-spinner' => 'Spinner (circle,loading,progress)',
				),
				array(
					'fas fa-stroopwafel' => 'Stroopwafel (caramel,cookie,dessert,sweets,waffle)',
				),
				array(
					'fas fa-sun' => 'Sun (bright,brighten,contrast,day,lighter,rays,sol,solar,star,sun,sunny,weather)',
				),
				array(
					'far fa-sun' => 'Sun (bright,brighten,contrast,day,lighter,rays,sol,solar,star,sun,sunny,weather)',
				),
				array(
					'fas fa-yin-yang' => 'Yin Yang (daoism,opposites,religion,tao,taoism,taoist,yang,yin,yin yang)',
				),
			),
			'Sports + Fitness' => array(
				array(
					'fas fa-baseball' => 'Baseball (baseball-ball,ball,baseball,foul,glove,hardball,league,leather,mlb,softball,sport,underarm)',
				),
				array(
					'fas fa-baseball-bat-ball' => 'Baseball Bat Ball (bat,league,mlb,slugger,softball,sport)',
				),
				array(
					'fas fa-basketball' => 'Basketball (basketball-ball,ball,basketball,dribble,dunk,hoop,nba)',
				),
				array(
					'fas fa-bicycle' => 'Bicycle (bicycle,bike,gears,pedal,transportation,vehicle)',
				),
				array(
					'fas fa-bowling-ball' => 'Bowling Ball (alley,candlepin,gutter,lane,strike,tenpin)',
				),
				array(
					'fas fa-broom-ball' => 'Broom Ball (quidditch,quidditch-broom-ball,ball,bludger,broom,golden snitch,harry potter,hogwarts,quaffle,sport,wizard)',
				),
				array(
					'fas fa-dumbbell' => 'Dumbbell (exercise,gym,strength,weight,weight-lifting)',
				),
				array(
					'fas fa-fire-flame-curved' => 'Fire Flame Curved (fire-alt,burn,caliente,flame,heat,hot,popular)',
				),
				array(
					'fas fa-fire-flame-simple' => 'Fire Flame Simple (burn,caliente,energy,fire,flame,gas,heat,hot)',
				),
				array(
					'fas fa-football' => 'Football (football-ball,american,american football,ball,fall,football,nfl,pigskin,seasonal)',
				),
				array(
					'fas fa-futbol' => 'Futbol (futbol-ball,soccer-ball,ball,football,mls,soccer,soccer ball)',
				),
				array(
					'far fa-futbol' => 'Futbol (futbol-ball,soccer-ball,ball,football,mls,soccer,soccer ball)',
				),
				array(
					'fas fa-golf-ball-tee' => 'Golf Ball Tee (golf-ball,caddy,eagle,putt,tee)',
				),
				array(
					'fas fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'far fa-heart' => 'Heart (black,black heart,blue,blue heart,brown,brown heart,card,evil,favorite,game,green,green heart,heart,heart suit,like,love,orange,orange heart,purple,purple heart,red heart,relationship,valentine,white,white heart,wicked,yellow,yellow heart)',
				),
				array(
					'fas fa-heart-pulse' => 'Heart Pulse (heartbeat,ekg,electrocardiogram,health,lifeline,vital signs)',
				),
				array(
					'fas fa-hockey-puck' => 'Hockey Puck (ice,nhl,sport)',
				),
				array(
					'fas fa-medal' => 'Medal (award,medal,ribbon,sports medal,star,trophy)',
				),
				array(
					'fas fa-mound' => 'Mound (barrier,hill,pitcher,speedbump)',
				),
				array(
					'fas fa-person-biking' => 'Person Biking (biking,bicycle,bike,biking,cyclist,pedal,person biking,summer,wheel)',
				),
				array(
					'fas fa-person-hiking' => 'Person Hiking (hiking,autumn,fall,hike,mountain,outdoors,summer,walk)',
				),
				array(
					'fas fa-person-running' => 'Person Running (running,exit,flee,marathon,person running,race,running)',
				),
				array(
					'fas fa-person-skating' => 'Person Skating (skating,figure skating,ice,olympics,rink,skate,winter)',
				),
				array(
					'fas fa-person-skiing' => 'Person Skiing (skiing,downhill,olympics,ski,skier,snow,winter)',
				),
				array(
					'fas fa-person-skiing-nordic' => 'Person Skiing Nordic (skiing-nordic,cross country,olympics,winter)',
				),
				array(
					'fas fa-person-snowboarding' => 'Person Snowboarding (snowboarding,olympics,ski,snow,snowboard,snowboarder,winter)',
				),
				array(
					'fas fa-person-swimming' => 'Person Swimming (swimmer,ocean,person swimming,pool,sea,swim,water)',
				),
				array(
					'fas fa-person-walking' => 'Person Walking (walking,crosswalk,exercise,hike,move,person walking,walk,walking)',
				),
				array(
					'fas fa-ranking-star' => 'Ranking Star (chart,first place,podium,rank,win)',
				),
				array(
					'fas fa-shoe-prints' => 'Shoe Prints (feet,footprints,steps,walk)',
				),
				array(
					'fas fa-spa' => 'Spa (flora,massage,mindfulness,plant,wellness)',
				),
				array(
					'fas fa-stopwatch-20' => 'Stopwatch 20 (ABCs,countdown,covid-19,happy birthday,i will survive,reminder,seconds,time,timer)',
				),
				array(
					'fas fa-table-tennis-paddle-ball' => 'Table Tennis Paddle Ball (ping-pong-paddle-ball,table-tennis,ball,bat,game,paddle,ping pong,table tennis)',
				),
				array(
					'fas fa-volleyball' => 'Volleyball (volleyball-ball,ball,beach,game,olympics,sport,volleyball)',
				),
				array(
					'fas fa-weight-hanging' => 'Weight Hanging (anvil,heavy,measurement)',
				),
			),
			'Text Formatting' => array(
				array(
					'fas fa-align-center' => 'Align Center (format,middle,paragraph,text)',
				),
				array(
					'fas fa-align-justify' => 'Align Justify (format,paragraph,text)',
				),
				array(
					'fas fa-align-left' => 'Align Left (format,paragraph,text)',
				),
				array(
					'fas fa-align-right' => 'Align Right (format,paragraph,text)',
				),
				array(
					'fas fa-bold' => 'Bold (emphasis,format,text)',
				),
				array(
					'fas fa-border-all' => 'Border All (cell,grid,outline,stroke,table)',
				),
				array(
					'fas fa-border-none' => 'Border None (cell,grid,outline,stroke,table)',
				),
				array(
					'fas fa-border-top-left' => 'Border Top Left (border-style,cell,outline,stroke,table)',
				),
				array(
					'fas fa-check' => 'Check (Check Mark,accept,agree,check,check mark,checkmark,confirm,correct,done,mark,notice,notification,notify,ok,select,success,tick,todo,yes,✓)',
				),
				array(
					'fas fa-check-double' => 'Check Double (accept,agree,checkmark,confirm,correct,done,notice,notification,notify,ok,select,success,tick,todo)',
				),
				array(
					'fas fa-circle-check' => 'Circle Check (check-circle,accept,affected,agree,clear,confirm,correct,done,ok,select,success,tick,todo,yes)',
				),
				array(
					'far fa-circle-check' => 'Circle Check (check-circle,accept,affected,agree,clear,confirm,correct,done,ok,select,success,tick,todo,yes)',
				),
				array(
					'fas fa-filter-circle-xmark' => 'Filter Circle Xmark (cancel,funnel,options,remove,separate,sort)',
				),
				array(
					'fas fa-font' => 'Font (alphabet,glyph,text,type,typeface)',
				),
				array(
					'fas fa-heading' => 'Heading (header,format,header,text,title)',
				),
				array(
					'fas fa-highlighter' => 'Highlighter (edit,marker,sharpie,update,write)',
				),
				array(
					'fas fa-i-cursor' => 'I Cursor (editing,i-beam,type,writing)',
				),
				array(
					'fas fa-icons' => 'Icons (heart-music-camera-bolt,bolt,emoji,heart,image,music,photo,symbols)',
				),
				array(
					'fas fa-indent' => 'Indent (align,justify,paragraph,tab)',
				),
				array(
					'fas fa-italic' => 'Italic (edit,emphasis,font,format,text,type)',
				),
				array(
					'fas fa-list' => 'List (list-squares,checklist,completed,done,finished,ol,todo,ul)',
				),
				array(
					'fas fa-list-check' => 'List Check (tasks,checklist,downloading,downloads,loading,progress,project management,settings,to do)',
				),
				array(
					'fas fa-list-ol' => 'List Ol (list-1-2,list-numeric,checklist,completed,done,finished,numbers,ol,todo,ul)',
				),
				array(
					'fas fa-list-ul' => 'List Ul (list-dots,checklist,completed,done,finished,ol,todo,ul)',
				),
				array(
					'fas fa-outdent' => 'Outdent (dedent,align,justify,paragraph,tab)',
				),
				array(
					'fas fa-paragraph' => 'Paragraph (Pilcrow Sign,edit,format,text,writing)',
				),
				array(
					'fas fa-rectangle-list' => 'Rectangle List (list-alt,checklist,completed,done,finished,ol,todo,ul)',
				),
				array(
					'far fa-rectangle-list' => 'Rectangle List (list-alt,checklist,completed,done,finished,ol,todo,ul)',
				),
				array(
					'fas fa-spell-check' => 'Spell Check (dictionary,edit,editor,grammar,text)',
				),
				array(
					'fas fa-square-check' => 'Square Check (check-square,accept,agree,box,button,check,check box with check,check mark button,checkmark,confirm,correct,done,mark,ok,select,success,tick,todo,yes,✓)',
				),
				array(
					'far fa-square-check' => 'Square Check (check-square,accept,agree,box,button,check,check box with check,check mark button,checkmark,confirm,correct,done,mark,ok,select,success,tick,todo,yes,✓)',
				),
				array(
					'fas fa-strikethrough' => 'Strikethrough (cancel,edit,font,format,text,type)',
				),
				array(
					'fas fa-subscript' => 'Subscript (edit,font,format,text,type)',
				),
				array(
					'fas fa-superscript' => 'Superscript (edit,exponential,font,format,text,type)',
				),
				array(
					'fas fa-table' => 'Table (data,excel,spreadsheet)',
				),
				array(
					'fas fa-table-cells' => 'Table Cells (th,blocks,boxes,grid,squares)',
				),
				array(
					'fas fa-table-cells-large' => 'Table Cells Large (th-large,blocks,boxes,grid,squares)',
				),
				array(
					'fas fa-table-columns' => 'Table Columns (columns,browser,dashboard,organize,panes,split)',
				),
				array(
					'fas fa-table-list' => 'Table List (th-list,checklist,completed,done,finished,ol,todo,ul)',
				),
				array(
					'fas fa-text-height' => 'Text Height (edit,font,format,text,type)',
				),
				array(
					'fas fa-text-slash' => 'Text Slash (remove-format,cancel,font,format,remove,style,text)',
				),
				array(
					'fas fa-text-width' => 'Text Width (edit,font,format,text,type)',
				),
				array(
					'fas fa-underline' => 'Underline (edit,emphasis,format,text,writing)',
				),
			),
			'Time' => array(
				array(
					'fas fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'far fa-bell' => 'Bell (alarm,alert,bel,bell,chime,notification,reminder)',
				),
				array(
					'fas fa-bell-slash' => 'Bell Slash (alert,bell,bell with slash,cancel,disabled,forbidden,mute,notification,off,quiet,reminder,silent)',
				),
				array(
					'far fa-bell-slash' => 'Bell Slash (alert,bell,bell with slash,cancel,disabled,forbidden,mute,notification,off,quiet,reminder,silent)',
				),
				array(
					'fas fa-calendar' => 'Calendar (calendar,calendar-o,date,day,event,month,schedule,tear-off calendar,time,when,year)',
				),
				array(
					'far fa-calendar' => 'Calendar (calendar,calendar-o,date,day,event,month,schedule,tear-off calendar,time,when,year)',
				),
				array(
					'fas fa-calendar-check' => 'Calendar Check (accept,agree,appointment,confirm,correct,date,day,done,event,month,ok,schedule,select,success,tick,time,todo,when,year)',
				),
				array(
					'far fa-calendar-check' => 'Calendar Check (accept,agree,appointment,confirm,correct,date,day,done,event,month,ok,schedule,select,success,tick,time,todo,when,year)',
				),
				array(
					'fas fa-calendar-day' => 'Calendar Day (date,day,detail,event,focus,month,schedule,single day,time,today,when,year)',
				),
				array(
					'fas fa-calendar-days' => 'Calendar Days (calendar-alt,calendar,date,day,event,month,schedule,time,when,year)',
				),
				array(
					'far fa-calendar-days' => 'Calendar Days (calendar-alt,calendar,date,day,event,month,schedule,time,when,year)',
				),
				array(
					'fas fa-calendar-minus' => 'Calendar Minus (calendar,date,day,delete,event,month,negative,remove,schedule,time,when,year)',
				),
				array(
					'far fa-calendar-minus' => 'Calendar Minus (calendar,date,day,delete,event,month,negative,remove,schedule,time,when,year)',
				),
				array(
					'fas fa-calendar-plus' => 'Calendar Plus (add,calendar,create,date,day,event,month,new,positive,schedule,time,when,year)',
				),
				array(
					'far fa-calendar-plus' => 'Calendar Plus (add,calendar,create,date,day,event,month,new,positive,schedule,time,when,year)',
				),
				array(
					'fas fa-calendar-week' => 'Calendar Week (date,day,detail,event,focus,month,schedule,single week,time,today,when,year)',
				),
				array(
					'fas fa-calendar-xmark' => 'Calendar Xmark (calendar-times,archive,calendar,date,day,delete,event,month,remove,schedule,time,when,x,year)',
				),
				array(
					'far fa-calendar-xmark' => 'Calendar Xmark (calendar-times,archive,calendar,date,day,delete,event,month,remove,schedule,time,when,x,year)',
				),
				array(
					'fas fa-clock' => 'Clock (clock-four,00,4,4:00,clock,date,four,four o’clock,hour,late,minute,o\'clock,o’clock,schedule,ticking,time,timer,timestamp,watch)',
				),
				array(
					'far fa-clock' => 'Clock (clock-four,00,4,4:00,clock,date,four,four o’clock,hour,late,minute,o\'clock,o’clock,schedule,ticking,time,timer,timestamp,watch)',
				),
				array(
					'fas fa-hourglass' => 'Hourglass (hourglass-empty,hour,hourglass,hourglass not done,minute,sand,stopwatch,time,timer)',
				),
				array(
					'far fa-hourglass' => 'Hourglass (hourglass-empty,hour,hourglass,hourglass not done,minute,sand,stopwatch,time,timer)',
				),
				array(
					'fas fa-hourglass-end' => 'Hourglass End (hourglass-3,hour,hourglass done,minute,sand,stopwatch,time,timer)',
				),
				array(
					'fas fa-hourglass-half' => 'Hourglass Half (hourglass-2,hour,minute,sand,stopwatch,time)',
				),
				array(
					'far fa-hourglass-half' => 'Hourglass Half (hourglass-2,hour,minute,sand,stopwatch,time)',
				),
				array(
					'fas fa-hourglass-start' => 'Hourglass Start (hourglass-1,hour,minute,sand,stopwatch,time)',
				),
				array(
					'fas fa-stopwatch' => 'Stopwatch (clock,reminder,stopwatch,time)',
				),
				array(
					'fas fa-stopwatch-20' => 'Stopwatch 20 (ABCs,countdown,covid-19,happy birthday,i will survive,reminder,seconds,time,timer)',
				),
			),
			'Toggle' => array(
				array(
					'fas fa-bullseye' => 'Bullseye (archery,goal,objective,strategy,target)',
				),
				array(
					'fas fa-circle' => 'Circle (Black Circle,Black Large Circle,black circle,blue,blue circle,brown,brown circle,chart,circle,circle-thin,diameter,dot,ellipse,fill,geometric,green,green circle,notification,orange,orange circle,progress,purple,purple circle,red,red circle,round,white circle,yellow,yellow circle)',
				),
				array(
					'far fa-circle' => 'Circle (Black Circle,Black Large Circle,black circle,blue,blue circle,brown,brown circle,chart,circle,circle-thin,diameter,dot,ellipse,fill,geometric,green,green circle,notification,orange,orange circle,progress,purple,purple circle,red,red circle,round,white circle,yellow,yellow circle)',
				),
				array(
					'fas fa-circle-check' => 'Circle Check (check-circle,accept,affected,agree,clear,confirm,correct,done,ok,select,success,tick,todo,yes)',
				),
				array(
					'far fa-circle-check' => 'Circle Check (check-circle,accept,affected,agree,clear,confirm,correct,done,ok,select,success,tick,todo,yes)',
				),
				array(
					'fas fa-circle-dot' => 'Circle Dot (dot-circle,bullseye,button,geometric,notification,radio,radio button,target)',
				),
				array(
					'far fa-circle-dot' => 'Circle Dot (dot-circle,bullseye,button,geometric,notification,radio,radio button,target)',
				),
				array(
					'fas fa-location-crosshairs' => 'Location Crosshairs (location,address,coordinate,direction,gps,location,map,navigation,place,where)',
				),
				array(
					'fas fa-microphone' => 'Microphone (address,audio,information,podcast,public,record,sing,sound,voice)',
				),
				array(
					'fas fa-microphone-slash' => 'Microphone Slash (audio,disable,mute,podcast,record,sing,sound,voice)',
				),
				array(
					'fas fa-plane-up' => 'Plane Up (airplane,airport,internet,signal,sky,wifi,wireless)',
				),
				array(
					'fas fa-signal' => 'Signal (signal-5,signal-perfect,antenna,antenna bars,bar,bars,cell,graph,mobile,online,phone,reception,status)',
				),
				array(
					'fas fa-star' => 'Star (achievement,award,favorite,important,night,rating,score,star)',
				),
				array(
					'far fa-star' => 'Star (achievement,award,favorite,important,night,rating,score,star)',
				),
				array(
					'fas fa-star-half' => 'Star Half (achievement,award,rating,score,star-half-empty,star-half-full)',
				),
				array(
					'far fa-star-half' => 'Star Half (achievement,award,rating,score,star-half-empty,star-half-full)',
				),
				array(
					'fas fa-star-half-stroke' => 'Star Half Stroke (star-half-alt,achievement,award,rating,score,star-half-empty,star-half-full)',
				),
				array(
					'far fa-star-half-stroke' => 'Star Half Stroke (star-half-alt,achievement,award,rating,score,star-half-empty,star-half-full)',
				),
				array(
					'fas fa-toggle-off' => 'Toggle Off (button,off,on,switch)',
				),
				array(
					'fas fa-toggle-on' => 'Toggle On (button,off,on,switch)',
				),
				array(
					'fas fa-wifi' => 'Wifi (wifi-3,wifi-strong,connection,hotspot,internet,network,wireless)',
				),
			),
			'Transportation' => array(
				array(
					'fab fa-accessible-icon' => 'Accessible Icon (accessibility,handicap,person,wheelchair,wheelchair-alt)',
				),
				array(
					'fas fa-baby-carriage' => 'Baby Carriage (carriage-baby,buggy,carrier,infant,push,stroller,transportation,walk,wheels)',
				),
				array(
					'fas fa-bicycle' => 'Bicycle (bicycle,bike,gears,pedal,transportation,vehicle)',
				),
				array(
					'fas fa-bus' => 'Bus (bus,oncoming,oncoming bus,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-bus-simple' => 'Bus Simple (bus-alt,mta,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-cable-car' => 'Cable Car (tram,aerial tramway,cable,gondola,lift,mountain,mountain cableway,tram,tramway,trolley)',
				),
				array(
					'fas fa-car' => 'Car (automobile,auto,automobile,car,oncoming,oncoming automobile,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car-burst' => 'Car Burst (car-crash,accident,auto,automobile,insurance,sedan,transportation,vehicle,wreck)',
				),
				array(
					'fas fa-car-rear' => 'Car Rear (car-alt,auto,automobile,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car-side' => 'Car Side (auto,automobile,car,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-car-tunnel' => 'Car Tunnel (road,tunnel)',
				),
				array(
					'fas fa-cart-shopping' => 'Cart Shopping (shopping-cart,buy,cart,checkout,grocery,payment,purchase,shopping,shopping cart,trolley)',
				),
				array(
					'fas fa-ferry' => 'Ferry (barge,boat,carry,ferryboat,ship)',
				),
				array(
					'fas fa-helicopter' => 'Helicopter (airwolf,apache,chopper,flight,fly,helicopter,travel,vehicle)',
				),
				array(
					'fas fa-horse' => 'Horse (equestrian,equus,fauna,horse,mammmal,mare,neigh,pony,racehorse,racing)',
				),
				array(
					'fas fa-jet-fighter' => 'Jet Fighter (fighter-jet,airforce,airplane,airport,fast,fly,goose,marines,maverick,military,plane,quick,top gun,transportation,travel)',
				),
				array(
					'fas fa-jet-fighter-up' => 'Jet Fighter Up (airforce,airplane,airport,fast,fly,goose,marines,maverick,military,plane,quick,top gun,transportation,travel)',
				),
				array(
					'fas fa-motorcycle' => 'Motorcycle (bike,machine,motorcycle,racing,transportation,vehicle)',
				),
				array(
					'fas fa-mound' => 'Mound (barrier,hill,pitcher,speedbump)',
				),
				array(
					'fas fa-paper-plane' => 'Paper Plane (air,float,fold,mail,paper,send)',
				),
				array(
					'far fa-paper-plane' => 'Paper Plane (air,float,fold,mail,paper,send)',
				),
				array(
					'fas fa-plane' => 'Plane (airplane,airport,destination,fly,location,mode,travel,trip)',
				),
				array(
					'fas fa-plane-slash' => 'Plane Slash (airplane mode,airport,canceled,covid-19,delayed,grounded,travel)',
				),
				array(
					'fas fa-plane-up' => 'Plane Up (airplane,airport,internet,signal,sky,wifi,wireless)',
				),
				array(
					'fas fa-road' => 'Road (highway,map,motorway,pavement,road,route,street,travel)',
				),
				array(
					'fas fa-road-barrier' => 'Road Barrier (block,border,no entry,roadblock)',
				),
				array(
					'fas fa-road-spikes' => 'Road Spikes (barrier,roadblock,spikes)',
				),
				array(
					'fas fa-rocket' => 'Rocket (aircraft,app,jet,launch,nasa,space)',
				),
				array(
					'fas fa-sailboat' => 'Sailboat (dinghy,mast,sailboat,sailing,yacht)',
				),
				array(
					'fas fa-ship' => 'Ship (boat,passenger,sea,ship,water)',
				),
				array(
					'fas fa-shuttle-space' => 'Shuttle Space (space-shuttle,astronaut,machine,nasa,rocket,space,transportation)',
				),
				array(
					'fas fa-sleigh' => 'Sleigh (christmas,claus,fly,holiday,santa,sled,snow,xmas)',
				),
				array(
					'fas fa-snowplow' => 'Snowplow (clean up,cold,road,storm,winter)',
				),
				array(
					'fas fa-taxi' => 'Taxi (cab,cab,cabbie,car,car service,lyft,machine,oncoming,oncoming taxi,taxi,transportation,travel,uber,vehicle)',
				),
				array(
					'fas fa-tractor' => 'Tractor (agriculture,farm,tractor,vehicle)',
				),
				array(
					'fas fa-train' => 'Train (bullet,commute,locomotive,railway,subway,train)',
				),
				array(
					'fas fa-train-subway' => 'Train Subway (subway,machine,railway,train,transportation,vehicle)',
				),
				array(
					'fas fa-train-tram' => 'Train Tram (crossing,machine,mountains,seasonal,tram,transportation,trolleybus)',
				),
				array(
					'fas fa-truck' => 'Truck (Black Truck,cargo,delivery,delivery truck,shipping,truck,vehicle)',
				),
				array(
					'fas fa-truck-arrow-right' => 'Truck Arrow Right (access,fast,shipping,transport)',
				),
				array(
					'fas fa-truck-droplet' => 'Truck Droplet (thirst,truck,water,water supply)',
				),
				array(
					'fas fa-truck-field' => 'Truck Field (supplies,truck)',
				),
				array(
					'fas fa-truck-field-un' => 'Truck Field Un (supplies,truck,united nations)',
				),
				array(
					'fas fa-truck-front' => 'Truck Front (shuttle,truck,van)',
				),
				array(
					'fas fa-truck-medical' => 'Truck Medical (ambulance,ambulance,clinic,covid-19,emergency,emt,er,help,hospital,mobile,support,vehicle)',
				),
				array(
					'fas fa-truck-monster' => 'Truck Monster (offroad,vehicle,wheel)',
				),
				array(
					'fas fa-truck-pickup' => 'Truck Pickup (cargo,pick-up,pickup,pickup truck,truck,vehicle)',
				),
				array(
					'fas fa-truck-plane' => 'Truck Plane (airplane,plane,transportation,truck,vehicle)',
				),
				array(
					'fas fa-van-shuttle' => 'Van Shuttle (shuttle-van,airport,bus,machine,minibus,public-transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-wheelchair' => 'Wheelchair (users-people)',
				),
				array(
					'fas fa-wheelchair-move' => 'Wheelchair Move (wheelchair-alt,access,handicap,impairment,physical,wheelchair symbol)',
				),
			),
			'Travel + Hotel' => array(
				array(
					'fas fa-archway' => 'Archway (arc,monument,road,street,tunnel)',
				),
				array(
					'fas fa-baby-carriage' => 'Baby Carriage (carriage-baby,buggy,carrier,infant,push,stroller,transportation,walk,wheels)',
				),
				array(
					'fas fa-ban-smoking' => 'Ban Smoking (smoking-ban,ban,cancel,forbidden,no,no smoking,non-smoking,not,prohibited,smoking)',
				),
				array(
					'fas fa-bath' => 'Bath (bathtub,bath,bathtub,clean,shower,tub,wash)',
				),
				array(
					'fas fa-bed' => 'Bed (hospital,hotel,lodging,mattress,patient,person in bed,rest,sleep,travel)',
				),
				array(
					'fas fa-bell-concierge' => 'Bell Concierge (concierge-bell,attention,bell,bellhop,bellhop bell,hotel,receptionist,service,support)',
				),
				array(
					'fas fa-book-atlas' => 'Book Atlas (atlas,book,directions,geography,globe,library,map,research,travel,wayfinding)',
				),
				array(
					'fas fa-briefcase' => 'Briefcase (bag,briefcas,briefcase,business,luggage,office,work)',
				),
				array(
					'fas fa-bus' => 'Bus (bus,oncoming,oncoming bus,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-bus-simple' => 'Bus Simple (bus-alt,mta,public transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-cable-car' => 'Cable Car (tram,aerial tramway,cable,gondola,lift,mountain,mountain cableway,tram,tramway,trolley)',
				),
				array(
					'fas fa-car' => 'Car (automobile,auto,automobile,car,oncoming,oncoming automobile,sedan,transportation,travel,vehicle)',
				),
				array(
					'fas fa-caravan' => 'Caravan (camper,motor home,rv,trailer,travel)',
				),
				array(
					'fas fa-cart-flatbed-suitcase' => 'Cart Flatbed Suitcase (luggage-cart,airport,bag,baggage,suitcase,travel)',
				),
				array(
					'fas fa-dice' => 'Dice (chance,dice,die,gambling,game,game die,roll)',
				),
				array(
					'fas fa-dice-five' => 'Dice Five (Die Face-5,chance,gambling,game,roll)',
				),
				array(
					'fas fa-door-closed' => 'Door Closed (doo,door,enter,exit,locked)',
				),
				array(
					'fas fa-door-open' => 'Door Open (enter,exit,welcome)',
				),
				array(
					'fas fa-dumbbell' => 'Dumbbell (exercise,gym,strength,weight,weight-lifting)',
				),
				array(
					'fas fa-earth-africa' => 'Earth Africa (globe-africa,africa,all,country,earth,europe,global,globe,gps,language,localize,location,map,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-earth-americas' => 'Earth Americas (earth,earth-america,globe-americas,all,america,country,earth,global,globe,gps,language,localize,location,map,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-earth-asia' => 'Earth Asia (globe-asia,all,asia,australia,country,earth,global,globe,gps,language,localize,location,map,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-earth-europe' => 'Earth Europe (globe-europe,all,country,earth,europe,global,globe,gps,language,localize,location,map,online,place,planet,translate,travel,world)',
				),
				array(
					'fas fa-earth-oceania' => 'Earth Oceania (globe-oceania,all,australia,country,earth,global,globe,gps,language,localize,location,map,melanesia,micronesia,new zealand,online,place,planet,polynesia,translate,travel,world)',
				),
				array(
					'fas fa-elevator' => 'Elevator (accessibility,elevator,hoist,lift,users-people)',
				),
				array(
					'fas fa-hot-tub-person' => 'Hot Tub Person (hot-tub,jacuzzi,spa)',
				),
				array(
					'fas fa-hotel' => 'Hotel (building,hotel,inn,lodging,motel,resort,travel)',
				),
				array(
					'fas fa-infinity' => 'Infinity (Infinity,eternity,forever,infinity,math,unbounded,universal)',
				),
				array(
					'fas fa-key' => 'Key (key,lock,password,private,secret,unlock)',
				),
				array(
					'fas fa-kitchen-set' => 'Kitchen Set (chef,cook,cup,kitchen,pan,pot,skillet)',
				),
				array(
					'fas fa-map' => 'Map (address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel,world,world map)',
				),
				array(
					'far fa-map' => 'Map (address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel,world,world map)',
				),
				array(
					'fas fa-map-location' => 'Map Location (map-marked,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-map-location-dot' => 'Map Location Dot (map-marked-alt,address,coordinates,destination,gps,localize,location,map,navigation,paper,pin,place,point of interest,position,route,travel)',
				),
				array(
					'fas fa-martini-glass' => 'Martini Glass (glass-martini-alt,alcohol,bar,beverage,cocktail,cocktail glass,drink,glass,liquor)',
				),
				array(
					'fas fa-martini-glass-citrus' => 'Martini Glass Citrus (cocktail,alcohol,beverage,drink,gin,glass,margarita,martini,vodka)',
				),
				array(
					'fas fa-martini-glass-empty' => 'Martini Glass Empty (glass-martini,alcohol,bar,beverage,drink,liquor)',
				),
				array(
					'fas fa-monument' => 'Monument (building,historic,landmark,memorable)',
				),
				array(
					'fas fa-mountain-city' => 'Mountain City (location,rural,urban)',
				),
				array(
					'fas fa-mug-saucer' => 'Mug Saucer (coffee,beverage,breakfast,cafe,drink,fall,morning,mug,seasonal,tea)',
				),
				array(
					'fas fa-passport' => 'Passport (document,id,identification,issued,travel)',
				),
				array(
					'fas fa-person-swimming' => 'Person Swimming (swimmer,ocean,person swimming,pool,sea,swim,water)',
				),
				array(
					'fas fa-person-walking-luggage' => 'Person Walking Luggage (bag,baggage,briefcase,carry-on,deployment,rolling)',
				),
				array(
					'fas fa-plane' => 'Plane (airplane,airport,destination,fly,location,mode,travel,trip)',
				),
				array(
					'fas fa-plane-arrival' => 'Plane Arrival (aeroplane,airplane,airplane arrival,airport,arrivals,arriving,destination,fly,land,landing,location,mode,travel,trip)',
				),
				array(
					'fas fa-plane-circle-check' => 'Plane Circle Check (airplane,airport,flight,fly,not affected,ok,okay,travel)',
				),
				array(
					'fas fa-plane-circle-exclamation' => 'Plane Circle Exclamation (affected,airplane,airport,flight,fly,travel)',
				),
				array(
					'fas fa-plane-circle-xmark' => 'Plane Circle Xmark (airplane,airport,destroy,flight,fly,travel)',
				),
				array(
					'fas fa-plane-departure' => 'Plane Departure (aeroplane,airplane,airplane departure,airport,check-in,departing,departure,departures,destination,fly,location,mode,take off,taking off,travel,trip)',
				),
				array(
					'fas fa-plane-lock' => 'Plane Lock (airplane,airport,closed,flight,fly,lockdown,quarantine,travel)',
				),
				array(
					'fas fa-plane-slash' => 'Plane Slash (airplane mode,airport,canceled,covid-19,delayed,grounded,travel)',
				),
				array(
					'fas fa-plane-up' => 'Plane Up (airplane,airport,internet,signal,sky,wifi,wireless)',
				),
				array(
					'fas fa-shower' => 'Shower (bath,clean,faucet,shower,water)',
				),
				array(
					'fas fa-smoking' => 'Smoking (cancer,cigarette,nicotine,smoking,smoking status,tobacco)',
				),
				array(
					'fas fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'far fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'fas fa-spa' => 'Spa (flora,massage,mindfulness,plant,wellness)',
				),
				array(
					'fas fa-stairs' => 'Stairs (exit,steps,up)',
				),
				array(
					'fas fa-suitcase' => 'Suitcase (baggage,luggage,move,packing,suitcase,travel,trip)',
				),
				array(
					'fas fa-suitcase-rolling' => 'Suitcase Rolling (baggage,luggage,move,suitcase,travel,trip)',
				),
				array(
					'fas fa-taxi' => 'Taxi (cab,cab,cabbie,car,car service,lyft,machine,oncoming,oncoming taxi,taxi,transportation,travel,uber,vehicle)',
				),
				array(
					'fas fa-toilet' => 'Toilet (bathroom,flush,john,loo,pee,plumbing,poop,porcelain,potty,restroom,throne,toile,toilet,washroom,waste,wc)',
				),
				array(
					'fas fa-toilet-paper' => 'Toilet Paper (bathroom,covid-19,halloween,holiday,lavatory,paper towels,prank,privy,restroom,roll,roll of paper,toilet,toilet paper,wipe)',
				),
				array(
					'fas fa-train-tram' => 'Train Tram (crossing,machine,mountains,seasonal,tram,transportation,trolleybus)',
				),
				array(
					'fas fa-tree-city' => 'Tree City (building,city,urban)',
				),
				array(
					'fas fa-tv' => 'Tv (television,tv-alt,computer,display,monitor,television)',
				),
				array(
					'fas fa-umbrella-beach' => 'Umbrella Beach (beach,beach with umbrella,protection,recreation,sand,shade,summer,sun,umbrella)',
				),
				array(
					'fas fa-utensils' => 'Utensils (cutlery,cooking,cutlery,dining,dinner,eat,food,fork,fork and knife,knife,restaurant)',
				),
				array(
					'fas fa-van-shuttle' => 'Van Shuttle (shuttle-van,airport,bus,machine,minibus,public-transportation,transportation,travel,vehicle)',
				),
				array(
					'fas fa-water-ladder' => 'Water Ladder (ladder-water,swimming-pool,ladder,recreation,swim,water)',
				),
				array(
					'fas fa-wheelchair' => 'Wheelchair (users-people)',
				),
				array(
					'fas fa-wheelchair-move' => 'Wheelchair Move (wheelchair-alt,access,handicap,impairment,physical,wheelchair symbol)',
				),
				array(
					'fas fa-wifi' => 'Wifi (wifi-3,wifi-strong,connection,hotspot,internet,network,wireless)',
				),
				array(
					'fas fa-wine-glass' => 'Wine Glass (alcohol,bar,beverage,cabernet,drink,glass,grapes,merlot,sauvignon,wine,wine glass)',
				),
				array(
					'fas fa-wine-glass-empty' => 'Wine Glass Empty (wine-glass-alt,alcohol,beverage,cabernet,drink,grapes,merlot,sauvignon)',
				),
			),
			'Users + People' => array(
				array(
					'fab fa-accessible-icon' => 'Accessible Icon (accessibility,handicap,person,wheelchair,wheelchair-alt)',
				),
				array(
					'fas fa-address-book' => 'Address Book (contact-book,contact,directory,index,little black book,rolodex)',
				),
				array(
					'far fa-address-book' => 'Address Book (contact-book,contact,directory,index,little black book,rolodex)',
				),
				array(
					'fas fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'far fa-address-card' => 'Address Card (contact-card,vcard,about,contact,id,identification,postcard,profile,registration)',
				),
				array(
					'fas fa-arrows-down-to-people' => 'Arrows Down To People (affected,focus,targeted)',
				),
				array(
					'fas fa-baby' => 'Baby (users-people)',
				),
				array(
					'fas fa-bed' => 'Bed (hospital,hotel,lodging,mattress,patient,person in bed,rest,sleep,travel)',
				),
				array(
					'fas fa-chalkboard-user' => 'Chalkboard User (chalkboard-teacher,blackboard,instructor,learning,professor,school,whiteboard,writing)',
				),
				array(
					'fas fa-child' => 'Child (boy,girl,kid,toddler,young,youth)',
				),
				array(
					'fas fa-child-dress' => 'Child Dress (boy,girl,kid,toddler,young,youth)',
				),
				array(
					'fas fa-child-reaching' => 'Child Reaching (boy,girl,kid,toddler,young,youth)',
				),
				array(
					'fas fa-children' => 'Children (boy,child,girl,kid,kids,young,youth)',
				),
				array(
					'fas fa-circle-user' => 'Circle User (user-circle,users-people)',
				),
				array(
					'far fa-circle-user' => 'Circle User (user-circle,users-people)',
				),
				array(
					'fas fa-clipboard-user' => 'Clipboard User (attendance,record,roster,staff)',
				),
				array(
					'fas fa-elevator' => 'Elevator (accessibility,elevator,hoist,lift,users-people)',
				),
				array(
					'fas fa-face-frown' => 'Face Frown (frown,disapprove,emoticon,face,frown,frowning face,rating,sad)',
				),
				array(
					'far fa-face-frown' => 'Face Frown (frown,disapprove,emoticon,face,frown,frowning face,rating,sad)',
				),
				array(
					'fas fa-face-meh' => 'Face Meh (meh,deadpan,emoticon,face,meh,neutral,neutral face,rating)',
				),
				array(
					'far fa-face-meh' => 'Face Meh (meh,deadpan,emoticon,face,meh,neutral,neutral face,rating)',
				),
				array(
					'fas fa-face-smile' => 'Face Smile (smile,approve,emoticon,face,happy,rating,satisfied,slightly smiling face,smile)',
				),
				array(
					'far fa-face-smile' => 'Face Smile (smile,approve,emoticon,face,happy,rating,satisfied,slightly smiling face,smile)',
				),
				array(
					'fas fa-head-side-cough' => 'Head Side Cough (cough,covid-19,germs,lungs,respiratory,sick)',
				),
				array(
					'fas fa-head-side-cough-slash' => 'Head Side Cough Slash (cough,covid-19,germs,lungs,respiratory,sick)',
				),
				array(
					'fas fa-head-side-mask' => 'Head Side Mask (breath,coronavirus,covid-19,filter,flu,infection,pandemic,respirator,virus)',
				),
				array(
					'fas fa-head-side-virus' => 'Head Side Virus (cold,coronavirus,covid-19,flu,infection,pandemic,sick)',
				),
				array(
					'fas fa-hospital-user' => 'Hospital User (covid-19,doctor,network,patient,primary care)',
				),
				array(
					'fas fa-hot-tub-person' => 'Hot Tub Person (hot-tub,jacuzzi,spa)',
				),
				array(
					'fas fa-house-chimney-user' => 'House Chimney User (covid-19,home,isolation,quarantine)',
				),
				array(
					'fas fa-house-user' => 'House User (home-user,house)',
				),
				array(
					'fas fa-id-badge' => 'Id Badge (address,contact,identification,license,profile)',
				),
				array(
					'far fa-id-badge' => 'Id Badge (address,contact,identification,license,profile)',
				),
				array(
					'fas fa-id-card' => 'Id Card (drivers-license,contact,demographics,document,identification,issued,profile,registration)',
				),
				array(
					'far fa-id-card' => 'Id Card (drivers-license,contact,demographics,document,identification,issued,profile,registration)',
				),
				array(
					'fas fa-id-card-clip' => 'Id Card Clip (id-card-alt,contact,demographics,document,identification,issued,profile)',
				),
				array(
					'fas fa-image-portrait' => 'Image Portrait (portrait,id,image,photo,picture,selfie)',
				),
				array(
					'fas fa-mars-and-venus-burst' => 'Mars And Venus Burst (gender,violence)',
				),
				array(
					'fas fa-people-arrows' => 'People Arrows (people-arrows-left-right,distance,isolation,separate,social distancing,users-people)',
				),
				array(
					'fas fa-people-carry-box' => 'People Carry Box (people-carry,users-people)',
				),
				array(
					'fas fa-people-group' => 'People Group (family,group,team)',
				),
				array(
					'fas fa-people-line' => 'People Line (group,need)',
				),
				array(
					'fas fa-people-pulling' => 'People Pulling (forced return,yanking)',
				),
				array(
					'fas fa-people-robbery' => 'People Robbery (criminal,hands up,looting,robbery,steal)',
				),
				array(
					'fas fa-people-roof' => 'People Roof (family,group,manage,people,safe,shelter)',
				),
				array(
					'fas fa-person' => 'Person (male,man,person standing,stand,standing,woman)',
				),
				array(
					'fas fa-person-arrow-down-to-line' => 'Person Arrow Down To Line (ground,indigenous,native)',
				),
				array(
					'fas fa-person-arrow-up-from-line' => 'Person Arrow Up From Line (population,rise)',
				),
				array(
					'fas fa-person-biking' => 'Person Biking (biking,bicycle,bike,biking,cyclist,pedal,person biking,summer,wheel)',
				),
				array(
					'fas fa-person-booth' => 'Person Booth (changing room,curtain,vote,voting)',
				),
				array(
					'fas fa-person-breastfeeding' => 'Person Breastfeeding (baby,child,infant,mother,nutrition,sustenance)',
				),
				array(
					'fas fa-person-burst' => 'Person Burst (abuse,accident,crash,explode,violence)',
				),
				array(
					'fas fa-person-cane' => 'Person Cane (aging,cane,elderly,old,staff)',
				),
				array(
					'fas fa-person-chalkboard' => 'Person Chalkboard (blackboard,instructor,keynote,lesson,presentation,teacher)',
				),
				array(
					'fas fa-person-circle-check' => 'Person Circle Check (approved,not affected,ok,okay)',
				),
				array(
					'fas fa-person-circle-exclamation' => 'Person Circle Exclamation (affected,alert,lost,missing)',
				),
				array(
					'fas fa-person-circle-minus' => 'Person Circle Minus (delete,remove)',
				),
				array(
					'fas fa-person-circle-plus' => 'Person Circle Plus (add,found)',
				),
				array(
					'fas fa-person-circle-question' => 'Person Circle Question (lost,missing)',
				),
				array(
					'fas fa-person-circle-xmark' => 'Person Circle Xmark (dead,removed)',
				),
				array(
					'fas fa-person-digging' => 'Person Digging (digging,bury,construction,debris,dig,men at work)',
				),
				array(
					'fas fa-person-dots-from-line' => 'Person Dots From Line (diagnoses,allergy,diagnosis)',
				),
				array(
					'fas fa-person-dress' => 'Person Dress (female,man,skirt,woman)',
				),
				array(
					'fas fa-person-dress-burst' => 'Person Dress Burst (abuse,accident,crash,explode,violence)',
				),
				array(
					'fas fa-person-drowning' => 'Person Drowning (drown,emergency,swim)',
				),
				array(
					'fas fa-person-falling' => 'Person Falling (accident,fall,trip)',
				),
				array(
					'fas fa-person-falling-burst' => 'Person Falling Burst (accident,crash,death,fall,homicide,murder)',
				),
				array(
					'fas fa-person-half-dress' => 'Person Half Dress (gender,man,restroom,transgender,woman)',
				),
				array(
					'fas fa-person-harassing' => 'Person Harassing (abuse,scream,shame,shout,yell)',
				),
				array(
					'fas fa-person-hiking' => 'Person Hiking (hiking,autumn,fall,hike,mountain,outdoors,summer,walk)',
				),
				array(
					'fas fa-person-military-pointing' => 'Person Military Pointing (army,customs,guard)',
				),
				array(
					'fas fa-person-military-rifle' => 'Person Military Rifle (armed forces,army,military,rifle,war)',
				),
				array(
					'fas fa-person-military-to-person' => 'Person Military To Person (civilian,coordination,military)',
				),
				array(
					'fas fa-person-praying' => 'Person Praying (pray,kneel,place of worship,religion,thank,worship)',
				),
				array(
					'fas fa-person-pregnant' => 'Person Pregnant (baby,birth,child,pregnant,pregnant woman,woman)',
				),
				array(
					'fas fa-person-rays' => 'Person Rays (affected,focus,shine)',
				),
				array(
					'fas fa-person-rifle' => 'Person Rifle (army,combatant,gun,military,rifle,war)',
				),
				array(
					'fas fa-person-running' => 'Person Running (running,exit,flee,marathon,person running,race,running)',
				),
				array(
					'fas fa-person-shelter' => 'Person Shelter (house,inside,roof,safe,safety,shelter)',
				),
				array(
					'fas fa-person-skating' => 'Person Skating (skating,figure skating,ice,olympics,rink,skate,winter)',
				),
				array(
					'fas fa-person-skiing' => 'Person Skiing (skiing,downhill,olympics,ski,skier,snow,winter)',
				),
				array(
					'fas fa-person-skiing-nordic' => 'Person Skiing Nordic (skiing-nordic,cross country,olympics,winter)',
				),
				array(
					'fas fa-person-snowboarding' => 'Person Snowboarding (snowboarding,olympics,ski,snow,snowboard,snowboarder,winter)',
				),
				array(
					'fas fa-person-swimming' => 'Person Swimming (swimmer,ocean,person swimming,pool,sea,swim,water)',
				),
				array(
					'fas fa-person-through-window' => 'Person Through Window (door,exit,forced entry,leave,robbery,steal,window)',
				),
				array(
					'fas fa-person-walking' => 'Person Walking (walking,crosswalk,exercise,hike,move,person walking,walk,walking)',
				),
				array(
					'fas fa-person-walking-arrow-loop-left' => 'Person Walking Arrow Loop Left (population return,return)',
				),
				array(
					'fas fa-person-walking-arrow-right' => 'Person Walking Arrow Right (exit,internally displaced,leave,refugee)',
				),
				array(
					'fas fa-person-walking-dashed-line-arrow-right' => 'Person Walking Dashed Line Arrow Right (exit,refugee)',
				),
				array(
					'fas fa-person-walking-luggage' => 'Person Walking Luggage (bag,baggage,briefcase,carry-on,deployment,rolling)',
				),
				array(
					'fas fa-person-walking-with-cane' => 'Person Walking With Cane (blind,blind,cane)',
				),
				array(
					'fas fa-poo' => 'Poo (crap,dung,face,monster,pile of poo,poo,poop,shit,smile,turd)',
				),
				array(
					'fas fa-restroom' => 'Restroom (bathroom,toilet,water closet,wc)',
				),
				array(
					'fas fa-skull' => 'Skull (bones,death,face,fairy tale,monster,skeleton,skull,x-ray,yorick)',
				),
				array(
					'fas fa-square-person-confined' => 'Square Person Confined (captivity,confined)',
				),
				array(
					'fas fa-street-view' => 'Street View (directions,location,map,navigation)',
				),
				array(
					'fas fa-user' => 'User (adult,bust,bust in silhouette,gender-neutral,person,profile,silhouette,unspecified gender,users-people)',
				),
				array(
					'far fa-user' => 'User (adult,bust,bust in silhouette,gender-neutral,person,profile,silhouette,unspecified gender,users-people)',
				),
				array(
					'fas fa-user-astronaut' => 'User Astronaut (avatar,clothing,cosmonaut,nasa,space,suit)',
				),
				array(
					'fas fa-user-check' => 'User Check (users-people)',
				),
				array(
					'fas fa-user-clock' => 'User Clock (users-people)',
				),
				array(
					'fas fa-user-doctor' => 'User Doctor (user-md,covid-19,health,job,medical,nurse,occupation,physician,profile,surgeon,worker)',
				),
				array(
					'fas fa-user-gear' => 'User Gear (user-cog,users-people)',
				),
				array(
					'fas fa-user-graduate' => 'User Graduate (users-people)',
				),
				array(
					'fas fa-user-group' => 'User Group (user-friends,bust,busts in silhouette,silhouette,users-people)',
				),
				array(
					'fas fa-user-injured' => 'User Injured (users-people)',
				),
				array(
					'fas fa-user-large' => 'User Large (user-alt,users-people)',
				),
				array(
					'fas fa-user-large-slash' => 'User Large Slash (user-alt-slash,users-people)',
				),
				array(
					'fas fa-user-lock' => 'User Lock (users-people)',
				),
				array(
					'fas fa-user-minus' => 'User Minus (delete,negative,remove)',
				),
				array(
					'fas fa-user-ninja' => 'User Ninja (assassin,avatar,dangerous,deadly,fighter,hidden,ninja,sneaky,stealth)',
				),
				array(
					'fas fa-user-nurse' => 'User Nurse (covid-19,doctor,health,md,medical,midwife,physician,practitioner,surgeon,worker)',
				),
				array(
					'fas fa-user-pen' => 'User Pen (user-edit,users-people)',
				),
				array(
					'fas fa-user-plus' => 'User Plus (add,avatar,positive,sign up,signup,team)',
				),
				array(
					'fas fa-user-secret' => 'User Secret (detective,sleuth,spy,users-people)',
				),
				array(
					'fas fa-user-shield' => 'User Shield (protect,safety)',
				),
				array(
					'fas fa-user-slash' => 'User Slash (ban,delete,remove)',
				),
				array(
					'fas fa-user-tag' => 'User Tag (users-people)',
				),
				array(
					'fas fa-user-tie' => 'User Tie (avatar,business,clothing,formal,professional,suit)',
				),
				array(
					'fas fa-user-xmark' => 'User Xmark (user-times,archive,delete,remove,x)',
				),
				array(
					'fas fa-users' => 'Users (users-people)',
				),
				array(
					'fas fa-users-between-lines' => 'Users Between Lines (covered,group,people)',
				),
				array(
					'fas fa-users-gear' => 'Users Gear (users-cog,users-people)',
				),
				array(
					'fas fa-users-line' => 'Users Line (group,need,people)',
				),
				array(
					'fas fa-users-rays' => 'Users Rays (affected,focused,group,people)',
				),
				array(
					'fas fa-users-rectangle' => 'Users Rectangle (focus,group,people,reached)',
				),
				array(
					'fas fa-users-slash' => 'Users Slash (users-people)',
				),
				array(
					'fas fa-users-viewfinder' => 'Users Viewfinder (focus,group,people,targeted)',
				),
				array(
					'fas fa-wheelchair' => 'Wheelchair (users-people)',
				),
				array(
					'fas fa-wheelchair-move' => 'Wheelchair Move (wheelchair-alt,access,handicap,impairment,physical,wheelchair symbol)',
				),
			),
			'Weather' => array(
				array(
					'fas fa-bolt' => 'Bolt (zap,charge,danger,electric,electricity,flash,high voltage,lightning,voltage,weather,zap)',
				),
				array(
					'fas fa-bolt-lightning' => 'Bolt Lightning (electricity,flash,lightning,weather,zap)',
				),
				array(
					'fas fa-cloud' => 'Cloud (atmosphere,cloud,fog,overcast,save,upload,weather)',
				),
				array(
					'fas fa-cloud-bolt' => 'Cloud Bolt (thunderstorm,bolt,cloud,cloud with lightning,lightning,precipitation,rain,storm,weather)',
				),
				array(
					'fas fa-cloud-meatball' => 'Cloud Meatball (FLDSMDFR,food,spaghetti,storm)',
				),
				array(
					'fas fa-cloud-moon' => 'Cloud Moon (crescent,evening,lunar,night,partly cloudy,sky)',
				),
				array(
					'fas fa-cloud-moon-rain' => 'Cloud Moon Rain (crescent,evening,lunar,night,partly cloudy,precipitation,rain,sky,storm)',
				),
				array(
					'fas fa-cloud-rain' => 'Cloud Rain (Rain,cloud,cloud with rain,precipitation,rain,sky,storm)',
				),
				array(
					'fas fa-cloud-showers-heavy' => 'Cloud Showers Heavy (precipitation,rain,sky,storm)',
				),
				array(
					'fas fa-cloud-showers-water' => 'Cloud Showers Water (cloud,deluge,flood,rain,storm,surge)',
				),
				array(
					'fas fa-cloud-sun' => 'Cloud Sun (clear,cloud,day,daytime,fall,outdoors,overcast,partly cloudy,sun,sun behind cloud)',
				),
				array(
					'fas fa-cloud-sun-rain' => 'Cloud Sun Rain (cloud,day,overcast,precipitation,rain,storm,summer,sun,sun behind rain cloud,sunshower)',
				),
				array(
					'fas fa-house-tsunami' => 'House Tsunami (damage,flood,tidal wave,wave)',
				),
				array(
					'fas fa-hurricane' => 'Hurricane (coriolis effect,eye,storm,tropical cyclone,typhoon)',
				),
				array(
					'fas fa-icicles' => 'Icicles (cold,frozen,hanging,ice,seasonal,sharp)',
				),
				array(
					'fas fa-meteor' => 'Meteor (armageddon,asteroid,comet,shooting star,space)',
				),
				array(
					'fas fa-moon' => 'Moon (Power Sleep Symbol,contrast,crescent,crescent moon,dark,lunar,moon,night)',
				),
				array(
					'far fa-moon' => 'Moon (Power Sleep Symbol,contrast,crescent,crescent moon,dark,lunar,moon,night)',
				),
				array(
					'fas fa-poo-storm' => 'Poo Storm (poo-bolt,bolt,cloud,euphemism,lightning,mess,poop,shit,turd)',
				),
				array(
					'fas fa-rainbow' => 'Rainbow (gold,leprechaun,prism,rain,rainbow,sky)',
				),
				array(
					'fas fa-smog' => 'Smog (dragon,fog,haze,pollution,smoke,weather)',
				),
				array(
					'fas fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'far fa-snowflake' => 'Snowflake (Heavy Chevron Snowflake,cold,precipitation,rain,snow,snowfall,snowflake,winter)',
				),
				array(
					'fas fa-sun' => 'Sun (bright,brighten,contrast,day,lighter,rays,sol,solar,star,sun,sunny,weather)',
				),
				array(
					'far fa-sun' => 'Sun (bright,brighten,contrast,day,lighter,rays,sol,solar,star,sun,sunny,weather)',
				),
				array(
					'fas fa-sun-plant-wilt' => 'Sun Plant Wilt (arid,droop,drought)',
				),
				array(
					'fas fa-temperature-arrow-down' => 'Temperature Arrow Down (temperature-down,air conditioner,cold,heater,mercury,thermometer,winter)',
				),
				array(
					'fas fa-temperature-arrow-up' => 'Temperature Arrow Up (temperature-up,air conditioner,cold,heater,mercury,thermometer,winter)',
				),
				array(
					'fas fa-temperature-empty' => 'Temperature Empty (temperature-0,thermometer-0,thermometer-empty,cold,mercury,status,temperature)',
				),
				array(
					'fas fa-temperature-full' => 'Temperature Full (temperature-4,thermometer-4,thermometer-full,fever,hot,mercury,status,temperature)',
				),
				array(
					'fas fa-temperature-half' => 'Temperature Half (temperature-2,thermometer-2,thermometer-half,mercury,status,temperature,thermometer,weather)',
				),
				array(
					'fas fa-temperature-high' => 'Temperature High (cook,covid-19,mercury,summer,thermometer,warm)',
				),
				array(
					'fas fa-temperature-low' => 'Temperature Low (cold,cool,covid-19,mercury,thermometer,winter)',
				),
				array(
					'fas fa-temperature-quarter' => 'Temperature Quarter (temperature-1,thermometer-1,thermometer-quarter,mercury,status,temperature)',
				),
				array(
					'fas fa-temperature-three-quarters' => 'Temperature Three Quarters (temperature-3,thermometer-3,thermometer-three-quarters,mercury,status,temperature)',
				),
				array(
					'fas fa-tornado' => 'Tornado (cloud,cyclone,dorothy,landspout,tornado,toto,twister,vortext,waterspout,weather,whirlwind)',
				),
				array(
					'fas fa-umbrella' => 'Umbrella (protection,rain,storm,wet)',
				),
				array(
					'fas fa-volcano' => 'Volcano (caldera,eruption,lava,magma,mountain,smoke,volcano)',
				),
				array(
					'fas fa-water' => 'Water (lake,liquid,ocean,sea,swim,wet)',
				),
				array(
					'fas fa-wind' => 'Wind (air,blow,breeze,fall,seasonal,weather)',
				),
			),
			'Writing' => array(
				array(
					'fas fa-blog' => 'Blog (journal,log,online,personal,post,web 2.0,wordpress,writing)',
				),
				array(
					'fas fa-book' => 'Book (book,cover,decorated,diary,documentation,journal,library,notebook,notebook with decorative cover,read,research)',
				),
				array(
					'fas fa-book-bookmark' => 'Book Bookmark (library,research)',
				),
				array(
					'fas fa-bookmark' => 'Bookmark (bookmark,favorite,library,mark,marker,read,remember,research,save)',
				),
				array(
					'far fa-bookmark' => 'Bookmark (bookmark,favorite,library,mark,marker,read,remember,research,save)',
				),
				array(
					'fas fa-box-archive' => 'Box Archive (archive,box,package,save,storage)',
				),
				array(
					'fas fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'far fa-envelope' => 'Envelope (Back of Envelope,e-mail,email,envelope,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-envelope-open' => 'Envelope Open (e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'far fa-envelope-open' => 'Envelope Open (e-mail,email,letter,mail,message,notification,support)',
				),
				array(
					'fas fa-eraser' => 'Eraser (art,delete,remove,rubber)',
				),
				array(
					'fas fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'far fa-file' => 'File (Empty Document,document,new,page,page facing up,pdf,resume)',
				),
				array(
					'fas fa-file-lines' => 'File Lines (file-alt,file-text,Document,Document with Text,document,file-text,invoice,new,page,pdf)',
				),
				array(
					'far fa-file-lines' => 'File Lines (file-alt,file-text,Document,Document with Text,document,file-text,invoice,new,page,pdf)',
				),
				array(
					'fas fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'far fa-folder' => 'Folder (folder-blank,Black Folder,archive,directory,document,file,file folder,folder)',
				),
				array(
					'fas fa-folder-open' => 'Folder Open (Open Folder,archive,directory,document,empty,file,folder,new,open,open file folder)',
				),
				array(
					'far fa-folder-open' => 'Folder Open (Open Folder,archive,directory,document,empty,file,folder,new,open,open file folder)',
				),
				array(
					'fas fa-keyboard' => 'Keyboard (accessory,computer,edit,input,keyboard,text,type,write)',
				),
				array(
					'far fa-keyboard' => 'Keyboard (accessory,computer,edit,input,keyboard,text,type,write)',
				),
				array(
					'fas fa-newspaper' => 'Newspaper (article,editorial,headline,journal,journalism,news,newspaper,paper,press)',
				),
				array(
					'far fa-newspaper' => 'Newspaper (article,editorial,headline,journal,journalism,news,newspaper,paper,press)',
				),
				array(
					'fas fa-notdef' => 'Notdef (close,missing)',
				),
				array(
					'fas fa-note-sticky' => 'Note Sticky (sticky-note,message,note,paper,reminder,sticker)',
				),
				array(
					'far fa-note-sticky' => 'Note Sticky (sticky-note,message,note,paper,reminder,sticker)',
				),
				array(
					'fas fa-paper-plane' => 'Paper Plane (air,float,fold,mail,paper,send)',
				),
				array(
					'far fa-paper-plane' => 'Paper Plane (air,float,fold,mail,paper,send)',
				),
				array(
					'fas fa-paperclip' => 'Paperclip (attach,attachment,connect,link,papercli,paperclip)',
				),
				array(
					'fas fa-paragraph' => 'Paragraph (Pilcrow Sign,edit,format,text,writing)',
				),
				array(
					'fas fa-pen' => 'Pen (ballpoint,design,edit,pen,update,write)',
				),
				array(
					'fas fa-pen-clip' => 'Pen Clip (pen-alt,design,edit,update,write)',
				),
				array(
					'fas fa-pen-to-square' => 'Pen To Square (edit,edit,pen,pencil,update,write)',
				),
				array(
					'far fa-pen-to-square' => 'Pen To Square (edit,edit,pen,pencil,update,write)',
				),
				array(
					'fas fa-pencil' => 'Pencil (pencil-alt,Lower Left Pencil,design,draw,edit,lead,pencil,update,write)',
				),
				array(
					'fas fa-quote-left' => 'Quote Left (quote-left-alt,Left Double Quotation Mark,mention,note,phrase,text,type)',
				),
				array(
					'fas fa-quote-right' => 'Quote Right (quote-right-alt,Right Double Quotation Mark,mention,note,phrase,text,type)',
				),
				array(
					'fas fa-signature' => 'Signature (John Hancock,cursive,name,writing)',
				),
				array(
					'fas fa-square-pen' => 'Square Pen (pen-square,pencil-square,edit,pencil-square,update,write)',
				),
				array(
					'fas fa-thumbtack' => 'Thumbtack (thumb-tack,Black Pushpin,coordinates,location,marker,pin,pushpin,thumb-tack)',
				),
			),
		);
		return $fontawesome_icons;
	}
}

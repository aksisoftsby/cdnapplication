/* This section of the code registers a new block, sets an icon and a category, and indicates what type of fields it'll include. */

wp.blocks.registerBlockType('pgssl/social-login', {
	title: 'Social Login',
	icon: 'smiley',
	category: 'common',
	attributes: {
		content: {type: 'string'},
	},
  
/* This configures how the content field will work, and sets up the necessary elements */
  
	edit: function(props) {
		function updateContent(event) {
			props.setAttributes({content: event.target.value})
		}
		return React.createElement(
			"div",
			null,
			React.createElement(
				"h3",
				null,
				"Social Login"
			),
			React.createElement("input", { type: "text", value: props.attributes.content, onChange: updateContent })
		);
	},
	save: function(props) {
		return wp.element.createElement(
			"h3",
			{ style: { border: "3px solid #cccccc" } },
			props.attributes.content
		);
	}
})
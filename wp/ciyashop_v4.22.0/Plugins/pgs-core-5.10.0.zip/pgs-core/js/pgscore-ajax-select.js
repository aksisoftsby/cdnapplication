/**
 * Backend JS for pgs_ajax_select - parameter
 */
 
( function( $ ) {
	"use strict";

	window.vc.atts.pgscore_ajax_select = {
        render: function ( param, value ) {
            return value;
        },
        init: function ( param, $field ) {

			var select_el     = $field.find( '.pgscore_ajax_select' );
			var control_title = $field.find( '.wpb_element_label' );
			var options       = $field.find( '.pgscore_ajax_select' ).attr( 'data-option' );

			select_el.select2({
				minimumInputLength: 3,
				ajax: {
					delay: 500,
					method  : "POST",
					url     : param.ajaxurl,
					dataType: 'json',
					data    : function( sparams ) {
						var query_params = {
							action     :'pgs_ajax_select_autocomplete',
							action_type: 'search',
							term       : sparams.term,
							nonce      : param.nonce,
							param_name : param.param_name,
							source_name: param.source_name,
							source_type: param.source_type,
							ajax_params: param,
							selected   : select_el.val()
						}
						return query_params;
					},
				},
				cache: true
			});
			
			var ids = [];
			if ( options ) {
				var current_ids = options.split( ',' );

				if ( ! Array.isArray( current_ids ) && current_ids != '' ) {
					ids = [current_ids];
				}else if( Array.isArray( current_ids ) ) {
					ids = current_ids.filter( function( el ) {
						return el != null;
					})
				}
			}
			
			if ( ids.length > 0 ) {

				control_title.after('<span class="vc-control-spinner"></span>');
				$.ajax({
					method: "POST",
					url: param.ajaxurl,
					data: {
						action     : 'pgs_ajax_select_autocomplete',
						action_type: 'get_titles',
						nonce      : param.nonce,
						param_name : param.param_name,
						source_name: param.source_name,
						source_type: param.source_type,
						ajax_params: param,
						selected   : ids,
					}
				} ).then( function( response ) {
					if ( typeof response.results != 'undefined' && Object.keys( response.results ).length > 0 ) {
						$.each( response.results, function( i, v ) {
							var new_option = new Option(
								v.text,
								v.id,
								true,
								true
							);
							select_el.append( new_option ).trigger( 'change' );
						} );
						select_el.trigger({
							type: 'select2:select',
							params: {
								data: response
							}
						});
					}

					control_title.siblings('.vc-control-spinner').remove();
				});
			}

			//Manual Sorting : Select2 drag and drop : starts
			// #ToDo Try to use promise in future
			select_el.next().children().children().children().sortable({
				containment: 'parent',
				stop: function(event, ui) {
					ui.item.parent().children('[title]').each(function() {
						var title = $(this).attr('title');
						var original = $('option:contains(' + title + ')', select_el).first();
						original.detach();
						select_el.append(original)
					});
					select_el.change();
				}
			});

			select_el.on("select2:select", function(evt) {
				var element = evt.params.data.element;
				var $element = $(element);

				$element.detach();
				$(this).append($element);
				$(this).trigger("change");
			});
			//Manual Sorting : Select2 drag and drop : ends
        }
    };

} )( jQuery );
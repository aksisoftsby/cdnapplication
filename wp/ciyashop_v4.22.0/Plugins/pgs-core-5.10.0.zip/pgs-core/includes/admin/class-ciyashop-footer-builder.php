<?php
/**
 * CiyaShop footer Builder Class.
 *
 * @author      Potenza Team
 * @package     ciyashop
 * @version     1.0.0
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Ciyashop_Footer_Builder' ) ) {
	/**
	 * Footer builder.
	 */
	class Ciyashop_Footer_Builder {

		/**
		 * Footer builder elements.
		 *
		 * @var $elements
		 */
		public $elements = '';

		/**
		 * Menu page object for the footer builder.
		 *
		 * @var string
		 */
		public $ciyashop_footer_builder;

		/**
		 * Ciyashop_Footer_Builder construct
		 */
		public function __construct() {

			add_action( 'admin_menu', array( $this, 'register_footer_builder_menu' ) );
			add_action( 'admin_init', array( $this, 'create_footer_builder_table' ) );

			add_action( 'wp_ajax_clone_footer', array( $this, 'clone_footer' ) );
			add_action( 'wp_ajax_save_footer_builder', array( $this, 'save_footer_builder' ) );
			add_action( 'wp_ajax_delete_footer', array( $this, 'delete_footer' ) );
		}

		/**
		 * Register menu for footer builder.
		 */
		public function register_footer_builder_menu() {
			$this->ciyashop_footer_builder = add_menu_page(
				__( 'Footer Builder', 'pgs-core' ),       // Page Title.
				__( 'Footer Builder', 'pgs-core' ),       // Menu Title.
				'manage_options',                         // Capability.
				'footer-builder',                         // Slug.
				array( $this, 'footer_bulder_list' ),     // Callback.
				'dashicons-tagcloud',                     // Icon.
				50                                        // Position.
			);
			add_submenu_page(
				'footer-builder',
				__( 'All Layouts', 'pgs-core' ),
				__( 'All Layouts', 'pgs-core' ),
				'manage_options',
				'footer-builder',
				array( $this, 'footer_bulder_list' )
			);
			add_submenu_page(
				'footer-builder',
				__( 'Layout Setting', 'pgs-core' ),
				__( 'Add New Layout', 'pgs-core' ),
				'manage_options',
				'footer-layout',
				array( $this, 'footer_bulder_create' )
			);
		}

		/**
		 * Footer list.
		 */
		public function footer_bulder_list() {
			require_once trailingslashit( PGSCORE_PATH ) . 'includes/admin/footer-builder/footer-layout-lists.php';
		}

		/**
		 * Create the footer layout.
		 */
		public function footer_bulder_create() {
			require_once trailingslashit( PGSCORE_PATH ) . 'includes/admin/footer-builder/footer-layout.php';
		}

		/**
		 * Create the footer builder table.
		 */
		public function create_footer_builder_table() {
			global $wpdb;
			$charset_collate = $wpdb->get_charset_collate();

			$table_name = $wpdb->prefix . 'cs_footer_builder';

			$sql = "CREATE TABLE $table_name (
				  id mediumint(9) NOT NULL AUTO_INCREMENT,
				  name tinytext NOT NULL,
				  value longtext NULL,
				  PRIMARY KEY  (id)
				) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );

		}

		/**
		 * Save footer builder.
		 */
		public function save_footer_builder() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- Data is sanitized by pgscore_clean.
			$data = isset( $_POST['footer_settings'] ) ? pgscore_clean( wp_unslash( $_POST['footer_settings'] ) ) : '';

			if ( empty( $data ) ) {
				$data['message'] = esc_html__( 'Missing Data', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			global $wpdb;

			$table_name = $wpdb->prefix . 'cs_footer_builder';
			$title      = isset( $data['layout_name'] ) ? sanitize_text_field( $data['layout_name'] ) : '';
			$footer_id  = isset( $data['footer_id'] ) ? (int) $data['footer_id'] : 0;
			$value      = serialize( $data );
			$redirect   = false;

			if ( $footer_id > 0 ) {
				$footer_layout_data = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT * FROM $table_name WHERE id = %d",
						$footer_id
					)
				);

				if ( ! empty( $footer_layout_data ) ) {
					$wpdb->update(
						$table_name,
						array(
							'name' => $title,
							'value' => $value,
						),
						array(
							'id' => $footer_id,
						)
					);
					$redirect = true;
				}
			} else {
				$wpdb->insert(
					$table_name,
					array(
						'name'  => $title,
						'value' => $value,
					),
					array( '%s', '%s' )
				);
				$footer_id = $wpdb->insert_id;
				$redirect  = true;
			}

			$return_data = array(
				'success'   => true,
				'footer_id' => $footer_id,
				'redirect'  => $redirect,
			);

			echo wp_json_encode( $return_data );
			exit();
		}

		/**
		 * Clone footer.
		 */
		public function clone_footer() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			global $wpdb;

			$hdr_id = isset( $_POST['footer_id'] ) ? (int) $_POST['footer_id'] : 0;

			if ( $hdr_id <= 0 ) {
				wp_send_json_error( 'Invalid ID', 400 );
			}

			$table_name = $wpdb->prefix . 'cs_footer_builder';

			$footer_layout_data = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $hdr_id )
			);

			if ( empty( $footer_layout_data ) ) {
				wp_send_json_error( 'Not Found', 404 );
			}

			$title = $footer_layout_data[0]->name . ' ( ' . __( 'Copy', 'pgs-core' ) . ' )';
			$value = $footer_layout_data[0]->value;

			$wpdb->insert(
				$table_name,
				array(
					'name'  => $title,
					'value' => $value,
				),
				array( '%s', '%s' )
			);

			$return_data = array(
				'success'      => true,
				'footer_title' => $title,
				'footer_id'    => $wpdb->insert_id,
			);

			echo wp_json_encode( $return_data );
			exit();
		}

		/**
		 * Delete the footer.
		 */
		public function delete_footer() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			$footer_id = isset( $_POST['footer_id'] ) ? (int) $_POST['footer_id'] : 0;

			if ( $footer_id <= 0 ) {
				wp_send_json_error( 'Invalid ID', 400 );
			}

			global $wpdb;
			$table_name = $wpdb->prefix . 'cs_footer_builder';

			$wpdb->delete( $table_name, array( 'id' => $footer_id ) );

			$return_data = array(
				'success'   => true,
				'footer_id' => $footer_id,
			);

			echo wp_json_encode( $return_data );
			exit();
		}
	}
}

new Ciyashop_Footer_Builder();

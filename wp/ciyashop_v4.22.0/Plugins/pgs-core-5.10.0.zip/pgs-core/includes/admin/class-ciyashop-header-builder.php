<?php
/**
 * CiyaShop Header Builder Class
 *
 * Handles the creation and management of custom header layouts.
 *
 * @package     ciyashop
 * @version     3.0.0
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'CiyaShop_Header_Builder' ) ) {
	/**
	 * CiyaShop Header Builder Class
	 */
	class CiyaShop_Header_Builder {

		/**
		 * Header elements.
		 *
		 * @var string
		 */
		public $elements = '';

		/**
		 * Header layouts.
		 *
		 * @var array
		 */
		public $layouts;

		/**
		 * Header configuration options.
		 *
		 * @var array
		 */
		public $configure_options;

		/**
		 * Header builder menu page hook.
		 *
		 * @var string
		 */
		public $ciyashop_header_builder;

		/**
		 * Constructor.
		 *
		 * Initializes the header builder by setting up filters, actions, and global variables.
		 */
		public function __construct() {
			global $header_elements, $header_configure_opt, $header_layouts;

			$this->layouts           = apply_filters( 'header_layouts', $header_layouts, $header_layouts );
			$this->elements          = apply_filters( 'header_builder_elements', $header_elements, $header_elements );
			$this->configure_options = apply_filters( 'header_configure_options', $header_configure_opt, $header_configure_opt );

			add_action( 'admin_menu', array( $this, 'register_header_builder_menu' ) );
			add_action( 'admin_init', array( $this, 'create_header_builder_table' ) );

			// Ajax callbacks.
			add_action( 'wp_ajax_add_sample_header', array( $this, 'add_sample_header' ) );
			add_action( 'wp_ajax_clone_header', array( $this, 'clone_header' ) );
			add_action( 'wp_ajax_export_header', array( $this, 'export_header' ) );
			add_action( 'wp_ajax_import_header', array( $this, 'import_header' ) );
			add_action( 'wp_ajax_edit_element', array( $this, 'edit_element' ) );
			add_action( 'wp_ajax_save_header_builder', array( $this, 'save_header_builder' ) );
			add_action( 'wp_ajax_delete_header', array( $this, 'delete_header' ) );
			add_action( 'wp_ajax_header_configure', array( $this, 'header_configure' ) );
		}

		/**
		 * Register Header Builder Menu.
		 *
		 * Adds the header builder menu and submenus to the WordPress admin dashboard.
		 */
		public function register_header_builder_menu() {
			$this->ciyashop_header_builder = add_menu_page(
				esc_html__( 'Header Builder', 'pgs-core' ), // Page Title.
				esc_html__( 'Header Builder', 'pgs-core' ), // Menu Title.
				'manage_options',                           // Capability.
				'header-builder',                           // Slug.
				array( $this, 'header_bulder_list' ),       // Callback.
				'dashicons-archive',                        // Icon.
				50                                          // Position.
			);
			add_submenu_page(
				'header-builder',
				esc_html__( 'All Layouts', 'pgs-core' ),
				esc_html__( 'All Layouts', 'pgs-core' ),
				'manage_options',
				'header-builder',
				array( $this, 'header_bulder_list' )
			);
			add_submenu_page(
				'header-builder',
				esc_html__( 'Layout Setting', 'pgs-core' ),
				esc_html__( 'Add New Layout', 'pgs-core' ),
				'manage_options',
				'header-layout',
				array( $this, 'header_bulder_create' )
			);
		}

		/**
		 * Header Builder List.
		 *
		 * Displays the list of all header layouts.
		 */
		public function header_bulder_list() {
			require_once trailingslashit( PGSCORE_PATH ) . 'includes/admin/header_builder/header-layout-lists.php';
		}

		/**
		 * Header Builder Create.
		 *
		 * Displays the interface for creating a new header layout.
		 */
		public function header_bulder_create() {
			require_once trailingslashit( PGSCORE_PATH ) . 'includes/admin/header_builder/header-layout.php';
		}

		/**
		 * Create Header Builder Table.
		 *
		 * Creates the database table for storing header builder data.
		 */
		public function create_header_builder_table() {
			global $wpdb;
			$charset_collate = $wpdb->get_charset_collate();

			$table_name = $wpdb->prefix . 'cs_header_builder';

			$sql = "CREATE TABLE $table_name (
				  id mediumint(9) NOT NULL AUTO_INCREMENT,
				  name tinytext NOT NULL,
				  value longtext NULL,
				  PRIMARY KEY  (id)
				) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}

		/**
		 * Add Sample Header.
		 *
		 * Adds a sample header layout to the database.
		 * SECURITY: Restricts the $layout variable to alphanumeric and underscore characters only to prevent path traversal.
		 *           Checks if the file exists before reading.
		 *           WARNING: Uses unserialize on trusted internal files only. Do NOT allow user-uploaded files here.
		 */
		public function add_sample_header() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and user capabilities.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			global $wpdb;

			// SECURITY: Only allow safe characters for $layout to prevent path traversal.
			$layout = isset( $_POST['layout'] ) ? sanitize_text_field( wp_unslash( $_POST['layout'] ) ) : '';
			if ( ! preg_match( '/^[a-zA-Z0-9_]+$/', $layout ) ) {
				$data['message'] = esc_html__( 'Invalid layout name.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			$file_path = trailingslashit( PGSCORE_PATH ) . 'includes/admin/header_builder/samples/' . $layout . '.txt';
			if ( ! file_exists( $file_path ) ) {
				$data['message'] = esc_html__( 'Layout file not found.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			$value = file_get_contents( $file_path );

			// SECURITY WARNING: unserialize can be dangerous. Only use on trusted, internal files.
			$data = unserialize( $value );

			$wpdb->insert(
				$wpdb->prefix . 'cs_header_builder',
				array(
					'name'  => sanitize_text_field( $data['title'] ),
					'value' => $value,
				)
			);

			$header_id = $wpdb->insert_id;

			$return_data = array(
				'success'   => true,
				'header_id' => $header_id,
			);

			echo wp_json_encode( $return_data );
			exit();
		}

		/**
		 * Edit Element.
		 *
		 * Retrieves the configuration options for a specific header element.
		 */
		public function edit_element() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			$element  = isset( $_POST['elementId'] ) ? sanitize_text_field( wp_unslash( $_POST['elementId'] ) ) : '';
			$elements = $this->elements;

			$element_options = isset( $elements[ $element ]['params'] ) ? $elements[ $element ]['params'] : array();

			echo wp_json_encode(
				array(
					'success'  => true,
					'elements' => $element_options,
				)
			);
			exit();
		}

		/**
		 * Save Header Builder.
		 *
		 * Saves the header builder data to the database.
		 */
		public function save_header_builder() {
			$return_data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$return_data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $return_data );
				exit();
			}

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- Data is sanitized by pgscore_clean.
			$data = isset( $_POST['objects'] ) ? wp_unslash( $_POST['objects'] ) : array();

			if ( ! is_array( $data ) || empty( $data ) ) {
				$return_data['message'] = esc_html__( 'Invalid data.', 'pgs-core' );
				echo wp_json_encode( $return_data );
				exit();
			}

			global $ciyashop_options, $wpdb;

			$table_name = $wpdb->prefix . 'cs_header_builder';

			$title     = isset( $data['title'] ) ? sanitize_text_field( wp_unslash( $data['title'] ) ) : '';
			$header_id = isset( $data['header_id'] ) ? intval( wp_unslash( $data['header_id'] ) ) : 0;
			$value     = maybe_serialize( $data );
			$redirect  = false;

			if ( $header_id > 0 ) {
				$header_layout_data = $wpdb->get_results(
					$wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $header_id )
				);
				if ( ! empty( $header_layout_data ) ) {
					$wpdb->update(
						$table_name,
						array(
							'name'  => $title,
							'value' => $value,
						),
						array( 'id' => $header_id ),
						array( '%s', '%s' ),
						array( '%d' )
					);
					$redirect = true;
				}
			} else {
				$wpdb->insert(
					$table_name,
					array(
						'name'  => $title,
						'value' => $value,
					),
					array( '%s', '%s' )
				);
				$header_id = $wpdb->insert_id;
				$redirect  = true;
			}

			$return_data = array(
				'success'   => true,
				'header_id' => $header_id,
				'redirect'  => $redirect,
			);

			if ( class_exists( 'Redux' ) ) {
				// Generate the color customizer CSS.
				$primary_color   = esc_html( $ciyashop_options['primary_color'] );
				$secondary_color = esc_html( $ciyashop_options['secondary_color'] );
				$tertiary_color  = esc_html( $ciyashop_options['tertiary_color'] );

				$header_schema   = ciyashop_get_custom_header_schema();
				$color_customize = ciyashop_get_color_scheme_colors( $primary_color, $secondary_color, $tertiary_color, $header_schema );
				ciyashop_generate_color_customize_css( $color_customize );
			}

			echo wp_json_encode( $return_data );
			exit();
		}

		/**
		 * Clone Header.
		 *
		 * Creates a duplicate of an existing header layout.
		 */
		public function clone_header() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			global $wpdb;

			$header_id = isset( $_POST['header_id'] ) ? intval( $_POST['header_id'] ) : 0;

			$table_name         = $wpdb->prefix . 'cs_header_builder';
			$header_layout_data = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $header_id ) );

			if ( empty( $header_layout_data ) ) {
				$data['message'] = esc_html__( 'Header not found.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			$header_builder_title = sanitize_text_field( $header_layout_data[0]->name );
			$header_builder_value = $header_layout_data[0]->value;

			$wpdb->insert(
				$table_name,
				array(
					'name'  => $header_builder_title . ' (Copy)',
					'value' => $header_builder_value,
				)
			);

			$header_id   = $wpdb->insert_id;
			$return_data = array(
				'success'      => true,
				'header_title' => $header_builder_title . ' (Copy)',
				'header_id'    => $header_id,
			);

			echo wp_json_encode( $return_data );
			exit();
		}

		/**
		 * Export Header.
		 *
		 * Exports a header layout as a downloadable file.
		 */
		public function export_header() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			global $wpdb;
			$hdr_id = isset( $_POST['headerId'] ) ? (int) $_POST['headerId'] : '';

			$return_data = false;

			$header_layout_data = $wpdb->get_results(
				$wpdb->prepare(
					'
					SELECT * FROM ' . $wpdb->prefix . 'cs_header_builder
					WHERE id = %d
					',
					$hdr_id
				)
			);

			if ( $header_layout_data ) {

				$header_builder_title = $header_layout_data[0]->name;
				$header_builder_value = $header_layout_data[0]->value;

				$header_builder_title = strtolower( str_replace( ' ', '-', $header_builder_title ) );

				$return_data = array(
					'success'      => true,
					'file_name'    => $header_builder_title . '.txt',
					'file_content' => $header_builder_value,
				);
			}

			echo wp_json_encode( $return_data );
			exit();

		}

		/**
		 * Import Header.
		 *
		 * Imports a header layout from a file.
		 */
		public function import_header() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			global $wpdb, $wp_filesystem;

			$return_data = false;

			if ( isset( $_FILES['file'] ) ) {

				if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base' ) ) {
					require_once ABSPATH . 'wp-admin/includes/file.php';
					$creds = request_filesystem_credentials( site_url() );
					wp_filesystem( $creds );
				}

				if ( isset( $_FILES['file']['type'] ) && 'text/plain' === $_FILES['file']['type'] ) {
					$table_name = $wpdb->prefix . 'cs_header_builder';
					$filename   = isset( $_FILES['file']['tmp_name'] ) ? sanitize_text_field( $_FILES['file']['tmp_name'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash

					$header_builder_value = $wp_filesystem->get_contents( $filename );
					$header_builder_title = unserialize( $header_builder_value );
					$header_builder_title = $header_builder_title['title'];

					$wpdb->insert(
						$table_name,
						array(
							'name'  => $header_builder_title,
							'value' => $header_builder_value,
						)
					);

					$header_id = $wpdb->insert_id;

					$return_data = array(
						'success'      => true,
						'header_title' => $header_builder_title,
						'header_id'    => $header_id,
					);
				}
			}

			echo wp_json_encode( $return_data );
			exit();

		}

		/**
		 * Delete Header.
		 *
		 * Deletes a header layout from the database.
		 */
		public function delete_header() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			$header_id = isset( $_POST['header_id'] ) ? intval( $_POST['header_id'] ) : 0;

			if ( empty( $header_id ) ) {
				wp_send_json_error( esc_html__( 'Invalid header ID.', 'pgs-core' ) );
				exit();
			}

			global $wpdb;
			$table_name = $wpdb->prefix . 'cs_header_builder';

			$wpdb->delete( $table_name, array( 'id' => $header_id ), array( '%d' ) );

			wp_send_json_success();
			exit();
		}

		/**
		 * Header Configure.
		 *
		 * Retrieves the header configuration options.
		 */
		public function header_configure() {
			$data = array(
				'success' => false,
				'message' => esc_html__( 'Something went wrong. Please try again later.', 'pgs-core' ),
			);

			// Verify nonce and require proper capabilities to secure the endpoint.
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'admin_ajax_nonce' ) || ! current_user_can( 'manage_options' ) ) {
				$data['message'] = esc_html__( 'Unauthorized request.', 'pgs-core' );
				echo wp_json_encode( $data );
				exit();
			}

			$configure_options = $this->configure_options;
			echo wp_json_encode(
				array(
					'success' => true,
					'data'    => $configure_options,
				)
			);

			exit();
		}
	}
}

// Initialize the CiyaShop_Header_Builder class.
new CiyaShop_Header_Builder();
